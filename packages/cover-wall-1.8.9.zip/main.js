/* 获取当前宿主实际样式，让调节入口跟随同一套控制台美术。 */
function syncAppearance(force) {
  var now = performance.now();
  if (!force && now - appearanceMeasuredAt < 1000) return;
  appearanceMeasuredAt = now;
  var fab = document.getElementById('fx-fab'), panel = document.getElementById('fx-panel');
  if (!fab || !panel) return;
  var buttonStyle = getComputedStyle(fab), panelStyle = getComputedStyle(panel);
  var rootStyle = getComputedStyle(document.documentElement);
  var appearance = {
    '--scale-button-bg': buttonStyle.backgroundImage !== 'none' ? buttonStyle.backgroundImage : buttonStyle.backgroundColor,
    '--scale-button-border': buttonStyle.borderColor,
    '--scale-button-color': buttonStyle.color,
    '--scale-button-shadow': buttonStyle.boxShadow,
    '--scale-button-blur': buttonStyle.backdropFilter || buttonStyle.webkitBackdropFilter || 'blur(20px) saturate(1.34)',
    '--scale-panel-bg': panelStyle.backgroundColor,
    '--scale-panel-border': panelStyle.borderColor,
    '--scale-panel-shadow': panelStyle.boxShadow,
    '--scale-panel-blur': panelStyle.backdropFilter || panelStyle.webkitBackdropFilter || 'blur(30px) saturate(1.34)',
    '--scale-accent': rootStyle.getPropertyValue('--fc-accent').trim() || '#00f5d4',
  };
  var value = JSON.stringify(appearance);
  if (force || value !== appearanceSignature) { appearanceSignature = value; post('appearance', { appearance: appearance }); }
}

/* 把宿主的秒级歌词转换为 Folia 原版封面歌词的数据格式。 */
function lyricNumber(value, fallback) { var n = Number(value); return value != null && isFinite(n) ? n : fallback; }
function convertLines(rows) {
  return rows.map(function (line, i) {
    var start = lyricNumber(line.t, lyricNumber(line.startTime, 0));
    var next = i + 1 < rows.length ? lyricNumber(rows[i + 1].t, lyricNumber(rows[i + 1].startTime, start + 5)) : start + 5;
    var end = Math.max(start + 0.05, lyricNumber(line.endTime, start + lyricNumber(line.duration, Math.max(0.1, next - start))));
    var text = String(line.text || line.fullText || '');
    var words = (Array.isArray(line.words) ? line.words : []).map(function (word) {
      var t = lyricNumber(word.t, lyricNumber(word.startTime, start));
      return { text: String(word.text || ''), startTime: t, endTime: Math.max(t + 0.01, lyricNumber(word.endTime, t + lyricNumber(word.d, lyricNumber(word.duration, 0.1)))) };
    });
    if (!words.length && text) {
      var chars = Array.from(text), step = (end - start) / chars.length;
      words = chars.map(function (ch, j) { return { text: ch, startTime: start + j * step, endTime: start + (j + 1) * step }; });
    }
    return { fullText: text, startTime: start, endTime: end, words: words, translation: String(line.translation || line.trans || ''), romanization: String(line.romanization || ''), isChorus: !!line.isChorus, songPart: line.songPart, blockIndex: line.blockIndex };
  });
}
function colorHex(css, fallback) {
  css = String(css || '').trim();
  if (/^#[0-9a-f]{6}$/i.test(css)) return css;
  if (/^#[0-9a-f]{3}$/i.test(css)) return '#' + css.slice(1).split('').map(function (c) { return c + c; }).join('');
  var rgb = css.match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)/i);
  return rgb ? '#' + rgb.slice(1, 4).map(function (v) { return Math.max(0, Math.min(255, Math.round(Number(v)))).toString(16).padStart(2, '0'); }).join('') : fallback;
}
function lyricTheme() {
  var fx = window.fx || {}, stage = window.stageLyrics || {}, pal = stage.coverPalette || stage.palette || {};
  try {
    if (fx.lyricColorMode === 'custom') pal = typeof window.lyricPaletteFromHex === 'function' ? window.lyricPaletteFromHex(fx.lyricColor) : { primary: fx.lyricColor, secondary: fx.lyricColor };
    if (typeof window.effectiveLyricPalette === 'function') pal = window.effectiveLyricPalette(pal);
  } catch (e) {}
  if (fx.lyricHighlightMode === 'custom' && typeof window.effectiveLyricPalette !== 'function') pal = Object.assign({}, pal, { highlight: fx.lyricHighlightColor });
  return { name: '宿主歌词配色', backgroundColor: '#090b10', primaryColor: colorHex(pal.primary, '#f5f0e6'), secondaryColor: colorHex(pal.secondary, '#8f98ad'), accentColor: colorHex(pal.highlight || pal.primary, '#d9b16d'), fontStyle: fx.lyricFont === 'serif' || fx.lyricFont === 'mono' ? fx.lyricFont : 'sans', fontWeight: lyricNumber(fx.lyricWeight, 500), animationIntensity: 'normal' };
}
function syncLyrics(songKey, force) {
  var rows = Array.isArray(window.lyricsLines) ? window.lyricsLines : [];
  var theme = lyricTheme();
  var value = JSON.stringify({ songKey: songKey, rows: rows, theme: theme });
  if (force || value !== lyricsSignature) {
    lyricsSignature = value;
    post('lyrics', { songKey: songKey, lines: convertLines(rows), theme: theme });
  }
}

/* IDs are provider scoped. Search candidates must match before their IDs are used. */
var libraryDetailProviders = ['netease', 'qq', 'kugou', 'qishui', 'spotify'];
var libraryResolvedRefs = new Map();
var libraryProviderLabels = { netease: '网易云', qq: 'QQ 音乐', kugou: '酷狗', qishui: '汽水', kuwo: '酷我', migu: '咪咕', spotify: 'Spotify' };
function libraryNorm(value) {
  return String(value || '').normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu, '');
}
function librarySame(a, b) { return !!libraryNorm(a) && libraryNorm(a) === libraryNorm(b); }
function libraryAlbumName(song) {
  var album = song && (song.al || song.album);
  return String(album && typeof album === 'object' ? album.name || album.title || '' : album || song && (song.albumName || song.alName) || '');
}
function libraryArtists(song) {
  var list = song && (song.ar || song.artists || song.singer);
  if (!Array.isArray(list) || !list.length) list = String(song && song.artist || '').split(/\s*\/\s*|、|,|，/);
  return list.map(function (entry) { return typeof entry === 'string' ? { name: entry } : entry || {}; }).filter(function (entry) { return entry.name; }).flatMap(function (entry) {
    if (entry.id || entry.mid || entry.artistId || !/\s+\/\s+|、|,|，/.test(entry.name)) return [entry];
    return String(entry.name).split(/\s+\/\s+|、|,|，/).map(function (name) { return { name: name.trim() }; }).filter(function (part) { return part.name; });
  });
}
function libraryDirectTarget(kind, song, provider, artistName) {
  if (!song || libraryProvider(song) !== provider) return null;
  var remembered = libraryResolvedRefs.get(libraryIdentity(song));
  if (remembered && kind === 'album' && remembered.album) return remembered.album;
  if (remembered && kind === 'artist' && remembered.artists[libraryNorm(artistName)]) return remembered.artists[libraryNorm(artistName)];
  if (kind === 'album') {
    var nested = song.al || (typeof song.album === 'object' ? song.album : {}) || {};
    var albumId = provider === 'qq' ? song.albumMid || song.albummid || song.album_mid || nested.mid : song.albumId || song.album_id || nested.id;
    if (albumId) return { provider: provider, id: String(albumId), name: libraryAlbumName(song) };
    if (provider === 'qishui' && song.id) return { provider: provider, trackId: String(song.id), name: libraryAlbumName(song) };
    return null;
  }
  var artists = libraryArtists(song), selected = artists.find(function (entry) { return librarySame(entry.name, artistName); });
  if (!selected) return null;
  var id = provider === 'qq' ? selected.mid || selected.singerMid || selected.artistMid : selected.id || selected.artistId || selected.singerid || selected.author_id || selected.mid;
  if (!id && librarySame(artists[0] && artists[0].name, artistName)) {
    id = provider === 'qq' ? song.artistMid || song.singerMid : song.artistId || song.singerid || song.singerId || song.author_id;
  }
  if (!id || provider === 'qq' && /^\d+$/.test(String(id))) return null;
  return { provider: provider, id: String(id), name: artistName };
}
function rememberLibraryReference(song, kind, target) {
  var key = libraryIdentity(song), previous = libraryResolvedRefs.get(key) || { artists: {} };
  if (kind === 'album') previous.album = target;
  if (kind === 'artist' && libraryArtists(song).some(function (entry) { return librarySame(entry.name, target.name); })) previous.artists[libraryNorm(target.name)] = target;
  libraryResolvedRefs.set(key, previous);
  if (libraryResolvedRefs.size > 4000) libraryResolvedRefs.delete(libraryResolvedRefs.keys().next().value);
}
function libraryDetailUrl(kind, provider, target) {
  if (provider === 'spotify') return target.id ? '/api/spotify/' + kind + '/detail?id=' + encodeURIComponent(target.id) + '&limit=100' : '';
  var payload = { id: target.id, trackId: target.trackId, name: target.name, limit: kind === 'album' ? 120 : 60 };
  var url = typeof window.detailUrlFor === 'function' ? window.detailUrlFor(kind, provider, payload) : '';
  if (kind === 'artist' && provider === 'qishui' && url) url += '&name=' + encodeURIComponent(target.name || '');
  return url;
}
function librarySearchUrl(provider, keyword) {
  var prefix = provider === 'netease' ? '' : '/' + provider;
  return '/api' + prefix + '/search?keywords=' + encodeURIComponent(keyword) + '&limit=20';
}
function libraryMatchCandidate(song, seed, kind, artistName, albumName) {
  if (!libraryArtists(song).some(function (entry) { return librarySame(entry.name, artistName); })) return false;
  if (kind === 'album' && albumName && !librarySame(libraryAlbumName(song), albumName)) return false;
  // Keep Live/remix/version words: different editions must not collapse into one match.
  return !seed || !seed.name && !seed.title || librarySame(song.name || song.title, seed.name || seed.title);
}
async function libraryCandidateTarget(kind, provider, seed, artistName, albumName, allowDirect) {
  var direct = allowDirect ? libraryDirectTarget(kind, seed, provider, artistName) : null;
  if (direct) return direct;
  if (allowDirect && provider === 'qq' && seed && (seed.mid || seed.songmid)) {
    try {
      var full = await libraryFetch('/api/qq/song/detail?mid=' + encodeURIComponent(seed.mid || seed.songmid));
      direct = libraryDirectTarget(kind, Object.assign({}, seed, full, { provider: provider }), provider, artistName);
      if (direct) return direct;
    } catch (error) { if (error.name === 'AbortError') throw error; }
  }
  var queries = [(seed && (seed.name || seed.title) || albumName) + ' ' + artistName];
  if (!seed && kind === 'artist') queries = [artistName];
  if (kind === 'album' && albumName) queries.push(albumName + ' ' + artistName);
  queries = Array.from(new Set(queries));
  for (var i = 0; i < queries.length; i++) {
    var result = await libraryFetch(librarySearchUrl(provider, queries[i].trim()));
    var rows = result.songs || result.tracks || (Array.isArray(result.data) ? result.data : result.data && result.data.songs) || [];
    for (var j = 0; j < rows.length; j++) {
      var candidate = Object.assign({}, rows[j], { provider: provider, source: provider });
      if (!libraryMatchCandidate(candidate, seed, kind, artistName, albumName)) continue;
      direct = libraryDirectTarget(kind, candidate, provider, artistName);
      if (direct) return direct;
    }
  }
  return null;
}
function librarySourceOrder(raw, target, skip) {
  var native = target.provider || libraryProvider(raw || {}), order = [native];
  if (typeof window.detailProviderOrder === 'function') order.push.apply(order, window.detailProviderOrder(raw || {}));
  order.push.apply(order, libraryDetailProviders);
  return Array.from(new Set(order)).filter(function (provider) { return libraryDetailProviders.indexOf(provider) >= 0 && (skip || []).indexOf(provider) < 0; });
}
async function resolveLibraryDetail(data, raw, options) {
  options = options || {};
  var target = data.target || {}, kind = data.kind;
  var artists = libraryArtists(raw), index = Number.isInteger(target.artistIndex) ? target.artistIndex : 0;
  var targetArtists = libraryArtists({ artist: target.artist });
  var artistName = kind === 'artist' && target.name || artists[index] && artists[index].name || targetArtists[0] && targetArtists[0].name || '';
  if (!artistName) throw new Error('缺少歌手信息，无法确认对应关系');
  var albumName = kind === 'album' ? target.name || libraryAlbumName(raw) : '';
  var origin = target.provider || libraryProvider(raw || {}), providers = librarySourceOrder(raw, target, options.skip);
  var errors = [];
  for (var i = 0; i < providers.length; i++) {
    if (options.cancelled && options.cancelled()) throw new DOMException('页面已关闭', 'AbortError');
    var provider = providers[i];
    if (options.progress) options.progress('正在从' + libraryProviderLabels[provider] + '查找对应' + (kind === 'artist' ? '歌手' : '专辑') + '…');
    try {
      var resolved = target.provider === provider && target.id ? Object.assign({}, target, { name: kind === 'artist' ? artistName : albumName }) :
        await libraryCandidateTarget(kind, provider, raw, artistName, albumName, provider === origin);
      if (!resolved) continue;
      var url = libraryDetailUrl(kind, provider, resolved);
      if (!url) continue;
      var detail = await libraryFetch(url), info = detail[kind];
      if (!info || !(detail.songs || detail.tracks || []).length && !info.name) throw new Error('详情为空');
      var aliases = Array.isArray(info.aliases || info.alias) ? info.aliases || info.alias : [];
      if (kind === 'artist' && info.name && !librarySame(info.name, artistName) && !aliases.some(function (alias) { return librarySame(alias, artistName); })) continue;
      if (kind === 'album' && info.name && albumName && !librarySame(info.name, albumName)) continue;
      // Native IDs are authoritative; a searched album must also belong to the requested artist.
      if (kind === 'album' && provider !== origin && info.artist && !libraryArtists({ artist: info.artist }).some(function (entry) { return librarySame(entry.name, artistName); }) &&
        !(detail.songs || detail.tracks || []).some(function (song) { return libraryMatchCandidate(song, raw, kind, artistName, albumName); })) continue;
      return { provider: provider, target: Object.assign({}, resolved, { provider: provider, name: info.name || resolved.name, artist: artistName }), detail: detail };
    } catch (error) {
      if (error.name === 'AbortError') throw error;
      errors.push(libraryProviderLabels[provider] + '：' + error.message);
    }
  }
  throw new Error('未找到可以确认对应的' + (kind === 'artist' ? '歌手' : '专辑') + (errors.length ? '；' + errors.join('；') : '，请检查歌曲元数据'));
}

/* Public discovery only; each card carries the provider needed by its detail route. */
var librarySquareSources = { wy: 'netease', tx: 'qq', kg: 'kugou', kw: 'kuwo', mg: 'migu' };
function libraryPlaylistView(item, provider) {
  provider = provider || librarySquareSources[item.source] || item.provider;
  var id = item.id || item.playlistId || item.specialid || item.dissid;
  if (!provider || !id || item.public === false || item.isPrivate === true) return null;
  return { id: String(id), provider: provider, name: item.name || item.title || '未命名歌单',
    coverUrl: libraryCover(item.coverUrl || item.cover || item.picUrl || item.coverImgUrl || ''),
    creator: item.creator && typeof item.creator === 'object' ? item.creator.nickname || item.creator.name || '' : String(item.creator || ''),
    description: item.description || '', trackCount: Number(item.trackCount || item.songCount || 0), sourceLabel: libraryProviderLabels[provider] || provider };
}
async function libraryPublicPlaylists(data) {
  var target = data.target || {}, platform = target.platform || 'all', cursor = data.cursor || {};
  var more = !!data.append, jobs = [], labels = [];
  var squareKey = Object.keys(librarySquareSources).find(function (key) { return librarySquareSources[key] === platform; });
  if ((platform === 'all' || squareKey) && (!more || cursor.squareMore)) {
    labels.push('热门歌单广场');
    jobs.push(libraryFetch('/api/playlist/square?platform=' + (squareKey || 'all') + '&limit=12&offset=' + (Number(cursor.square) || 0) + '&keyword=' + encodeURIComponent(target.keyword || '')).then(function (result) {
      return { items: (result.items || []).map(function (item) { return libraryPlaylistView(item); }).filter(Boolean),
        statuses: result.sources || [], cursor: { square: (Number(cursor.square) || 0) + 12, squareMore: (result.sources || []).some(function (source) { return source.hasMore; }) } };
    }));
  }
  if ((platform === 'all' || platform === 'qishui') && !more) {
    labels.push('汽水');
    jobs.push(libraryFetch('/api/qishui/discover/mix').then(function (result) {
      var items = (result.playlists || []).map(function (item) { return libraryPlaylistView(item, 'qishui'); }).filter(Boolean);
      return { items: items, statuses: [{ source: 'qishui', label: '汽水', count: items.length, error: items.length ? '' : result.message || '当前没有可用的热门歌单' }], cursor: {} };
    }));
  }
  if ((platform === 'all' || platform === 'spotify') && (!more || cursor.spotifyMore)) {
    labels.push('Spotify');
    jobs.push(libraryFetch('/api/spotify/featured-playlists?limit=12&offset=' + (Number(cursor.spotify) || 0)).then(function (result) {
      var items = (result.playlists || []).map(function (item) { return libraryPlaylistView(item, 'spotify'); }).filter(Boolean);
      return { items: items, statuses: [{ source: 'spotify', label: 'Spotify', count: items.length, error: result.message || '' }],
        cursor: { spotify: (Number(cursor.spotify) || 0) + items.length, spotifyMore: result.hasMore === true || (Number(cursor.spotify) || 0) + items.length < Number(result.total || 0) } };
    }));
  }
  var settled = await Promise.allSettled(jobs), buckets = [], statuses = [], next = Object.assign({}, cursor, { squareMore: false, spotifyMore: false });
  settled.forEach(function (result, index) {
    if (result.status === 'fulfilled') { buckets.push(result.value.items); statuses.push.apply(statuses, result.value.statuses); Object.assign(next, result.value.cursor); }
    else { if (result.reason.name === 'AbortError') throw result.reason; statuses.push({ label: labels[index], error: result.reason.message }); }
  });
  var items = [], max = Math.max(0, ...buckets.map(function (bucket) { return bucket.length; }));
  for (var i = 0; i < max; i++) buckets.forEach(function (bucket) { if (bucket[i]) items.push(bucket[i]); });
  if (target.keyword) items = items.filter(function (item) { return libraryNorm(item.name + item.creator).includes(libraryNorm(target.keyword)); });
  return { publicPlaylists: items, sources: statuses, cursor: next, hasMore: !!(next.squareMore || next.spotifyMore), appendPublic: more, target: target };
}
async function libraryPlaylistDetail(data) {
  var target = data.target || {}, id = encodeURIComponent(target.id || ''), provider = target.provider;
  var paths = { netease: '/api/playlist/tracks?id=', qq: '/api/qq/playlist/tracks?id=',
    kuwo: '/api/kuwo/playlist/tracks?id=', migu: '/api/migu/playlist/tracks?id=',
    kugou: '/api/kugou/special-playlist-tracks?specialid=', qishui: '/api/qishui/playlist/tracks?id=', spotify: '/api/spotify/playlist/tracks?id=' };
  if (!id || !paths[provider]) throw new Error('歌单缺少来源或标识');
  var offset = Number(data.offset) || 0, limit = 50;
  var result = await libraryFetch(paths[provider] + id + '&limit=' + limit + '&offset=' + offset);
  var rows = result.tracks || result.songs || [], info = result.playlist || result.info || {};
  if (!rows.length && result.message) throw new Error(result.message);
  var playlist = Object.assign({}, target, { name: info.name || target.name, description: info.description || target.description,
    coverUrl: libraryCover(info.cover || info.coverImgUrl || target.coverUrl) });
  return { playlist: playlist, target: playlist, songs: rows.map(function (song) { return librarySongView(Object.assign({}, song, { provider: provider, source: provider })); }),
    appendSongs: !!data.append, nextOffset: Number(result.nextOffset) || offset + rows.length,
    hasMore: rows.length > 0 && (typeof result.hasMore === 'boolean' ? result.hasMore : offset + rows.length < Number(result.total || info.trackCount || target.trackCount || 0)),
    sourceLabel: libraryProviderLabels[provider] };
}

/* One transient backdrop state shared with presets; no host preferences are saved. */
var wallBackdropFrames = new WeakMap();
var wallBackdropObserved = new WeakSet();
function wallNativeBackdropFilter() {
  var renderer = window.renderer;
  if (!renderer || typeof renderer.render !== 'function') return;
  var record = window.__mrCoverWallNativeFilter;
  if (record && record.renderer === renderer) { record.active = !!window.__mrCoverWallBackdrop; return; }
  record = { renderer: renderer, original: renderer.render, active: true };
  record.wrapped = function (scene) {
    var backdrop = window.__mrCoverWallBackdrop;
    if (!record.active || !backdrop || backdrop.lyrics || scene !== window.scene) return record.original.apply(this, arguments);
    var objects = [window.stageLyrics && window.stageLyrics.group];
    if (window.fx && window.fx.particleLyrics) objects.push(window.particles, window.bloomParticles);
    var saved = [];
    objects.forEach(function (object) {
      if (!object || saved.some(function (entry) { return entry.object === object; })) return;
      saved.push({ object: object, visible: object.visible }); object.visible = false;
    });
    try { return record.original.apply(this, arguments); }
    finally { saved.forEach(function (entry) { entry.object.visible = entry.visible; }); }
  };
  renderer.render = record.wrapped;
  window.__mrCoverWallNativeFilter = record;
}
function wallSyncBackdrop() {
  var backdrop = window.__mrCoverWallBackdrop;
  var showText = !backdrop || backdrop.lyrics;
  // This also updates installed preset versions whose host adapter lacks the new event.
  document.querySelectorAll('iframe[data-mr-plugin]').forEach(function (element) {
    var match = /^(lumiere|pendolo|diorama|sonnet)-preset$/.exec(element.getAttribute('data-mr-plugin') || '');
    if (!match || !element.contentWindow) return;
    if (!wallBackdropObserved.has(element)) {
      wallBackdropObserved.add(element);
      element.addEventListener('load', function () { wallBackdropFrames.delete(element); wallSyncBackdrop(); }, { once: true });
    }
    var previous = wallBackdropFrames.get(element);
    if (previous === showText) return;
    wallBackdropFrames.set(element, showText);
    element.contentWindow.postMessage({ channel: 'mr-folia-' + match[1], type: 'appearance', song: { showText: showText } }, location.origin);
  });
  if (backdrop) wallNativeBackdropFilter();
  else {
    var record = window.__mrCoverWallNativeFilter;
    if (record) {
      record.active = false;
      if (record.renderer.render === record.wrapped) {
        record.renderer.render = record.original;
        delete window.__mrCoverWallNativeFilter;
      }
    }
  }
}
function wallSetBackdrop(data) {
  window.__mrCoverWallBackdrop = data.active ? { lyrics: !!data.lyrics, blur: !!data.blur } : null;
  if (frame) frame.style.background = 'transparent';
  window.dispatchEvent(new CustomEvent('mr-cover-wall-backdrop'));
  wallSyncBackdrop();
}

/* Catalog requests remain in the host, using its provider resolution and login session. */
var librarySongs = new Map(), libraryControllers = new Set(), libraryReturnPending = false;
function libraryProvider(song) {
  var provider = typeof window.songProviderKey === 'function' ? window.songProviderKey(song) : song.provider || song.source || 'netease';
  if (song.localKey || song.localFileId || song.type === 'local') return 'local';
  return ({ wy: 'netease', tx: 'qq', kg: 'kugou', kw: 'kuwo', mg: 'migu', qs: 'qishui', sp: 'spotify' })[provider] || provider || 'netease';
}
function libraryIdentity(song) {
  return libraryProvider(song) + '|' + (typeof window.queueItemKey === 'function' ? window.queueItemKey(song) : libraryProvider(song) + ':' + String(song.id || song.mid || song.url || song.name));
}
function libraryCover(url) {
  if (!url) return '';
  return /^https?:\/\//i.test(url) ? '/api/cover?url=' + encodeURIComponent(url) : String(url);
}
function librarySongView(song, context) {
  var raw = typeof window.cloneSong === 'function' ? window.cloneSong(song) : Object.assign({}, song);
  if (context) rememberLibraryReference(raw, context.kind, context.target);
  var base = libraryIdentity(raw), key = 'catalog:' + base;
  librarySongs.set(key, raw);
  if (librarySongs.size > 4000) librarySongs.delete(librarySongs.keys().next().value);
  var names = libraryArtists(raw).map(function (entry) { return entry.name; });
  var duration = number(raw.durationMs || raw.dt || raw.duration);

  return { _mrKey: key, _mrSongKey: base, id: raw.id, name: raw.name || raw.title || '未知歌曲',
    artists: artist(raw || {}), artistNames: names, album: libraryAlbumName(raw),
    durationMs: duration, coverUrl: libraryCover(typeof window.songCoverSrc === 'function' ? window.songCoverSrc(raw, 1024) : raw.cover), provider: libraryProvider(raw) };
}
function libraryOriginal(key) {
  if (librarySongs.has(key)) return librarySongs.get(key);
  var queue = queueSnapshot(), index = queue.findIndex(function (song) { return song._mrKey === key; });
  return index >= 0 ? window.playQueue[index] : null;
}
async function libraryFetch(url) {
  if (!alive || !frame) throw new DOMException('页面已关闭', 'AbortError');
  var controller = new AbortController(), timedOut = false, timer = setTimeout(function () { timedOut = true; controller.abort(); }, 22000);
  libraryControllers.add(controller);
  try {
    var response = await fetch(url, { credentials: 'same-origin', signal: controller.signal });
    var result = await response.json();
    if (!response.ok || result.error) throw new Error(result.error || '请求失败 (' + response.status + ')');
    return result;
  } catch (error) { if (timedOut) throw new Error('请求超时，请重试'); throw error; }
  finally { clearTimeout(timer); libraryControllers.delete(controller); }
}
function normalizeAlbum(album, provider) {
  var id = album.albumMid || album.mid || album.albumId || album.album_id || album.id;
  if (id == null || id === '') return null;
  var time = Number(album.publishTime || album.publishedAt || Date.parse(album.releaseDate || album.public_time || '') || 0), year = album.year || (time ? new Date(time).getFullYear() : '');
  return { id: String(id), provider: provider, name: album.name || album.albumName || album.album_name || '未知专辑',
    coverUrl: libraryCover(album.coverUrl || album.cover || album.picUrl || album.imgurl || ''),
    year: String(year || ''), trackCount: Number(album.trackCount || album.size || album.songCount || 0), artist: album.artist && typeof album.artist === 'object' ? album.artist.name || '' : album.artist || '',
    description: album.description || album.brief || '', genre: album.genre || '' };
}
async function libraryAlbumPage(target, offset) {
  var endpoint = target.provider === 'spotify' ? '/api/spotify/artist/albums?' : '/api/artist/albums?provider=' + encodeURIComponent(target.provider) + '&';
  var page = await libraryFetch(endpoint + 'id=' + encodeURIComponent(target.id) + '&offset=' + (Number(offset) || 0) + '&limit=30');
  return { albums: (page.albums || []).map(function (album) { return normalizeAlbum(Object.assign({}, album, { artist: album.artist || target.name }), target.provider); }).filter(Boolean), hasMore: !!page.hasMore, nextOffset: Number(page.nextOffset) || 0, albumError: page.supported === false ? (page.message || '当前来源暂未提供歌手专辑列表') : '' };
}
async function libraryLoad(data) {
  if (data.kind === 'playlists') return libraryPublicPlaylists(data);
  if (data.kind === 'playlist') return libraryPlaylistDetail(data);
  var raw = libraryOriginal(data.key), target = data.target || {}, source = frame;
  if (data.kind === 'artist-albums') {
    return Object.assign({ appendAlbums: true, albumTarget: target }, await libraryAlbumPage(target, data.offset));
  }
  if (!raw && !target.id && !target.name) throw new Error('这首歌曲已不在列表中，请重新打开');
  var progress = function (message) { if (alive && frame === source) post('library-progress', { requestId: data.requestId, message: message }); };
  var options = { progress: progress, cancelled: function () { return !alive || frame !== source; } };
  var resolved = await resolveLibraryDetail(data, raw, options), provider = resolved.provider, detail = resolved.detail;
  if (data.kind === 'artist') {
    var info = Object.assign({}, detail.artist), catalogTarget = Object.assign({}, resolved.target, {
      id: String(info.mid || info.singerid || info.artistId || info.id || resolved.target.id || ''), name: info.name || resolved.target.name,
    });
    var page = { albums: [], hasMore: false, nextOffset: 0, albumError: '' }, albumTarget = catalogTarget;
    var songViews = (detail.songs || []).map(function (song) {
      var copy = Object.assign({}, song, { provider: provider, source: provider });
      if (provider === 'kugou' && !copy.albumId && copy.cover === detail.artist.avatar) copy.cover = '';
      return librarySongView(copy, { kind: 'artist', target: catalogTarget });
    });
    info.avatar = libraryCover(info.avatar || info.cover);
    if (alive && frame === source) post('library-result', { requestId: data.requestId, partial: true,
      data: { target: catalogTarget, artist: info, sourceLabel: libraryProviderLabels[provider], songs: songViews } });
    try {
      page = await libraryAlbumPage(catalogTarget, 0);
      if (page.albumError || !page.albums.length) throw new Error(page.albumError || '当前平台没有返回专辑');
    } catch (error) {
      if (error.name === 'AbortError') throw error;
      var originalError = error;
      for (var i = 0; i < libraryDetailProviders.length; i++) {
        var alternate = libraryDetailProviders[i];
        if (alternate === provider) continue;
        try {
          var alt = await resolveLibraryDetail({ kind: 'artist', target: { provider: alternate, name: catalogTarget.name } }, null,
            Object.assign({}, options, { skip: libraryDetailProviders.filter(function (key) { return key !== alternate; }) }));
          var altTarget = Object.assign({}, alt.target, { id: String(alt.detail.artist.mid || alt.detail.artist.id || alt.target.id) });
          var altPage = await libraryAlbumPage(altTarget, 0);
          if (!altPage.albumError && altPage.albums.length) { page = altPage; albumTarget = altTarget; originalError = null; break; }
        } catch (altError) { if (altError.name === 'AbortError') throw altError; }
      }
      if (originalError) page.albumError = '专辑列表暂不可用：' + originalError.message;
    }
    return Object.assign({ target: catalogTarget, albumTarget: albumTarget, sourceLabel: libraryProviderLabels[provider], artist: info,
      albumSourceLabel: libraryProviderLabels[albumTarget.provider], songs: songViews }, page);
  }
  var albumInfo = normalizeAlbum(Object.assign({}, detail.album, { id: resolved.target.id || detail.album.id || resolved.target.trackId }), provider) || {};
  if (!albumInfo.name || albumInfo.name === '未知专辑') albumInfo.name = target.name || libraryAlbumName(raw) || '未知专辑';
  if (!albumInfo.coverUrl) albumInfo.coverUrl = libraryCover(target.coverUrl || (raw && provider === libraryProvider(raw) && typeof window.songCoverSrc === 'function' ? window.songCoverSrc(raw, 1024) : ''));
  if (!albumInfo.artist) albumInfo.artist = resolved.target.artist;
  return { target: resolved.target, sourceLabel: libraryProviderLabels[provider], album: albumInfo,
    songs: (detail.songs || detail.tracks || []).map(function (song) { return librarySongView(Object.assign({}, song, { provider: provider, source: provider }), { kind: 'album', target: resolved.target }); }) };
}
function clearLibraryRequests() {
  libraryControllers.forEach(function (controller) { controller.abort(); }); libraryControllers.clear(); librarySongs.clear();
  libraryResolvedRefs.clear();
  wallSetBackdrop({ active: false });
}
function libraryQueueIndex(raw) {
  var key = libraryIdentity(raw), queue = window.playQueue || [];
  for (var i = 0; i < queue.length; i++) if (libraryIdentity(queue[i]) === key) return i;
  return -1;
}
async function libraryPlay(keys, returnToPlayer) {
  if (returnToPlayer && libraryReturnPending) return;
  if (returnToPlayer) libraryReturnPending = true;
  try {
  var raws = keys.map(libraryOriginal).filter(Boolean);
  if (!raws.length) throw new Error('歌曲已失效，请重新打开页面');
  var indexes = raws.map(function (song) { var index = libraryQueueIndex(song); return index >= 0 ? index : window.queueSong(song); });
  var first = indexes[0];
  if (first === window.currentIdx) {
    if (!window.playing) await window.togglePlay();
  } else {
    var queued = queueSnapshot()[first];
    var result = await window.playQueueAt(first, { skipShuffleOrder: true, resumeAt: returnToPlayer && queued ? positions.get(queued._mrKey) || 0 : 0 });
    if (result === false) throw new Error('歌曲未能开始播放');
  }
  if (returnToPlayer) close(); else sync(true);
  } finally { if (returnToPlayer) libraryReturnPending = false; }
}
function handleLibraryMessage(data) {
  if (data.type === 'library-artists') {
    var original = libraryOriginal(data.key), seenArtists = new Set();
    var artists = libraryArtists(original).map(function (entry, index) { return { name: String(entry.name).trim(), index: index }; })
      .filter(function (entry) { var key = libraryNorm(entry.name); if (!key || seenArtists.has(key)) return false; seenArtists.add(key); return true; });
    post('library-artists-result', { requestId: data.requestId, data: { key: data.key, artists: artists } });
  } else if (data.type === 'library-request') {
    var source = frame;
    libraryLoad(data).then(function (result) { if (alive && frame === source) post('library-result', { requestId: data.requestId, data: result }); })
      .catch(function (error) { if (alive && frame === source && error.name !== 'AbortError') post('library-result', { requestId: data.requestId, error: error.message }); });
  } else if (data.type === 'library-play' || data.type === 'library-play-return' || data.type === 'library-play-scope') {
    libraryPlay(Array.isArray(data.keys) ? data.keys.slice(0, 500) : [data.key], data.type === 'library-play-return').catch(report);
  } else if (data.type === 'library-enqueue') {
    (data.keys || []).slice(0, 500).forEach(function (key) { var raw = libraryOriginal(key); if (raw && libraryQueueIndex(raw) < 0) window.queueSong(raw); }); sync(true);
  } else if (data.type === 'backdrop') {
    wallSetBackdrop(data);
  }
}

/* Queue identity and title follow the actual queue, not a merely browsed playlist. */
var queueLabels = window.__mrCoverWallQueueLabels;
if (!(queueLabels instanceof WeakMap)) queueLabels = window.__mrCoverWallQueueLabels = new WeakMap();
var originalQueuePlay = null, wrappedQueuePlay = null;
function rememberQueueLabel(queue, context) {
  if (!Array.isArray(queue) || !context || !context.playlistName) return;
  queueLabels.set(queue, {
    id: String(context.type || 'playlist') + ':' + String(context.playlistId || context.playlistName),
    title: String(context.playlistName), description: ''
  });
}
function installQueueLabelHook() {
  if (wrappedQueuePlay || typeof window.playQueueAt !== 'function') return;
  originalQueuePlay = window.playQueueAt;
  wrappedQueuePlay = function (index, options) {
    if (alive && Number.isInteger(Number(index)) && window.playQueue && window.playQueue[index]) {
      rememberQueueLabel(window.playQueue, options && options.context || window.playQueue[index].radioContext);
    }
    return originalQueuePlay.apply(this, arguments);
  };
  window.playQueueAt = wrappedQueuePlay;
}
function releaseQueueLabelHook() {
  if (window.playQueueAt === wrappedQueuePlay) window.playQueueAt = originalQueuePlay;
}
function queueInfoSnapshot() {
  var queue = window.playQueue || [], hydration = window.queueHydrationState;
  var hydrated = hydration && hydration.queueRef === queue;
  var remembered = queueLabels.get(queue);
  if (!remembered) {
    rememberQueueLabel(queue, window.activeRadioContext);
    remembered = queueLabels.get(queue);
  }
  if (hydrated && hydration.title) {
    remembered = { id: String(hydration.provider || '') + ':' + String(hydration.playlistId || hydration.title), title: String(hydration.title), description: '' };
    queueLabels.set(queue, remembered);
  }
  return {
    id: remembered && remembered.id || 'queue', title: remembered && remembered.title || '当前播放队列',
    description: remembered && remembered.description || '', total: hydrated ? Math.max(queue.length, Number(hydration.total) || 0) : queue.length,
    loading: !!(hydrated && hydration.loading), hasMore: !!(hydrated && hydration.hasMore), error: hydrated ? String(hydration.error || '') : ''
  };
}

/* Playlist metadata stays in the host; only titles, counts, covers and opaque IDs cross the frame. */
var queueCatalogEntries = new Map(), queueCatalogSelecting = false, queueCatalogToken = 0, queueCatalogCoverMap = null;
function queueCatalogRead(key) {
  try { var rows = JSON.parse(localStorage.getItem(key) || '[]'); return Array.isArray(rows) ? rows : []; }
  catch (_) { return []; }
}
function queueCatalogCustomCover(id) {
  if (id == null || id === '') return '';
  if (!queueCatalogCoverMap) {
    try {
      var stored = JSON.parse(localStorage.getItem('mineradio-playlist-custom-covers-v1') || '{}');
      queueCatalogCoverMap = stored && typeof stored === 'object' && !Array.isArray(stored) ? stored : {};
    } catch (_) { queueCatalogCoverMap = {}; }
  }
  return String(queueCatalogCoverMap[String(id)] || '');
}
// 封面优先级：自定义封面 > 歌单自身封面 > 首曲封面，与宿主的歌单卡片一致。
function queueCatalogRawCover(entry) {
  var custom = queueCatalogCustomCover(entry.sourceId);
  if (custom) return custom;
  var own = entry.cover || entry.coverImgUrl || entry.picUrl || entry.imgUrl;
  if (own) return String(own);
  var songs = entry.songs;
  if (!Array.isArray(songs)) return '';
  for (var index = 0; index < songs.length && index < 3; index += 1) {
    var song = songs[index] || {};
    var cover = song.customCover || song.cover || song.picUrl || song.img || song.image;
    if (cover) return String(cover);
  }
  return '';
}
// 缩略图复用宿主的封面尺寸工具与同源 /api/cover 代理，原始地址不外泄。
function queueCatalogCover(entry) {
  var raw = queueCatalogRawCover(entry);
  if (!raw) return '';
  var sized = typeof window.coverUrlWithSize === 'function' ? window.coverUrlWithSize(raw, 96) : raw;
  return libraryCover(sized);
}
function queueCatalogSnapshot() {
  var rows = [], seen = new Set();
  queueCatalogEntries.clear();
  queueCatalogCoverMap = null;
  function add(entry) {
    if (!entry || seen.has(entry.id)) return;
    seen.add(entry.id);
    queueCatalogEntries.set(entry.id, entry);
    rows.push({ id: entry.id, title: entry.title, source: entry.source, total: entry.total, current: !!entry.current, coverUrl: queueCatalogCover(entry) });
  }
  var queue = window.playQueue || [], current = queue[window.currentIdx], info = queueInfoSnapshot();
  add({ id: 'queue', title: info.title, source: '当前队列', total: info.total, current: true, songs: current ? [current] : [] });
  function stored(key, kind, source) {
    queueCatalogRead(key).forEach(function (item, index) {
      if (!item || !Array.isArray(item.songs)) return;
      add({ id: kind + ':' + String(item.id == null ? index : item.id), sourceId: item.id, title: String(item.name || item.title || '未命名歌单'), source: source,
        total: item.songs.length, songs: item.songs, kind: kind, cover: item.cover || item.coverImgUrl || '' });
    });
  }
  stored('mineradio-library-custom-v1', 'custom', '我的歌单');
  stored('mineradio-imported-platform-playlists-v1', 'imported', '导入歌单');
  (window.localPlaylists || []).forEach(function (item) {
    if (item && Array.isArray(item.songs)) add({ id: 'local-playlist:' + item.id, sourceId: item.id, title: String(item.name || '本地歌单'), source: '本地歌单', total: item.songs.length, songs: item.songs, kind: 'local-playlist', cover: item.cover || '' });
  });
  (window.userPlaylists || []).forEach(function (item) {
    if (!item || item.id == null) return;
    var provider = String(item.provider || item.source || 'netease');
    var source = typeof window.playlistProviderName === 'function' ? window.playlistProviderName(provider) : provider;
    add({ id: 'account:' + provider + ':' + item.id, sourceId: item.id, title: String(item.name || item.title || '我的歌单'), source: source,
      total: item.trackCount == null ? (Array.isArray(item.songs) ? item.songs.length : null) : Number(item.trackCount) || 0,
      provider: provider, playlistId: item.id, kind: 'account', cover: item.cover || '' });
  });
  var local = typeof window.homeDashboardLocalSongs === 'function' ? window.homeDashboardLocalSongs() : [];
  if (local.length) add({ id: 'local-files', title: '本地音乐', source: '本地音乐', total: local.length, songs: local, kind: 'local' });
  try {
    var daily = JSON.parse(localStorage.getItem('mineradio-daily-hot-30-cache-v1') || 'null');
    var now = new Date(), day = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
    if (daily && daily.date === day && Array.isArray(daily.songs) && daily.songs.length) add({ id: 'daily', title: '每日推荐', source: '今日推荐', total: daily.songs.length, songs: daily.songs, kind: 'daily' });
  } catch (_) { }
  return rows;
}
/**
 * 只等「首批歌单数据载入」，不等取流与播放。
 * 账号歌单走 autoplay=false：宿主失败时保留原队列，这里抛错让选择页留在原地；
 * 本地 / 导入歌单替换队列与歌单名之后即算载入成功。
 */
async function queueCatalogLoad(selection) {
  // Resolve against fresh host data, so a deleted/reordered playlist cannot select another entry.
  queueCatalogSnapshot();
  var entry = queueCatalogEntries.get(selection.id);
  if (!entry) throw new Error('歌单已改变，请重新选择');
  if (entry.current) return null;
  if (entry.kind === 'account') {
    if (typeof window.loadPlaylistIntoQueueById !== 'function' || typeof window.playlistPanelProviderId !== 'function') throw new Error('当前宿主缺少歌单加载接口');
    var providerId = window.playlistPanelProviderId(entry.provider, entry.playlistId);
    var before = window.playQueue;
    await window.loadPlaylistIntoQueueById(providerId, false, entry.title, { preserveHomeState: true });
    var queue = window.playQueue;
    // 返回值之外再核对队列本身：宿主在「首批载入成功、界面刷新失败」时返回 false，但队列已经换好。
    var replaced = Array.isArray(queue) && queue.length > 0 && queue !== before;
    if (!replaced) throw new Error('歌单未能载入，请重试');
    var context = { type: 'cover-wall', playlistId: entry.id, playlistName: entry.title };
    rememberQueueLabel(queue, context);
    return { queue: queue, context: context, index: 0, options: { preserveHomeState: true } };
  }
  if (!entry.songs || !entry.songs.length) throw new Error('这个歌单还没有歌曲');
  if (typeof window.playQueueAt !== 'function') throw new Error('当前宿主缺少播放接口');
  if (typeof window.cancelPlaylistQueueHydration === 'function') window.cancelPlaylistQueueHydration('cover-wall-playlist');
  var songs = entry.songs.map(function (song) {
    var copy = typeof window.cloneSong === 'function' ? window.cloneSong(song) : Object.assign({}, song);
    if (copy.type !== 'local') copy.type = 'online-queue';
    return copy;
  });
  window.playQueue = songs;
  window.currentIdx = 0;
  var localContext = { type: 'cover-wall', playlistId: entry.id, playlistName: entry.title };
  rememberQueueLabel(songs, localContext);
  if (typeof window.safeRenderQueuePanel === 'function') window.safeRenderQueuePanel('cover-wall-playlist', { animate: false });
  if (typeof window.safeShelfRebuild === 'function') window.safeShelfRebuild('cover-wall-playlist', true);
  return { queue: songs, context: localContext, index: 0, options: { manual: true, context: localContext, skipShuffleOrder: true, preserveHomeState: true } };
}
// 首曲在墙面已经换好之后才启动：取流慢或失败只补一条提示，不再挂着选择页。
function queueCatalogStart(selection, loaded) {
  if (!loaded) return;
  if (typeof window.playQueueAt !== 'function') { queueCatalogNotice(selection, '歌单已载入，当前宿主缺少播放接口'); return; }
  Promise.resolve().then(function () {
    // 队列已被别的歌单或宿主操作替换时放弃，避免迟到的旧请求覆盖新队列或误播。
    if (!alive || frame !== selection.frame || selection.token !== queueCatalogToken || window.playQueue !== loaded.queue) return null;
    return window.playQueueAt(loaded.index || 0, loaded.options);
  }).then(function (started) {
    if (started === false) queueCatalogNotice(selection, '歌单已载入，首曲未能开始播放，可在歌曲列表里选择其他歌曲');
  }).catch(function (error) {
    queueCatalogNotice(selection, '歌单已载入，首曲未能开始播放' + (error && error.message ? '：' + error.message : ''));
  });
}
function queueCatalogNotice(selection, text) {
  if (!alive || frame !== selection.frame || selection.token !== queueCatalogToken) return;
  post('queue-select-notice', { requestId: selection.requestId, text: text });
}
function handleQueueCatalogMessage(data) {
  var source = frame;
  // 用户取消：让在途选择的结果失效（不再回报成功、不再启动首曲），旧请求也不能覆盖下一次选择。
  if (data.type === 'queue-select-cancel') {
    if (queueCatalogSelecting) { queueCatalogToken += 1; queueCatalogSelecting = false; }
    return;
  }
  if (data.type === 'queue-catalog') {
    post('queue-catalog-result', { requestId: data.requestId, rows: queueCatalogSnapshot() });
    // Cached rows are shown immediately; account hydration may complete independently.
    if (!(window.userPlaylists || []).length && typeof window.refreshUserPlaylists === 'function') {
      Promise.resolve().then(function () { return window.refreshUserPlaylists(false); }).then(function () {
        if (alive && frame === source) post('queue-catalog-result', { requestId: data.requestId, rows: queueCatalogSnapshot() });
      }).catch(function (error) {
        if (alive && frame === source) post('queue-catalog-result', { requestId: data.requestId, rows: queueCatalogSnapshot(), error: '账号歌单暂未载入：' + error.message });
      });
    }
    return;
  }
  if (queueCatalogSelecting) { post('queue-select-result', { requestId: data.requestId, error: '正在切换歌单，请稍候' }); return; }
  queueCatalogSelecting = true;
  // token 标记这一次选择：晚到的旧请求、旧 iframe 的结果都不能覆盖新歌单。
  var selection = { token: ++queueCatalogToken, requestId: data.requestId, frame: source, id: String(data.id || '') };
  queueCatalogLoad(selection).then(function (loaded) {
    if (!alive || frame !== selection.frame || selection.token !== queueCatalogToken) return;
    // 先报成功并刷新快照，让选择态收起、墙面换成新歌单，再单独启动首曲。
    sync(true);
    post('queue-select-result', { requestId: selection.requestId });
    queueCatalogSelecting = false;
    queueCatalogStart(selection, loaded);
  }).catch(function (error) {
    if (!alive || frame !== selection.frame || selection.token !== queueCatalogToken) return;
    sync(true);
    post('queue-select-result', { requestId: selection.requestId, error: String(error && error.message || error) });
  }).finally(function () {
    if (selection.token === queueCatalogToken) queueCatalogSelecting = false;
  });
}

/* 独立封面选歌插件；进入后隐藏宿主搜索栏、播放栏，退出后恢复。 */
var ID = 'cover-wall', CHANNEL = 'mr-cover-wall';
var alive = true, button = null, frame = null, ready = false, signature = '', queueVersion = '';
var lyricsSignature = '', hideStyle = null;
var appearanceSignature = '';
var appearanceMeasuredAt = 0;
var returnPending = false;
var positions = new Map(), snapshotQueue = [], snapshotIndex = -1;
function post(type, data) {
  if (frame && frame.contentWindow) frame.contentWindow.postMessage(Object.assign({ channel: CHANNEL, type: type }, data || {}), location.origin);
}
function number(value) { var n = Number(value); return isFinite(n) ? n : 0; }
function artist(song) {
  if (typeof song.artist === 'string' && song.artist) return song.artist;
  var artists = song.artists || song.ar;
  return Array.isArray(artists) ? artists.map(function (item) { return typeof item === 'string' ? item : item.name || ''; }).filter(Boolean).join(' / ') : '';
}
function queueSnapshot() {
  var occurrences = Object.create(null);
  return (Array.isArray(window.playQueue) ? window.playQueue : []).map(function (song) {
    song = song || {};
    var base = libraryIdentity(song);
    var occurrence = occurrences[base] || 0; occurrences[base] = occurrence + 1;
    var cover = typeof window.songCoverSrc === 'function' ? window.songCoverSrc(song, 1024) : song.cover || '';
    var coverSizes = {};
    [128, 256, 512, 1024].forEach(function (size) { coverSizes[size] = typeof window.songCoverSrc === 'function' ? String(window.songCoverSrc(song, size) || '') : String(cover || ''); });
    var ms = number(song.durationMs || song.dt);
    if (!ms) { var raw = number(song.duration); ms = raw > 10000 ? raw : raw * 1000; }
    return { _mrKey: JSON.stringify([base, occurrence]), _mrSongKey: libraryIdentity(song), id: song.id, name: String(song.name || song.title || '未知歌曲'), artists: artist(song), album: libraryAlbumName(song), coverUrl: String(cover || ''), coverSizes: coverSizes, durationMs: ms };
  });
}
function sync(force) {
  if (!frame || !ready) return;
  var queue = queueSnapshot();
  var snapshot = { queue: queue, queueInfo: queueInfoSnapshot(), currentIndex: number(window.currentIdx == null ? -1 : window.currentIdx), playing: !!window.playing, duration: typeof window.getPlaybackDurationSeconds === 'function' ? number(window.getPlaybackDurationSeconds()) : number(window.audio && window.audio.duration) };
  var encoded = JSON.stringify(snapshot);
  queueVersion = JSON.stringify(queue);
  snapshotQueue = queue; snapshotIndex = snapshot.currentIndex;
  if (force || encoded !== signature) { signature = encoded; post('snapshot', { snapshot: snapshot }); }
  syncLyrics(queue[snapshot.currentIndex] && queue[snapshot.currentIndex]._mrKey || null, force);
  syncAppearance(force);
  syncClock();
}
function syncClock() {
  if (!frame || !ready || document.hidden) return;
  var time = typeof window.getPlaybackCurrentSeconds === 'function' ? number(window.getPlaybackCurrentSeconds()) : number(window.audio && window.audio.currentTime);
  if (snapshotIndex === window.currentIdx && snapshotQueue[snapshotIndex] && time > 0) {
    var matches = typeof window.playbackMediaMatchesCurrentQueueItem !== 'function' || window.playbackMediaMatchesCurrentQueueItem(window.audio);
    if (matches) positions.set(snapshotQueue[snapshotIndex]._mrKey, time);
  }
  var lyricTime = typeof window.getAdjustedLyricPlaybackTime === 'function' ? number(window.getAdjustedLyricPlaybackTime(time)) : time;
  post('clock', { time: time, lyricTime: lyricTime });
}
function close() {
  clearLibraryRequests();
  queueCatalogEntries.clear();
  if (frame) frame.remove();
  frame = null; ready = false; signature = ''; queueVersion = ''; lyricsSignature = ''; appearanceSignature = '';
  document.documentElement.classList.remove('mr-cover-wall-open');
  if (hideStyle) { hideStyle.remove(); hideStyle = null; }
  if (button) { button.setAttribute('aria-pressed', 'false'); button.classList.remove('active'); button.title = '封面选歌'; }
}
function open() {
  if (!alive || frame) return;
  hideStyle = document.createElement('style');
  hideStyle.setAttribute('data-mr-plugin', ID);
  hideStyle.textContent = 'html.mr-cover-wall-open #search-area,html.mr-cover-wall-open #bottom-bar,html.mr-cover-wall-open #bottom-handle,html.mr-cover-wall-open #fx-fab,html.mr-cover-wall-open #fx-fab-hide-btn,html.mr-cover-wall-open #fx-panel{opacity:0!important;visibility:hidden!important;pointer-events:none!important;}';
  document.head.appendChild(hideStyle);
  document.documentElement.classList.add('mr-cover-wall-open');
  frame = document.createElement('iframe');
  frame.setAttribute('data-mr-plugin', ID);
  frame.title = '封面选歌';
  frame.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;border:0;z-index:4;background:transparent;';
  frame.src = '/api/plugins/' + ID + '/resource?path=wall.html&v=mvdpo12q';
  document.body.appendChild(frame);
  button.setAttribute('aria-pressed', 'true'); button.classList.add('active'); button.title = '退出封面选歌';
}
function toggleWall(event) { event.preventDefault(); event.stopPropagation(); if (frame) close(); else open(); }
function attach() {
  if (!alive) return;
  installQueueLabelHook();
  var lyrics = document.getElementById('lyrics-toggle-btn');
  if (!lyrics || !lyrics.parentNode) return;
  var anchor = lyrics.closest('#lyric-timing-control') || lyrics;
  if (button && button.isConnected && button.parentNode === anchor.parentNode) return;
  if (button) { button.removeEventListener('click', toggleWall); button.remove(); }
  button = document.createElement('button');
  button.id = 'cover-wall-toggle-btn'; button.type = 'button';
  button.className = 'ctrl-btn lyrics-toggle-btn'; button.title = frame ? '退出封面选歌' : '封面选歌';
  button.setAttribute('aria-label', '封面选歌'); button.setAttribute('aria-pressed', String(!!frame));
  button.setAttribute('data-mr-plugin', ID);
  var word = document.createElement('span'); word.className = 'lyrics-word-icon'; word.textContent = '封'; button.appendChild(word);
  button.addEventListener('click', toggleWall); anchor.parentNode.insertBefore(button, anchor);
}
function report(error) {
  console.error('[封面选歌]', error);
  if (typeof window.showToast === 'function') window.showToast('封面选歌：' + (error && error.message || String(error)));
}
function call(name, args) {
  if (typeof window[name] !== 'function') throw new Error('当前宿主缺少 ' + name + ' 接口');
  Promise.resolve(window[name].apply(window, args || [])).catch(report);
}
function currentKeyMatches(key) {
  var queue = queueSnapshot(), current = queue[window.currentIdx];
  return !!current && current._mrKey === key;
}
function onMessage(event) {
  if (!alive || !frame || event.source !== frame.contentWindow || event.origin !== location.origin) return;
  var data = event.data;
  if (!data || data.channel !== CHANNEL) return;
  try {
    if (data.type === 'ready') { ready = true; sync(true); }
    else if (data.type.indexOf('library-') === 0 || data.type === 'backdrop') handleLibraryMessage(data);
    else if (data.type === 'close') close();
    else if (data.type === 'play' || data.type === 'play-return') {
      var queue = queueSnapshot();
      // 列表已改变时拒绝旧卡片指令，防止重复曲目或重排后播错歌。
      if (JSON.stringify(queue) !== queueVersion) { sync(true); return; }
      var index = Number(data.queueIndex);
      if (!Number.isInteger(index) || !queue[index] || queue[index]._mrKey !== data.key) { sync(true); return; }
      if (data.type === 'play-return') {
        if (returnPending) return;
        if (typeof window.playQueueAt !== 'function') throw new Error('当前宿主缺少播放接口');
        var sourceFrame = frame;
        returnPending = true;
        Promise.resolve().then(function () {
          if (index === window.currentIdx) {
            if (!window.playing && typeof window.togglePlay === 'function') return window.togglePlay();
            return true;
          }
          return window.playQueueAt(index, { skipShuffleOrder: true, resumeAt: positions.get(data.key) || 0 });
        }).then(function (result) {
          if (result === false) { report(new Error('歌曲未能开始播放')); return; }
          if (alive && frame === sourceFrame) close();
        }).catch(report).finally(function () { returnPending = false; });
      } else call('playQueueAt', [index, { skipShuffleOrder: true }]);
    }
    else if (data.type === 'toggle' && currentKeyMatches(data.key)) call('togglePlay');
    else if (data.type === 'prev') call('prevTrack', [true]);
    else if (data.type === 'next') call('nextTrack', [true]);
    else if (data.type === 'queue-catalog' || data.type === 'queue-select' || data.type === 'queue-select-cancel') {
      try { handleQueueCatalogMessage(data); }
      catch (catalogError) { post(data.type + '-result', { requestId: data.requestId, error: catalogError.message }); }
    }
    else if (data.type === 'queue-more') {
      var hydration = window.queueHydrationState;
      if (hydration && hydration.queueRef === window.playQueue && hydration.hasMore && !hydration.loading) {
        if (hydration.error && typeof window.retryPlaylistQueueHydration === 'function') call('retryPlaylistQueueHydration');
        else call('requestPlaylistQueueHydrationForBrowse');
      }
    }
    else if (data.type === 'seek' && isFinite(data.time) && currentKeyMatches(data.key)) call('commitProgressSeek', [Number(data.time), !!window.playing]);
    else if (data.type === 'error') report(new Error(String(data.message || '界面加载失败')));
  } catch (error) { report(error); }
}
window.addEventListener('message', onMessage);
var timer = api.timer.setInterval(function () { if (!alive) return; attach(); if (!document.hidden) { sync(false); if (frame) wallSyncBackdrop(); } }, 200);
var clockTimer = api.timer.setInterval(function () { if (alive) syncClock(); }, 50);
api.ready(attach);
return function () {
  alive = false; clearInterval(timer); clearInterval(clockTimer); window.removeEventListener('message', onMessage); close();
  releaseQueueLabelHook();
  if (button) { button.removeEventListener('click', toggleWall); button.remove(); button = null; }
};
