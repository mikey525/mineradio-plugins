Folia 0.7.19 原作者 chthollyphile，AGPL-3.0。本插件适配层同样按 AGPL-3.0 分发；对应 Folia 源码、适配源码、依赖清单及构建脚本见本次随附源码包。第三方许可见 *.LEGAL.txt。
