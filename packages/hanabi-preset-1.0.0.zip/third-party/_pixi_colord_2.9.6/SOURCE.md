@pixi/colord 2.9.6 declares MIT and repository omgovich/colord, but its installed npm package omits a license file.

LICENSE.md is copied verbatim from the declared upstream repository:
https://github.com/omgovich/colord/blob/master/LICENSE.md
Git blob SHA-1: e437003733acd123c76c2a9df0c13a6f3b02b51e
Retrieved 2026-11-03.
