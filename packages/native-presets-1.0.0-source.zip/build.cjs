const fs = require('node:fs'), path = require('node:path');
const base = __dirname;
const specs = JSON.parse(fs.readFileSync(path.join(base, 'presets.json'), 'utf8'));

// 预设专属参数面板：控件与行为全部由插件自带（与参考插件 host-main.js 的思路一致，
// 宿主只保留 fx 参数与按预设隔离的存储）。
const PANEL_BASE = [
  { key: 'intensity', label: '律动强度', type: 'range', min: 0.2, max: 1.6, step: 0.01 },
  { key: 'depth', label: '画面景深', type: 'range', min: 0.2, max: 1.8, step: 0.01 },
  { key: 'coverResolution', label: '封面清晰度', type: 'range', min: 0.75, max: 1.55, step: 0.01 },
  { key: 'cinemaShake', label: '镜头晃动', type: 'range', min: 0, max: 1.8, step: 0.01 },
  { key: 'cinema', label: '电影镜头', type: 'toggle' }
];
const PANEL_PARTICLES = [
  { key: 'floatLayer', label: '浮空粒子层', type: 'toggle' },
  { key: 'bloom', label: '粒子溢光', type: 'toggle' },
  { key: 'edge', label: '轮廓高亮', type: 'toggle' },
  { key: 'backgroundStarRiver', label: '背景星河', type: 'toggle' },
  { key: 'point', label: '粒子尺寸', type: 'range', min: 0.5, max: 2.2, step: 0.01 },
  { key: 'speed', label: '运动速度', type: 'range', min: 0.2, max: 2.5, step: 0.01 },
  { key: 'twist', label: '粒子扭曲', type: 'range', min: 0, max: 0.6, step: 0.01 },
  { key: 'color', label: '色彩张力', type: 'range', min: 0.5, max: 2.0, step: 0.01 },
  { key: 'bloomStrength', label: '光晕强度', type: 'range', min: 0, max: 1.6, step: 0.01 },
  { key: 'scatter', label: '离散感', type: 'range', min: 0, max: 0.5, step: 0.01 },
  { key: 'bgFade', label: '背景压暗', type: 'range', min: 0, max: 1.2, step: 0.01 }
];
const PANEL_COMMON_GROUPS = [
  { title: '基础画面', controls: PANEL_BASE },
  { title: '粒子与光影', controls: PANEL_PARTICLES }
];
const PANEL_REQUIEM_GROUPS = [
  { title: '粒子与光影', controls: [PANEL_PARTICLES[4], PANEL_PARTICLES[7], PANEL_PARTICLES[8]] }
];

function controlMarkup(control) {
  if (control.type === 'toggle') {
    return '<div class="fx-toggle-grid"><div class="fx-toggle" data-mr-preset-toggle="' + control.key + '">' +
      '<span>' + control.label + '</span><span class="dot"></span></div></div>';
  }
  return '<div class="fx-slider"><label>' + control.label + '</label>' +
    '<input data-mr-preset-range="' + control.key + '" type="range" min="' + control.min + '" max="' + control.max + '" step="' + control.step + '"><output></output></div>';
}

function groupsMarkup(groups) {
  return groups.map(group =>
    (group.title ? '<div class="fx-section-label">' + group.title + '</div>' : '') +
    (group.controls || []).map(controlMarkup).join('')
  ).join('');
}

// 面板行为：按钮展开/收起、参数读写、恢复默认、选中预设才显示、卸载清理。
function panelScript(index, label, html) {
  return `
(function () {
  if (typeof document === 'undefined') return;
  var grid = document.getElementById('preset-grid');
  if (!grid || !grid.parentNode) return;
  var section = document.createElement('section');
  section.setAttribute('data-mr-preset-panel', '${index}');
  section.style.cssText = 'display:none;margin:12px 0';
  var button = document.createElement('button');
  button.type = 'button';
  button.setAttribute('data-mr-preset-panel-toggle', '');
  button.textContent = ${JSON.stringify(label + '参数设置')};
  button.style.cssText = 'padding:10px 16px;border-radius:9px;color:#eee;background:#222b39;border:1px solid #5c6370;width:100%';
  var body = document.createElement('div');
  body.className = 'mr-preset-panel-body';
  body.style.cssText = 'display:none;margin-top:8px;max-height:65vh;overflow:auto;background:#090b10;border:1px solid rgba(255,255,255,.10);border-radius:12px;padding:10px 12px';
  body.innerHTML = ${JSON.stringify(html)};
  var resetRow = document.createElement('div');
  resetRow.className = 'fx-actions';
  resetRow.style.cssText = 'margin-top:10px;padding-top:8px;border-top:1px solid rgba(255,255,255,.10)';
  var resetButton = document.createElement('button');
  resetButton.type = 'button';
  resetButton.className = 'fx-mini-btn ghost';
  resetButton.setAttribute('data-mr-preset-reset', '');
  resetButton.textContent = '恢复默认';
  resetRow.appendChild(resetButton);
  body.appendChild(resetRow);

  function refreshHost() {
    if (typeof updateFxInputs === 'function') updateFxInputs();
    if (typeof updateSonicGroundColorControls === 'function') updateSonicGroundColorControls();
    if (typeof updateSonicWorkshopColorControls === 'function') updateSonicWorkshopColorControls();
    if (typeof bindSonicAudioMonitorControls === 'function') bindSonicAudioMonitorControls();
    if (typeof refreshSonicAudioMonitorUi === 'function') refreshSonicAudioMonitorUi();
  }
  function syncValues() {
    body.querySelectorAll('[data-mr-preset-range]').forEach(function (input) {
      var key = input.getAttribute('data-mr-preset-range');
      var value = presetFxParamValue(key);
      input.value = value;
      var out = input.parentElement && input.parentElement.querySelector('output');
      if (out) out.textContent = String(value);
    });
    body.querySelectorAll('[data-mr-preset-toggle]').forEach(function (el) {
      el.classList.toggle('on', !!presetFxParamValue(el.getAttribute('data-mr-preset-toggle')));
    });
  }
  button.addEventListener('click', function () {
    var open = body.style.display !== 'none';
    body.style.display = open ? 'none' : '';
    button.classList.toggle('active', !open);
    if (!open) syncValues();
  });
  resetButton.addEventListener('click', function () {
    if (typeof resetPresetFxProfile === 'function') resetPresetFxProfile(${index});
    body.querySelectorAll('[data-preset-key]').forEach(function (input) {
      var key = input.getAttribute('data-preset-key');
      if (typeof fxDefaults !== 'undefined' && typeof fxDefaults[key] !== 'undefined') fx[key] = fxDefaults[key];
    });
    if (typeof sonicAudioNormalizeFx === 'function') sonicAudioNormalizeFx(fx);
    if (typeof syncFxUniforms === 'function') syncFxUniforms();
    if (typeof saveLyricLayout === 'function') saveLyricLayout({ user: true, reason: 'preset-panel-reset' });
    syncValues();
    refreshHost();
    if (typeof showToast === 'function') showToast('已恢复该预设的默认参数');
  });
  body.querySelectorAll('[data-mr-preset-range]').forEach(function (input) {
    input.addEventListener('input', function () {
      setPresetFxParam(input.getAttribute('data-mr-preset-range'), parseFloat(input.value));
      syncValues();
    });
  });
  body.querySelectorAll('[data-mr-preset-toggle]').forEach(function (el) {
    el.addEventListener('click', function () {
      var key = el.getAttribute('data-mr-preset-toggle');
      setPresetFxParam(key, !presetFxParamValue(key));
      syncValues();
    });
  });
  body.querySelectorAll('[data-preset-key]').forEach(function (input) {
    input.addEventListener('input', function () {
      var key = input.getAttribute('data-preset-key');
      var value = input.type === 'range' ? Number(input.value) : input.value;
      if (input.type === 'range' && !isFinite(value)) return;
      fx[key] = value;
      if (/^sonicAudio/.test(key) && typeof sonicAudioNormalizeFx === 'function') sonicAudioNormalizeFx(fx);
      if (typeof syncFxUniforms === 'function') syncFxUniforms();
      if (typeof saveLyricLayout === 'function') saveLyricLayout({ user: true, reason: 'preset-panel' });
      var out = input.parentElement && input.parentElement.querySelector('output');
      if (out) out.textContent = input.type === 'range' ? String(value) : String(value).toUpperCase();
    });
  });

  section.appendChild(button);
  section.appendChild(body);
  grid.parentNode.insertBefore(section, grid.nextSibling);
  var wasActive = false;
  function updateActive() {
    var active = Number(window.fx && fx.preset) === ${index};
    section.style.display = active ? '' : 'none';
    if (active && !wasActive) { refreshHost(); syncValues(); }
    if (!active) { body.style.display = 'none'; button.classList.remove('active'); }
    wasActive = active;
  }
  api.timer.setInterval(updateActive, 300);
  if (api.hook && typeof api.hook.after === 'function') {
    try { api.hook.after('setPreset', function () { updateActive(); }); } catch (e) { }
  }
  api._uninstallers.push(function () { if (section.parentNode) section.parentNode.removeChild(section); });
  updateActive();
})();
`;
}

const workshopHtml = path.join(base, 'native-sonic-workshop-preset/vendor/sonic-workshop/mineradio-bridge.html');
fs.writeFileSync(workshopHtml, fs.readFileSync(workshopHtml, 'utf8').replace(/(src|href)="(assets\/[^"\s]+)"/g,
  '$1="/api/plugins/native-sonic-workshop-preset/resource?path=vendor/sonic-workshop/$2"'));
for (const spec of specs) {
  const dir = path.join(base, spec.id);
  let implementation = '', payload = '', dispose = '';
  if (spec.index < 6) payload = ', vertexShader: '+JSON.stringify(fs.readFileSync(path.join(dir, 'vertex.glsl'), 'utf8'));
  if (spec.index === 6) {
    implementation = 'var skullRenderer = (function () {\n'+fs.readFileSync(path.join(dir, 'renderer.js'), 'utf8')+'\n})();\n';
    payload = ', skull: skullRenderer';
    dispose = `skullRenderer.clearSkullPresetResidue();
      if (window.skullParticleGroup) {
        scene.remove(skullParticleGroup);
        skullParticleGroup.geometry.dispose();
        skullParticleGroup.material.dispose();
        skullParticleGroup = null;
      }
      skullParticleAsset = { data: null, promise: null, failed: false };`;
  }
  if (spec.index >= 7) {
    implementation = fs.readFileSync(path.join(dir, 'renderer.js'), 'utf8')+'\n';
    const globalName=spec.index===7?'MineradioSonicTopography':'MineradioSonicWorkshop';
    dispose = `if (window.${globalName}) {
      var instance = window.${globalName};
      if (instance.dispose) instance.dispose(); else instance.clear();
      delete window.${globalName};
    }`;
  }
  let panelHtml = '';
  if (spec.index >= 0 && spec.index <= 5) panelHtml = groupsMarkup(PANEL_COMMON_GROUPS);
  else if (spec.index === 6) panelHtml = groupsMarkup(PANEL_REQUIEM_GROUPS);
  else panelHtml = fs.readFileSync(path.join(dir, 'panel.html'), 'utf8');

  const code = `/* Mineradio optional native visual preset. Original authors retained in manifest. */
MineradioPlugins.register(${JSON.stringify(spec.manifest)}, function (api) {
  var registry = window.MineradioVisualPresets;
  if (!registry) throw new Error('请安装配套的虚空核心版 Mineradio');
  ${implementation}
  var disposePreset = registry.register({ index: ${spec.index}, id: ${JSON.stringify(spec.id)}, meta: ${JSON.stringify(spec.meta)}, icon: ${JSON.stringify(spec.icon)}${payload}, dispose: function () { ${dispose} } });
  ${panelScript(spec.index, spec.meta.name, panelHtml)}
  return disposePreset;
});
`;
  new Function('MineradioPlugins', code);
  fs.writeFileSync(path.join(dir, 'main.js'), code);
  console.log(spec.manifest.name+': '+Buffer.byteLength(code)+' bytes');
}
