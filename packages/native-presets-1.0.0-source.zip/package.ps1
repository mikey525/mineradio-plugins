﻿param([Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$taskBase = $PSScriptRoot
$taskOutput = [IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Force -Path $taskOutput | Out-Null

# Keep installation archives flat so the host finds manifest.json at the root.
function Write-TaskZip([string]$taskZipPath, [string]$taskRoot, [object[]]$taskFiles) {
    $taskTemp = $taskZipPath + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    $taskZip = [System.IO.Compression.ZipFile]::Open($taskTemp, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($taskFile in $taskFiles) {
            $taskEntry = $taskFile.FullName.Substring($taskRoot.Length).TrimStart('\','/').Replace('\','/')
            [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($taskZip, $taskFile.FullName, $taskEntry, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
        }
    } finally { $taskZip.Dispose() }
    Move-Item -LiteralPath $taskTemp -Destination $taskZipPath -Force
}

$taskSpecs = Get-Content -LiteralPath (Join-Path $taskBase 'presets.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($taskSpec in $taskSpecs) {
    $taskRoot = Join-Path $taskBase $taskSpec.id
    $taskManifest = Get-Content -LiteralPath (Join-Path $taskRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($taskManifest.id -ne $taskSpec.id) { throw "Unexpected plugin identity: $($taskSpec.id)" }
    if ($taskManifest.version -ne '1.0.0') { throw "Unexpected plugin version: $($taskSpec.id)" }
    foreach ($taskRequired in @('manifest.json','entry.json','main.js','LICENSE','NOTICE.md')) {
        if (-not (Test-Path -LiteralPath (Join-Path $taskRoot $taskRequired))) { throw "$($taskSpec.id) is missing $taskRequired" }
    }
    $taskFiles = @(Get-ChildItem -LiteralPath $taskRoot -File -Recurse | Where-Object { $_.Name -notlike '*.map' })
    Write-TaskZip (Join-Path $taskOutput "$($taskSpec.id)-1.0.0.zip") $taskRoot $taskFiles
}

$taskSourceFiles = @(Get-ChildItem -LiteralPath $taskBase -File | Where-Object {
    $_.Name -in @('presets.json','build.cjs','package.ps1','README.md')
})
foreach ($taskFolder in $taskSpecs.id) {
    $taskSourceFiles += @(Get-ChildItem -LiteralPath (Join-Path $taskBase $taskFolder) -File -Recurse | Where-Object {
        $_.Name -notlike 'main.js' -and $_.Name -notlike '*.map'
    })
}
Write-TaskZip (Join-Path $taskOutput 'native-presets-1.0.0-source.zip') $taskBase $taskSourceFiles
if (Test-Path -LiteralPath (Join-Path $taskBase 'README.md')) {
    Copy-Item -LiteralPath (Join-Path $taskBase 'README.md') -Destination (Join-Path $taskOutput '安装与更新说明.md')
}
$taskHashes = Get-ChildItem -LiteralPath $taskOutput -Filter '*.zip' -File | Sort-Object Name | ForEach-Object {
    $taskHash = Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256
    "$($taskHash.Hash.ToLowerInvariant())  $($_.Name)"
}
[IO.File]::WriteAllLines((Join-Path $taskOutput 'SHA256.txt'), $taskHashes)
Get-ChildItem -LiteralPath $taskOutput -File | Select-Object Name,Length
