# Mineradio 内置视觉预设独立插件 1.0.0

从 Mineradio **2.4.3（虚空核心版）** 拆出的 8 个原生视觉预设，主程序只保留「虚空」预设和公共粒子、歌词、场景接口。插件可单独安装、启用、停用与卸载，无需重打 APK。

## 拆分清单

| 插件 ID | 预设 | 索引 | 作者 |
| --- | --- | --- | --- |
| `native-emily-preset` | emily 专辑封面 | 0 | Mineradio |
| `native-tunnel-preset` | 滚筒 | 1 | Mineradio |
| `native-planet-preset` | 星球 | 2 | Mineradio |
| `native-vinyl-preset` | 唱片 | 4 | Mineradio |
| `native-galaxy-preset` | 星河 | 5 | Mineradio |
| `native-requiem-preset` | 安魂 | 6 | Mineradio / YUI7W |
| `native-sonic-topography-preset` | 音域回响（Ajin） | 7 | Mineradio / Ajin |
| `native-sonic-workshop-preset` | 音域回响（Wallpaper Engine） | 8 | Mineradio / CmzYa |

索引 3 由宿主保留给「虚空」，插件不占用。

## 登录入口

账号入口不再要求先输入口令「世界和平」，直接点击即可打开对应平台的登录面板。

## 安装

1. 安装随附的 `Mineradio-2.4.3-void-core.apk`（旧版主程序没有 `MineradioVisualPresets` 注册表，插件会提示缺少虚空核心版）。包名为 `com.mineradio.app.v243`，可直接覆盖 2.4.3；若提示签名不一致，先卸载旧版再安装。
2. 打开「插件」→「安装」，逐个导入需要的 `*.zip`。安装包无需解压，`native-presets-1.0.0-source.zip` 不用于安装。
3. 在视觉控制台启用插件后，预设卡片才会出现；停用或卸载插件会立即释放画面并退回「虚空」。
4. 已保存的预设若对应插件未安装，冷启动会回退到「虚空」，插件装回后恢复原预设。

## 参数面板

原视觉控制台「动效」页的预设专属参数已随插件走。选中对应预设时，预设卡片下方会出现「XX参数设置」按钮；点击后展开调节面板，再点收起，切走预设会自动收起（与 Folia 插件的行为一致）。面板里有「恢复默认」，把该预设的参数恢复成插件化之前的默认值。

面板的按钮、展开/收起、参数读写和恢复默认都由插件自带；主程序只保留 `fx` 参数与按预设隔离的存储。以后调整面板样式或参数项，重新打包插件即可，不需要重建 APK。

- emily、滚筒、星球、唱片、星河：基础画面（律动强度、景深、封面清晰度、镜头晃动、电影镜头）+ 粒子与光影（浮空粒子层、溢光、轮廓、背景星河、粒子尺寸/速度/扭曲/色彩/光晕/离散/背景压暗）。
- 安魂：粒子尺寸、色彩张力、光晕强度。
- 音域回响（Ajin）：音域地形、音域频谱（含实时频谱面板与 Kick 自动）、音域颜色、音域方块。
- 音域回响（Wallpaper Engine）：输入压制、音频响应、响应范围、中心高光、五组取色、五套主题。

基础画面与粒子参数按预设独立保存（`mineradio-preset-fx-profiles-v1`），切到别的预设不会串值；「虚空」不提供这些调节，回到默认值。旧版全局参数会在首次启动时迁移成每个预设的初始值。

## 验证范围

浏览器夹具使用真实宿主接口和 WebGL 渲染，覆盖：

- 未装插件时只有「虚空」一张卡片，默认预设为 3；
- 8 个插件逐个注册、切换、停用、再次启用；
- 安魂的 `skull-decimation-points.bin` 与音域回响（Wallpaper Engine）的 vendor 资源加载；
- 冷启动：插件禁用时回退虚空，启用时恢复预设 4 和 9 张卡片；
- 账号入口点击直接打开平台登录面板；
- 全程无页面异常、着色器错误和资源加载失败。

这是桌面 Edge 的兼容性检查，未在 Android 真机上测量帧率、功耗和长时间运行稳定性。

## 构建

```powershell
node build.cjs
powershell -ExecutionPolicy Bypass -File package.ps1 -OutputDirectory dist
```

`build.cjs` 把 `vertex.glsl`、`renderer.js` 和 vendor 资源内联进各插件的 `main.js`；`package.ps1` 输出平铺根目录的安装 ZIP（根目录含 `manifest.json`、`entry.json`、`main.js`、许可与运行资源）、一份源码 ZIP 和 `SHA256.txt`。

## 来源与许可

- 预设与渲染代码来自 Mineradio 原内置实现，作者 Mineradio、YUI7W、Ajin、CmzYa。
- 各安装包保留 `LICENSE`（GPL-3.0）、`NOTICE.md` 与原署名。
- 安魂的粒子采样数据 `skull-decimation-points.bin` 与音域回响（Wallpaper Engine）的 `vendor/sonic-workshop/` 随包分发，来源见各插件目录。
