/* Folia 原版画面预设的 Mineradio 插件入口。由 build.cjs 替换元数据。 */
var MODE = 'diorama', LABEL = '镜台', ID = MODE + '-preset';
var channel = 'mr-folia-' + MODE;
var key = 'mr_folia_' + MODE + '_settings_v1';
var restoreKey = 'mr_folia_restore_pending_v1';
var alive = true, index = -1, frame = null, panelFrame = null, controls = null;
var active = false, ready = false, settings = null, fontScale = 0.85, subtitleFontScale = 0.85, backgroundMode = 'auto';
var backgroundEffect = 'latent', coverBackground = { layout: 'full-overlay', blur: 6, drift: true };
var restoreWaiting = false, restoreAttempt = false, restoreVisibleAt = 0, restoreTimeout = null;
var lastLyrics = null, lastSeed = '', lastSignature = '', lastTheme = '';
var lastCover = '', lastBackgroundEnabled = null, lastShowText = null;
var manager = window.__mrFoliaPresets;
if (!manager) {
  manager = window.__mrFoliaPresets = { retired: {}, clients: {} };
  var baseBuild = window.buildPresetGrid;
  if (typeof baseBuild === 'function') window.buildPresetGrid = function () {
    var result = baseBuild.apply(this, arguments);
    Object.keys(manager.retired).forEach(function (i) {
      var el = document.querySelector('.preset-card[data-preset="' + i + '"]');
      if (el) el.remove();
    });
    return result;
  };
}
manager.overlayOwners = manager.overlayOwners || {};
if (!manager.restoreSessionChecked) {
  manager.restoreSessionChecked = true;
  try {
    manager.suppressAutoRestore = !!localStorage.getItem(restoreKey) ||
      new URLSearchParams(location.search).get('safeFoliaRestore') === '1';
    if (manager.suppressAutoRestore) {
      localStorage.removeItem(restoreKey);
      localStorage.removeItem('mr_folia_selected');
    }
  } catch (e) { manager.suppressAutoRestore = false; }
}
function splashFinished() {
  var splash = document.getElementById('splash');
  return !document.body.classList.contains('splash-active') &&
    (!splash || splash.style.display === 'none');
}
function clearRestoreAttempt() {
  if (restoreTimeout) { clearTimeout(restoreTimeout); restoreTimeout = null; }
  if (!restoreAttempt) return;
  restoreAttempt = false;
  try { localStorage.removeItem(restoreKey); } catch (e) {}
}
function abandonRestore(reason) {
  clearRestoreAttempt();
  restoreWaiting = false;
  try { if (localStorage.getItem('mr_folia_selected') === MODE) localStorage.removeItem('mr_folia_selected'); } catch (e) {}
  if (window.fx && Number(window.fx.preset) === index && typeof window.setPreset === 'function') {
    window.setPreset(0, { silent: true, skipTransition: true, noSave: true });
  }
  updateActive();
  if (api.ui && api.ui.toast) api.ui.toast(LABEL + '启动未完成，已恢复普通画面' + (reason ? '：' + reason : ''));
}
function maybeRestore() {
  if (!restoreWaiting || document.hidden || !splashFinished() || typeof window.setPreset !== 'function') {
    restoreVisibleAt = 0;
    return;
  }
  if (!restoreVisibleAt) restoreVisibleAt = Date.now();
  if (Date.now() - restoreVisibleAt < 1200) return;
  restoreWaiting = false;
  restoreAttempt = true;
  try { localStorage.setItem(restoreKey, JSON.stringify({ mode: MODE, startedAt: Date.now() })); } catch (e) {}
  restoreTimeout = setTimeout(function () { if (restoreAttempt) abandonRestore('渲染超时'); }, 15000);
  window.setPreset(index, { silent: true, skipTransition: true, noSave: true });
  updateActive();
}
// 渲染前暂时压掉冲突的歌词与粒子，保留同画布中的歌单架、详情及连接线。
function installHostRenderHook() {
  var renderer = window.renderer;
  if (!renderer || typeof renderer.render !== 'function') return;
  if (manager.renderHook && manager.renderHook.target === renderer) return;
  var original = renderer.render;
  var wrapped = function (scene) {
    var preset = window.fx && Number(window.fx.preset);
    var on = Object.keys(manager.overlayOwners).some(function (id) { return manager.overlayOwners[id] === preset; });
    if (!on || scene !== window.scene) return original.apply(this, arguments);
    var objects = [window.particles, window.bloomParticles, window.floatGroup, window.backCoverGroup, window.stageLyrics && window.stageLyrics.group];
    var saved = [];
    objects.forEach(function (object) {
      if (!object || saved.some(function (s) { return s.object === object; })) return;
      saved.push({ object: object, visible: object.visible }); object.visible = false;
    });
    try { return original.apply(this, arguments); }
    finally { saved.forEach(function (s) { s.object.visible = s.visible; }); }
  };
  renderer.render = wrapped;
  manager.renderHook = { target: renderer, original: original, wrapped: wrapped };
}
// 多插件共用层级记录；仅改变层级，不隐藏承担歌单架交互的宿主画布。
function syncHostCanvas(on) {
  if (on) manager.overlayOwners[ID] = index;
  else delete manager.overlayOwners[ID];
  var needed = Object.keys(manager.overlayOwners).length > 0;
  if (needed) installHostRenderHook();
  if (needed && !manager.promotedCanvas) {
    var canvas = document.getElementById('canvas-container');
    if (canvas) {
      manager.promotedCanvas = { el: canvas, value: canvas.style.getPropertyValue('z-index'), priority: canvas.style.getPropertyPriority('z-index') };
      canvas.style.setProperty('z-index', '2', 'important');
    }
  } else if (!needed && manager.promotedCanvas) {
    var savedCanvas = manager.promotedCanvas;
    if (savedCanvas.value) savedCanvas.el.style.setProperty('z-index', savedCanvas.value, savedCanvas.priority);
    else savedCanvas.el.style.removeProperty('z-index');
    manager.promotedCanvas = null;
  }
  if (!needed && manager.renderHook) {
    var hook = manager.renderHook;
    if (hook.target.render === hook.wrapped) hook.target.render = hook.original;
    manager.renderHook = null;
  }
}
function resource(path) { return '/api/plugins/' + encodeURIComponent(ID) + '/resource?path=' + encodeURIComponent(path); }
function post(target, type, data) {
  if (target && target.contentWindow) target.contentWindow.postMessage(Object.assign({ channel: channel, type: type }, data || {}), location.origin);
}
function save() {
  try { localStorage.setItem(key, JSON.stringify({ tuning: settings, fontScale: fontScale, subtitleFontScale: subtitleFontScale, backgroundMode: backgroundMode, backgroundEffect: backgroundEffect, coverBackground: coverBackground })); } catch (e) {}
}
function settingsMessage(target) { post(target, 'settings', { tuning: settings, fontScale: fontScale, subtitleFontScale: subtitleFontScale, backgroundMode: backgroundMode, backgroundEffect: backgroundEffect, coverBackground: coverBackground, effectiveFoliaBackgroundEnabled: resolveFoliaBackground() }); }
function finite(value, fallback) { var n = Number(value); return isFinite(n) ? n : fallback; }
function scale(value, fallback) { return Math.max(0, Math.min(1.6, finite(value, fallback))); }
function normalizeBackgroundMode(value) { return value === 'transparent' || value === 'folia' ? value : 'auto'; }
function normalizeCoverBackground(value) {
  value = value && typeof value === 'object' ? value : {};
  return { layout: value.layout === 'half-pane-gradient' ? 'half-pane-gradient' : 'full-overlay', blur: Math.max(0, Math.min(30, Math.round(typeof value.blur === 'number' ? finite(value.blur, 6) : 6))), drift: typeof value.drift === 'boolean' ? value.drift : true };
}
function useFoliaBackground() {
  var fx = window.fx || {};
  var body = document.body;
  return !(
    fx.backgroundAlbumCover || fx.backgroundImage || fx.backgroundMedia ||
    fx.backgroundColorMode === 'custom' || fx.backgroundColorCustom ||
    fx.wallpaperMode ||
    (body && (body.classList.contains('custom-background-override') ||
      body.classList.contains('wallpaper-engine-active') ||
      body.classList.contains('desktop-wallpaper-mode')))
  );
}
function resolveFoliaBackground() {
  return backgroundMode === 'auto' ? useFoliaBackground() : backgroundMode === 'folia';
}
// 宿主以秒保存歌词和逐字时间；普通 LRC 没有逐字信息时按字分配。
function convertLines(rows) {
  return rows.map(function (line, i) {
    var start = finite(line.t, finite(line.startTime, 0));
    var next = i + 1 < rows.length ? finite(rows[i + 1].t, finite(rows[i + 1].startTime, start + 5)) : start + 5;
    var end = finite(line.endTime, start + finite(line.duration, Math.max(0.1, next - start)));
    end = Math.max(start + 0.05, end);
    var text = String(line.text || line.fullText || '');
    var words = (line.words || []).map(function (word) {
      var t = finite(word.t, finite(word.startTime, start));
      return { text: String(word.text || ''), startTime: t, endTime: Math.max(t + 0.01, finite(word.endTime, t + finite(word.d, finite(word.duration, 0.1)))) };
    });
    if (!words.length && text) {
      var chars = Array.from(text), step = (end - start) / chars.length;
      words = chars.map(function (ch, j) { return { text: ch, startTime: start + j * step, endTime: start + (j + 1) * step }; });
    }
    return { fullText: text, startTime: start, endTime: end, words: words, translation: line.translation || line.trans || '', romanization: line.romanization || '', isChorus: !!line.isChorus, songPart: line.songPart, blockIndex: line.blockIndex };
  });
}
function colorHex(css, fallback) {
  css = String(css || '').trim();
  if (/^#[0-9a-f]{6}$/i.test(css)) return css;
  if (/^#[0-9a-f]{3}$/i.test(css)) return '#' + css.slice(1).split('').map(function (c) { return c + c; }).join('');
  var rgb = css.match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)/i);
  return rgb ? '#' + rgb.slice(1, 4).map(function (v) { return Math.max(0, Math.min(255, Math.round(Number(v)))).toString(16).padStart(2, '0'); }).join('') : fallback;
}
function themeData() {
  var fx = window.fx || {};
  var stage = window.stageLyrics || {};
  var pal = stage.coverPalette || stage.palette || {};
  try {
    if (fx.lyricColorMode === 'custom') pal = typeof window.lyricPaletteFromHex === 'function' ? window.lyricPaletteFromHex(fx.lyricColor) : { primary: fx.lyricColor, secondary: fx.lyricColor };
    if (typeof window.effectiveLyricPalette === 'function') pal = window.effectiveLyricPalette(pal);
  } catch (e) {}
  if (fx.lyricHighlightMode === 'custom' && typeof window.effectiveLyricPalette !== 'function') pal = Object.assign({}, pal, { highlight: fx.lyricHighlightColor });
  return { name: LABEL, backgroundColor: '#090b10', primaryColor: colorHex(pal.primary, '#f5f0e6'), secondaryColor: colorHex(pal.secondary, '#8f98ad'), accentColor: colorHex(pal.highlight || pal.primary, '#d9b16d'), fontStyle: fx.lyricFont === 'serif' || fx.lyricFont === 'mono' ? fx.lyricFont : 'sans', fontWeight: finite(fx.lyricWeight, 500), animationIntensity: 'normal' };
}
function songData(force) {
  var rows = Array.isArray(window.lyricsLines) ? window.lyricsLines : [];
  var song = (Array.isArray(window.playQueue) && window.currentIdx >= 0 ? window.playQueue[window.currentIdx] : null) || window.currentSong || window.currentTrack || {};
  var seed = String(song.id || song.mid || song.url || song.name || song.title || (window.audio && window.audio.src) || 'waiting');
  var signature = rows.length + '|' + (rows[0] && rows[0].text || '') + '|' + (rows[rows.length - 1] && rows[rows.length - 1].text || '');
  var theme = themeData(), themeKey = JSON.stringify(theme);
  var cover = typeof window.songCoverSrc === 'function' ? window.songCoverSrc(song, 800) : song.cover || '';
  var backgroundEnabled = resolveFoliaBackground();
  var showText = !window.__mrCoverWallBackdrop || window.__mrCoverWallBackdrop.lyrics;
  var lyricsChanged = force || rows !== lastLyrics || seed !== lastSeed || signature !== lastSignature;
  if (!lyricsChanged && lastTheme === themeKey && lastCover === cover && lastBackgroundEnabled === backgroundEnabled && lastShowText === showText) return;
  // 取色完成后只传主题，歌词数组保持原引用，避免重编整首歌的镜头。
  var songProps = { seed: seed, theme: theme, coverUrl: cover, showText: showText, foliaBackgroundEnabled: backgroundEnabled, songTitle: song.name || song.title || '', songArtist: song.artist || song.singer || '', songAlbum: song.album || '' };
  if (lyricsChanged) songProps.lines = convertLines(rows);
  post(frame, lyricsChanged ? 'song' : 'appearance', { song: songProps });
  if (lastBackgroundEnabled !== backgroundEnabled && panelFrame) settingsMessage(panelFrame);
  lastLyrics = rows; lastSeed = seed; lastSignature = signature; lastTheme = themeKey; lastCover = cover; lastBackgroundEnabled = backgroundEnabled;
  lastShowText = showText;
}
function syncWallBackdrop() {
  if (frame) frame.style.filter = window.__mrCoverWallBackdrop && window.__mrCoverWallBackdrop.blur ? 'blur(12px)' : '';
  if (ready) songData(false);
}
function makeFrame(view) {
  var el = document.createElement('iframe');
  el.title = LABEL + (view === 'panel' ? '参数' : '画面');
  el.setAttribute('data-mr-plugin', ID);
  var memory = Number(navigator.deviceMemory) || 0;
  var cores = Number(navigator.hardwareConcurrency) || 0;
  var androidWebView = /Android/i.test(navigator.userAgent || '');
  var lowPower = document.documentElement.classList.contains('gpu-safe-mode') || document.body.classList.contains('gpu-safe-mode') || new URLSearchParams(location.search).get('gpuSafeMode') === '1' || (memory > 0 && memory <= 4) || (cores > 0 && cores <= 4) || (androidWebView && !memory);
  el.src = resource('renderer.html') + '&view=' + view + '&lowPower=' + (lowPower ? '1' : '0') + '&_t=' + Date.now();
  el.style.cssText = view === 'panel' ? 'width:100%;height:620px;max-height:65vh;border:0;border-radius:12px;background:#090b10' : 'position:fixed;inset:0;width:100%;height:100%;border:0;z-index:1;pointer-events:none;background:transparent';
  return el;
}
function stopStage() {
  ready = false;
  clearRestoreAttempt();
  syncHostCanvas(false);
  if (frame) { post(frame, 'dispose'); frame.remove(); frame = null; }
  lastLyrics = null; lastSeed = ''; lastSignature = ''; lastBackgroundEnabled = null;
}
function updateActive() {
  if (!alive || index < 0) return;
  var on = !!window.fx && Number(window.fx.preset) === index && splashFinished();
  if (on === active) return;
  active = on;
  if (controls) controls.style.display = on ? '' : 'none';
  if (on) {
    try { localStorage.setItem('mr_folia_selected', MODE); } catch (e) {}
    frame = makeFrame('stage'); document.body.appendChild(frame); syncWallBackdrop();
    syncHostCanvas(true);
  } else {
    stopStage();
    if (panelFrame) { post(panelFrame, 'dispose'); panelFrame.remove(); panelFrame = null; }
    try { if (localStorage.getItem('mr_folia_selected') === MODE) localStorage.removeItem('mr_folia_selected'); } catch (e) {}
  }
}
function createControls() {
  var host = document.getElementById('fx-panel');
  if (!host || controls) return;
  controls = document.createElement('section');
  controls.setAttribute('data-mr-plugin', ID);
  controls.style.cssText = 'margin:12px 0;display:none';
  var button = document.createElement('button');
  button.type = 'button'; button.textContent = LABEL + '参数设置';
  button.style.cssText = 'padding:10px 16px;border-radius:9px;color:#eee;background:#222b39;border:1px solid #5c6370;width:100%';
  button.onclick = function () {
    if (panelFrame) { post(panelFrame, 'dispose'); panelFrame.remove(); panelFrame = null; return; }
    panelFrame = makeFrame('panel'); controls.appendChild(panelFrame);
  };
  controls.appendChild(button);
  var anchor = document.getElementById('preset-grid');
  if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(controls, anchor.nextSibling); else host.appendChild(controls);
}
function register() {
  if (!Array.isArray(window.presetMeta) || !window.fx) return false;
  window.presetMeta.some(function (p, i) { if (p && p._mrFolia === MODE) { index = i; return true; } return false; });
  var meta = { name: LABEL, nameHtml: LABEL + ' <span class="pc-name-en">' + MODE[0].toUpperCase() + MODE.slice(1) + '</span>', desc: '点阵化的文字在 3D 空间里穿行，镜头跟着歌词运镜', _mrFolia: MODE };
  if (index < 0) { index = window.presetMeta.length; window.presetMeta.push(meta); }
  else window.presetMeta[index] = meta;
  delete manager.retired[index]; manager.clients[MODE] = updateActive;
  if (Array.isArray(window.presetIcons)) window.presetIcons[index] = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="8"/><path d="M12 4v16M4 12h16M6 6l12 12M6 18L18 6"/></svg>';
  if (Array.isArray(window.presetDisplayOrder) && window.presetDisplayOrder.indexOf(index) < 0) window.presetDisplayOrder.push(index);
  window.MAX_VISUAL_PRESET_INDEX = window.presetMeta.length - 1;
  if (typeof window.buildPresetGrid === 'function') window.buildPresetGrid();
  createControls();
  try { restoreWaiting = !manager.suppressAutoRestore && localStorage.getItem('mr_folia_selected') === MODE; } catch (e) {}
  updateActive();
  return true;
}
function onMessage(event) {
  if (!alive || event.origin !== location.origin || !event.data || event.data.channel !== channel) return;
  var target = frame && event.source === frame.contentWindow ? frame : panelFrame && event.source === panelFrame.contentWindow ? panelFrame : null;
  if (!target) return;
  var msg = event.data;
  if (msg.type === 'ready') {
    settingsMessage(target);
    if (target === frame) { ready = true; songData(true); }
  }
  if (msg.type === 'stageAlive' && target === frame) clearRestoreAttempt();
  if (msg.type === 'settingsChanged' && target === panelFrame) {
    settings = msg.tuning; fontScale = scale(msg.fontScale, 0.85); subtitleFontScale = scale(msg.subtitleFontScale, 0.85); backgroundMode = normalizeBackgroundMode(msg.backgroundMode);
    backgroundEffect = msg.backgroundEffect === 'cover' ? 'cover' : 'latent'; coverBackground = normalizeCoverBackground(msg.coverBackground);
    save(); settingsMessage(frame); settingsMessage(panelFrame);
  }
  if (msg.type === 'error') {
    console.error('[Folia ' + LABEL + ']', msg.message);
    if (restoreAttempt) abandonRestore(msg.message);
    else if (api.ui && api.ui.toast) api.ui.toast(LABEL + '：' + msg.message);
  }
}
try { var saved = JSON.parse(localStorage.getItem(key) || 'null'); if (saved) { settings = saved.tuning; fontScale = scale(saved.fontScale, 0.85); subtitleFontScale = scale(saved.subtitleFontScale, 0.85); backgroundMode = normalizeBackgroundMode(saved.backgroundMode); backgroundEffect = saved.backgroundEffect === 'cover' ? 'cover' : 'latent'; coverBackground = normalizeCoverBackground(saved.coverBackground); } } catch (e) {}
window.addEventListener('message', onMessage);
window.addEventListener('mr-cover-wall-backdrop', syncWallBackdrop);
// setTimeout 调度桥接，避免依赖宿主对 requestAnimationFrame 的改写。
var timer = api.timer.setInterval(function () {
  if (!alive) return;
  if (index < 0) { register(); return; }
  createControls(); maybeRestore(); updateActive();
  if (active) syncHostCanvas(true);
  if (!active || !ready || document.hidden) return;
  songData(false);
  var t = typeof window.getPlaybackCurrentSeconds === 'function' ? finite(window.getPlaybackCurrentSeconds(), 0) : finite(window.audio && window.audio.currentTime, 0);
  if (typeof window.getAdjustedLyricPlaybackTime === 'function') t = finite(window.getAdjustedLyricPlaybackTime(t), t);
  var rows = window.lyricsLines || [], lineIndex = -1, lo = 0, hi = rows.length - 1;
  while (lo <= hi) { var mid = (lo + hi) >> 1; if (finite(rows[mid].t, finite(rows[mid].startTime, 0)) <= t) { lineIndex = mid; lo = mid + 1; } else hi = mid - 1; }
  var spectrum = window.frequencyData instanceof Uint8Array ? window.frequencyData.slice(0, 128) : new Uint8Array(0);
  post(frame, 'frame', { spectrum: spectrum, time: t, index: lineIndex, paused: typeof window.playing === 'boolean' ? !window.playing : !!(window.audio && window.audio.paused), power: finite(window.audioEnergy, 0), bands: { bass: finite(window.bass, 0), lowMid: finite(window.mid, 0), mid: finite(window.mid, 0), vocal: finite(window.mid, 0), treble: finite(window.treble, 0) } });
}, 33);
api.ready(function () { if (alive) register(); });
return function () {
  alive = false;
  clearRestoreAttempt();
  clearInterval(timer); window.removeEventListener('message', onMessage);
  window.removeEventListener('mr-cover-wall-backdrop', syncWallBackdrop);
  if (active && typeof window.setPreset === 'function') window.setPreset(0, { silent: true });
  stopStage();
  if (panelFrame) { post(panelFrame, 'dispose'); panelFrame.remove(); }
  if (controls) controls.remove();
  delete manager.clients[MODE];
  if (index >= 0) {
    manager.retired[index] = true;
    if (Array.isArray(window.presetDisplayOrder)) { var at = window.presetDisplayOrder.indexOf(index); if (at >= 0) window.presetDisplayOrder.splice(at, 1); }
    if (typeof window.buildPresetGrid === 'function') window.buildPresetGrid();
  }
  try { if (localStorage.getItem('mr_folia_selected') === MODE) localStorage.removeItem('mr_folia_selected'); } catch (e) {}
};
