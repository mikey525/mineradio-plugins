/* Mineradio portrait-mode 1.0.1 */
MineradioPlugins.register({
  "id": "portrait-mode",
  "name": "横竖屏切换",
  "version": "1.0.1",
  "author": "Mineradio",
  "description": "独立竖屏界面，按钮切换横屏/竖屏；横屏支持左右旋转，启动恢复上次选择。需配套方向控制版主程序。"
}
, function (api) {
  var controller = window.MineradioOrientation;
  if (!controller || !controller.supported()) throw new Error('请先安装配套方向控制版主程序');
  api.dom.addCSS("/* Portrait only: landscape continues to use the original dimensions/colours.\n   Override the desktop rem/zoom here instead of scaling a wide layout down. */\nhtml[data-mineradio-layout=\"portrait\"] {\n  font-size: 100px !important;\n  --ui-scale: 1 !important;\n  --ui-scale-i: 1 !important;\n  --portrait-edge: max(16px, env(safe-area-inset-left), env(safe-area-inset-right));\n  --portrait-top: max(12px, env(safe-area-inset-top));\n  --portrait-bottom: max(12px, env(safe-area-inset-bottom));\n}\nhtml[data-mineradio-layout=\"portrait\"],\nhtml[data-mineradio-layout=\"portrait\"] body {\n  zoom: 1 !important;\n  -moz-transform: none !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] #splash { zoom: 1 !important; }\n\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar.stage-mode {\n  left: 50%;\n  bottom: var(--portrait-bottom);\n  width: min(520px, calc(100% - var(--portrait-edge) * 2));\n  padding: 12px;\n  gap: 6px;\n  border-radius: 24px;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #progress-bar {\n  width: calc(100% - 88px);\n  align-self: flex-start;\n  margin: 6px 0;\n  height: 4px;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #progress-bar::before {\n  content: '';\n  position: absolute;\n  inset: -10px 0;\n}\nhtml[data-mineradio-layout=\"portrait\"] body:not(.immersive-mode) #controls {\n  display: grid;\n  grid-template-columns: 36px 36px minmax(0, 1fr) 36px 36px;\n  gap: 8px 0;\n}\nhtml[data-mineradio-layout=\"portrait\"] body:not(.immersive-mode) #controls .control-cluster.actions {\n  display: contents;\n}\nhtml[data-mineradio-layout=\"portrait\"] body:not(.immersive-mode) #controls .control-track {\n  display: flex;\n  grid-column: 1 / 4;\n  grid-row: 1;\n  max-width: none;\n  gap: 10px;\n  padding-right: 6px;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-meta { max-width: none; flex: 1; gap: 5px; }\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-title-row,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-subtitle-row { gap: 5px; }\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-cover { display: block; width: 40px; height: 40px; border-radius: 10px; }\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-title { font-size: 13px; }\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-artist { font-size: 11px; }\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #heart-btn { grid-column: 4; grid-row: 1; }\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #collect-btn { grid-column: 5; grid-row: 1; }\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #play-mode-btn { grid-column: 1; grid-row: 2; }\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #cuefield-automix-btn { grid-column: 5; grid-row: 2; }\nhtml[data-mineradio-layout=\"portrait\"] body:not(.immersive-mode) #controls .control-cluster.transport {\n  grid-column: 2 / 5 !important;\n  grid-row: 2;\n  width: max-content;\n  height: 48px;\n  gap: 12px;\n  order: initial;\n}\nhtml[data-mineradio-layout=\"portrait\"] body:not(.immersive-mode) #controls .control-cluster.modes {\n  grid-column: 1 / -1 !important;\n  grid-row: 3;\n  width: 100%;\n  min-width: 0;\n  height: auto;\n  justify-content: center;\n  flex-wrap: wrap;\n  gap: 2px;\n  order: initial;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #controls .ctrl-btn { width: 36px; height: 36px; flex-shrink: 0; }\nhtml[data-mineradio-layout=\"portrait\"] body #controls .ctrl-btn svg { width: 20px; height: 20px; }\nhtml[data-mineradio-layout=\"portrait\"] body #controls .lyrics-word-icon { font-size: 20px; }\nhtml[data-mineradio-layout=\"portrait\"] body #controls #play-btn { width: 48px; height: 48px; }\nhtml[data-mineradio-layout=\"portrait\"] body #controls #time-display {\n  display: block;\n  position: absolute;\n  top: -25px;\n  right: 0;\n  width: 82px;\n  min-width: 0;\n  height: 16px;\n  font-size: 10px;\n  line-height: 16px;\n  text-align: right;\n  white-space: nowrap;\n}\n/* Preserve badge fills from index.css and give text a readable portrait size. */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #control-source-badges .tag-source,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #control-title-badges .tag-vip,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #quality-btn.quality-pill {\n  width: auto;\n  min-width: 0;\n  height: 16px;\n  padding: 0 4px;\n  font-size: 9px;\n}\nhtml[data-mineradio-layout=\"portrait\"] body.immersive-mode #controls { flex-wrap: wrap; gap: 10px; }\nhtml[data-mineradio-layout=\"portrait\"] body.immersive-mode #controls .control-cluster { height: auto; gap: 8px; }\nhtml[data-mineradio-layout=\"portrait\"] body.immersive-mode #controls .control-cluster.modes { min-width: 0; }\n\n/* Top controls occupy their own row so search remains full width below them. */\nhtml[data-mineradio-layout=\"portrait\"] body #top-right { top: var(--portrait-top); right: var(--portrait-edge); gap: 8px; }\nhtml[data-mineradio-layout=\"portrait\"] body #search-area {\n  left: 50%;\n  width: min(520px, calc(100% - var(--portrait-edge) * 2));\n  gap: 8px;\n  --search-offset: 0px;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #search-area.peek { top: calc(var(--portrait-top) + 52px); }\nhtml[data-mineradio-layout=\"portrait\"] body #search-stack,\nhtml[data-mineradio-layout=\"portrait\"] body #search-area.stage-mode #search-stack { flex: 1; min-width: 0; width: 0; }\nhtml[data-mineradio-layout=\"portrait\"] body #search-box { width: 100%; min-height: 42px; padding: 0 12px; }\nhtml[data-mineradio-layout=\"portrait\"] body #search-input { min-width: 0; font-size: 14px; }\nhtml[data-mineradio-layout=\"portrait\"] body #upload-actions { flex: 0 0 40px; }\nhtml[data-mineradio-layout=\"portrait\"] body #upload-btn { width: 40px; height: 42px; }\nhtml[data-mineradio-layout=\"portrait\"] body .search-mode-tabs { width: 100%; flex-wrap: wrap; }\nhtml[data-mineradio-layout=\"portrait\"] body #search-results { max-height: min(50vh, 440px); }\nhtml[data-mineradio-layout=\"portrait\"] body #upload-panel { max-width: calc(100vw - 32px); }\n\n/* Side panels become bounded sheets; the existing anchor code sets their height. */\nhtml[data-mineradio-layout=\"portrait\"] body #playlist-panel,\nhtml[data-mineradio-layout=\"portrait\"] body #fx-panel {\n  width: min(440px, calc(100vw - var(--portrait-edge) * 2)) !important;\n  max-width: calc(100vw - var(--portrait-edge) * 2);\n  zoom: 1 !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #playlist-panel { left: var(--portrait-edge); }\nhtml[data-mineradio-layout=\"portrait\"] body #fx-panel { right: var(--portrait-edge); }\nhtml[data-mineradio-layout=\"portrait\"] body #thumb-wrap { bottom: 204px; }\nhtml[data-mineradio-layout=\"portrait\"] body .mini-queue-popover { width: calc(100% - 8px); max-height: min(50vh, 440px); }\nhtml[data-mineradio-layout=\"portrait\"] body .volume-popover,\nhtml[data-mineradio-layout=\"portrait\"] body .lyric-timing-popover { left: 50%; right: auto; transform: translateX(-50%); max-width: calc(100vw - 48px); }\nhtml[data-mineradio-layout=\"portrait\"] body .modal-mask { padding: var(--portrait-top) var(--portrait-edge) var(--portrait-bottom); }\nhtml[data-mineradio-layout=\"portrait\"] body .modal { max-width: 100%; max-height: 88vh; overflow-y: auto; }\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home { top: calc(var(--portrait-top) + 140px); bottom: var(--portrait-bottom); }\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .empty-home-shell { grid-template-rows: minmax(280px, 42vh) auto auto; }\n\n/*\n * Folia 风格竖屏播放胶囊（第一阶段：只做播放栏，横屏零影响）\n *\n * 结构来源：whycfawa/folia-android @ 7d2cc8312ee961b01f08f3585ab6bec5a059a4e7\n *           src/styles/androidPhoneFit.css 的 portrait 分支\n *   第一行：播放键 | 封面+歌名/歌手 | 上一首 下一首 | 队列 词 音量\n *   第二行：进度条（横跨整行）\n *   胶囊：高 66px，宽 min(100vw - 40px, 380px)，圆角悬浮\n *\n * 只在根属性 data-mineradio-layout=\"portrait\" 下生效；横屏 DOM 与尺寸不动。\n * 必须加载在 portrait-layout.css 之后。\n */\n\n/* Hide portrait-only content immediately during rotation, before JS cleanup. */\n#empty-home .mr-now-layer { display: none; }\n\n/* ---------- 1. 胶囊外壳：两行 grid ---------- */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar.stage-mode,\nhtml[data-mineradio-layout=\"portrait\"] body.simple-mode #bottom-bar,\nhtml[data-mineradio-layout=\"portrait\"] body.diy-mode #bottom-bar,\nhtml[data-mineradio-layout=\"portrait\"] body.diy-mode #bottom-bar.stage-mode {\n  left: 50% !important;\n  width: min(calc(100vw - 40px), 380px) !important;\n  max-width: min(calc(100vw - 40px), 380px) !important;\n  min-width: 0 !important;\n  height: 66px !important;\n  min-height: 66px !important;\n  max-height: 66px !important;\n  bottom: calc(10px + env(safe-area-inset-bottom, 0px)) !important;\n  padding: 7px 12px !important;\n  border-radius: 22px !important;\n  box-sizing: border-box !important;\n  display: grid !important;\n  grid-template-columns: 100% !important;\n  grid-template-rows: 36px 4px !important;\n  align-content: center !important;\n  row-gap: 7px !important;\n  column-gap: 0 !important;\n  overflow: visible !important;\n}\n\n/* 播放栏与横屏一致：本身不铺底色，透明浮在壁纸上 */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar.visible {\n  background: transparent !important;\n  backdrop-filter: none !important;\n  -webkit-backdrop-filter: none !important;\n  box-shadow: none !important;\n}\n\n/* 竖屏封面由 --mr-now-cover 统一驱动，避免被播放器内联样式的清空逻辑覆盖 */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #control-cover {\n  background-image: var(--mr-now-cover, none) !important;\n  background-size: cover !important;\n  background-position: center !important;\n  background-repeat: no-repeat !important;\n}\n\n/* ---------- 2. 第二行：进度条 ---------- */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #progress-bar {\n  grid-row: 2 !important;\n  grid-column: 1 !important;\n  width: 100% !important;\n  height: 4px !important;\n  min-height: 4px !important;\n  margin: 0 !important;\n  align-self: center !important;\n  justify-self: stretch !important;\n  order: 0 !important;\n}\n\n/* 进度条触控热区上下各留 10px */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #progress-bar::before {\n  content: '';\n  position: absolute;\n  inset: -10px 0;\n}\n\n/* ---------- 3. 第一行：控件压成一条不换行的 flex ---------- */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #controls {\n  grid-row: 1 !important;\n  grid-column: 1 !important;\n  display: flex !important;\n  flex-direction: row !important;\n  align-items: center !important;\n  justify-content: flex-start !important;\n  flex-wrap: nowrap !important;\n  gap: 6px !important;\n  width: 100% !important;\n  height: 36px !important;\n  min-width: 0 !important;\n  margin: 0 !important;\n  padding: 0 !important;\n  overflow: visible !important;\n}\n\n/* 三个 control-cluster 打散，子元素才能按 Folia 顺序重排 */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #controls > .control-cluster,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #lyric-timing-control,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #volume-control {\n  display: contents !important;\n}\n\n/* ---------- 4. 顺序：标题 → 上一首 播放 下一首 → 槽位 ---------- */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-track {\n  order: 1;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #prev-btn {\n  order: 2;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #play-btn {\n  order: 3;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #next-btn {\n  order: 4;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #mini-queue-btn {\n  order: 5;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #cover-wall-toggle-btn {\n  order: 6;\n  width: 22px !important;\n  height: 22px !important;\n  min-width: 22px !important;\n  flex: 0 0 22px !important;\n  padding: 0 !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #lyrics-toggle-btn {\n  order: 7;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #volume-btn {\n  order: 8;\n}\n\n/* ---------- 5. 尺寸 ---------- */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #controls .ctrl-btn:not(.quality-pill) {\n  width: 22px !important;\n  height: 22px !important;\n  min-width: 22px !important;\n  flex: 0 0 22px !important;\n  padding: 0 !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #controls .ctrl-btn:not(.quality-pill) svg {\n  width: 14px !important;\n  height: 14px !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #controls .lyrics-word-icon {\n  font-size: 14px !important;\n  line-height: 1 !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #controls #play-btn {\n  width: 32px !important;\n  height: 32px !important;\n  min-width: 32px !important;\n  flex: 0 0 32px !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #controls #play-btn svg {\n  width: 15px !important;\n  height: 15px !important;\n}\n\n/* 播放组（上一首 / 播放 / 下一首）钉在胶囊正中央，标题靠左、槽位靠右 */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #controls {\n  position: relative !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #prev-btn,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #play-btn,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #next-btn {\n  position: absolute !important;\n  top: 50% !important;\n  transform: translateY(-50%) !important;\n  z-index: 2 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #play-btn {\n  left: calc(50% - 16px) !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #prev-btn {\n  left: calc(50% - 44px) !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #next-btn {\n  left: calc(50% + 22px) !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #mini-queue-btn {\n  margin-left: auto !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-track {\n  max-width: calc(50% - 52px) !important;\n}\n\n/* ---------- 6. 歌曲信息：弹性占中间 ---------- */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-track {\n  display: flex !important;\n  flex: 1 1 auto !important;\n  align-items: center !important;\n  justify-content: flex-start !important;\n  gap: 7px !important;\n  min-width: 0 !important;\n  /* 必须止于中线左侧，否则长歌手名会顶到中间的播放按钮下面；\n     -44px 给播放组留 8px 间隙，同时比 -52 多让出 8px 给文字 */\n  max-width: calc(50% - 44px) !important;\n  overflow: hidden !important;\n  padding: 0 !important;\n  height: 36px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-title {\n  flex: 0 1 auto !important;\n  min-width: 0 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-artist {\n  flex: 1 1 0 !important;\n  min-width: 0 !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-cover {\n  display: block !important;\n  width: 26px !important;\n  height: 26px !important;\n  min-width: 26px !important;\n  border-radius: 8px !important;\n  flex: 0 0 26px !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-meta {\n  display: flex !important;\n  flex-direction: column !important;\n  justify-content: center !important;\n  gap: 0 !important;\n  max-width: none !important;\n  min-width: 0 !important;\n  flex: 1 1 auto !important;\n  overflow: hidden !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-title-row,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-subtitle-row {\n  display: flex !important;\n  align-items: center !important;\n  gap: 3px !important;\n  min-width: 0 !important;\n  height: 15px !important;\n  overflow: hidden !important;\n  white-space: nowrap !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-title {\n  font-size: 12px !important;\n  line-height: 14px !important;\n  min-width: 0 !important;\n  overflow: hidden !important\n  ;\n  text-overflow: ellipsis !important;\n  white-space: nowrap !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .control-artist {\n  font-size: 10px !important;\n  line-height: 12px !important;\n  min-width: 0 !important;\n  overflow: hidden !important;\n  text-overflow: ellipsis !important;\n  white-space: nowrap !important;\n}\n\n/* 徽章保持原配色，只压尺寸 */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #control-title-badges .tag-vip,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #control-source-badges .tag-source,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #quality-btn.quality-pill {\n  height: 13px !important;\n  min-width: 0 !important;\n  padding: 0 3px !important;\n  font-size: 8px !important;\n  line-height: 13px !important;\n  flex: 0 0 auto !important;\n}\n\n/* ---------- 7. 第一行放不下的收起（横屏不受影响） ---------- */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #heart-btn,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #collect-btn,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #play-mode-btn,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #controls-hide-btn,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #immersive-btn,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .fullscreen-toggle-btn,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #time-display,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #control-title-badges,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #control-source-badges,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #quality-control {\n  display: none !important;\n}\n\n/* 弹层仍挂在胶囊上方 */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .volume-popover,\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar .lyric-timing-popover {\n  bottom: calc(100% + 8px) !important;\n}\n\n/* ========== 11. 竖屏外壳：顶栏 + tab ========== */\nhtml[data-mineradio-layout=\"portrait\"] #folia-shell {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: 40;\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  padding: calc(env(safe-area-inset-top, 0px) + 12px) 18px 0;\n  pointer-events: none;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #folia-topbar {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  height: 40px;\n  min-width: 0;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #folia-brand {\n  font-size: 27px;\n  line-height: 1;\n  font-weight: 600;\n  letter-spacing: .3px;\n  color: #fff;\n  text-shadow: 0 2px 14px rgba(0, 0, 0, .55);\n  white-space: nowrap;\n  cursor: pointer;\n  pointer-events: auto;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #folia-gear {\n  pointer-events: auto;\n  width: 34px;\n  height: 34px;\n  padding: 0;\n  border: 0;\n  background: transparent;\n  color: #8e8e93;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #folia-tabs {\n  display: flex;\n  align-items: center;\n  gap: 2px;\n  pointer-events: auto;\n  min-width: 0;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #folia-tabs button {\n  height: 30px;\n  padding: 0 15px;\n  border: 0;\n  border-radius: 15px;\n  background: transparent;\n  color: #9b9b9f;\n  font-family: inherit;\n  font-size: 14px;\n  line-height: 30px;\n  white-space: nowrap;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #folia-tabs button.is-active {\n  background: #fff;\n  color: #101012;\n  font-weight: 600;\n}\n\n/* ========== 9. 顶栏右侧：Folia 式圆角搜索框 ========== */\nhtml[data-mineradio-layout=\"portrait\"] body #search-area {\n  position: fixed !important;\n  top: calc(env(safe-area-inset-top, 0px) + 14px) !important;\n  right: 18px !important;\n  left: auto !important;\n  bottom: auto !important;\n  margin: 0 !important;\n  padding: 0 !important;\n  height: 36px !important;\n  max-height: 36px !important;\n  transform: none !important;\n  width: min(42vw, 172px) !important;\n  z-index: 41 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #search-area #search-box,\nhtml[data-mineradio-layout=\"portrait\"] body #search-area #search-stack {\n  width: 100% !important;\n  min-width: 0 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #search-area #search-box {\n  height: 36px !important;\n  min-height: 36px !important;\n  max-height: 36px !important;\n  padding: 0 12px !important;\n  border-radius: 18px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #search-area #search-input {\n  font-size: 13px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #search-area #upload-actions,\nhtml[data-mineradio-layout=\"portrait\"] body #search-area .search-mode-tabs {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #top-right {\n  display: none !important;\n}\n\n/* ========== 10. 首页内容区：Folia 卡片网格 ========== */\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home {\n  top: calc(env(safe-area-inset-top, 0px) + 104px) !important;\n  bottom: calc(env(safe-area-inset-bottom, 0px) + 96px) !important;\n  padding: 0 16px !important;\n  overflow-y: auto !important;\n  overflow-x: hidden !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .empty-home-shell {\n  display: block !important;\n  grid-template-rows: none !important;\n  padding: 0 !important;\n  width: 100% !important;\n  max-width: none !important;\n  height: auto !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-hero {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-grid.home-quick-grid {\n  display: grid !important;\n  grid-template-columns: repeat(2, minmax(0, 1fr)) !important;\n  gap: 10px !important;\n  margin: 0 0 12px !important;\n  width: 100% !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card {\n  position: relative !important;\n  background: #1c1c1e !important;\n  border: 0 !important;\n  border-radius: 18px !important;\n  box-shadow: none !important;\n  min-height: 134px !important;\n  padding: 12px !important;\n  overflow: hidden !important;\n  display: flex !important;\n  flex-direction: column !important;\n  justify-content: flex-end !important;\n  gap: 2px !important;\n  text-align: left !important;\n}\n\n/* Folia 的卡片就是封面铺满 + 底部渐变 + 标题，不画小图标 */\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card-art {\n  display: block !important;\n  position: absolute !important;\n  top: 0 !important;\n  left: 0 !important;\n  right: 0 !important;\n  bottom: 0 !important;\n  width: 100% !important;\n  height: 100% !important;\n  max-width: none !important;\n  max-height: none !important;\n  min-width: 0 !important;\n  margin: 0 !important;\n  border-radius: inherit !important;\n  background-size: cover !important;\n  background-position: center !important;\n  background-repeat: no-repeat !important;\n  filter: brightness(.78) saturate(.92) !important;\n  opacity: 1 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card.mr-now-card .home-card-art {\n  background-image: var(--mr-now-cover, none) !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card::after {\n  content: '';\n  position: absolute;\n  inset: 0;\n  border-radius: inherit;\n  pointer-events: none;\n  z-index: 2;\n  background: linear-gradient(180deg, rgba(8, 8, 10, .30) 0%, rgba(8, 8, 10, .72) 46%, rgba(8, 8, 10, 1) 100%);\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card .home-card-art {\n  z-index: 1 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card > * {\n  position: relative;\n  z-index: 3;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card-label {\n  font-size: 10px !important;\n  letter-spacing: .08em !important;\n  color: #8e8e93 !important;\n  font-weight: 600 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card-title {\n  font-size: 17px !important;\n  line-height: 1.2 !important;\n  color: #fff !important;\n  font-weight: 600 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card-sub {\n  font-size: 11px !important;\n  line-height: 1.35 !important;\n  color: #8e8e93 !important;\n}\n\n/* 洞察区压成 Folia 同款分组卡片 */\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-insight-rail {\n  display: block !important;\n  width: 100% !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home #home-insight-dock {\n  display: grid !important;\n  grid-template-columns: minmax(0, 1fr) !important;\n  gap: 10px !important;\n  width: 100% !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-insight-card {\n  background: #1c1c1e !important;\n  border: 0 !important;\n  border-radius: 18px !important;\n  box-shadow: none !important;\n  padding: 14px !important;\n  min-height: 0 !important;\n  width: 100% !important;\n  min-width: 0 !important;\n  max-width: none !important;\n  grid-column: 1 / -1 !important;\n  height: auto !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-legacy-rail {\n  display: none !important;\n}\n\n/* 卡片文字压在封面图上，必须自带投影与足够暗的底 */\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card-label {\n  color: #d2d2d6 !important;\n  text-shadow: 0 1px 8px rgba(0, 0, 0, .95), 0 0 2px rgba(0, 0, 0, .9) !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card-title {\n  color: #ffffff !important;\n  text-shadow: 0 2px 14px rgba(0, 0, 0, .98), 0 0 3px rgba(0, 0, 0, .9) !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card-sub {\n  color: #e2e2e6 !important;\n  font-size: 11.5px !important;\n  text-shadow: 0 1px 10px rgba(0, 0, 0, .98), 0 0 3px rgba(0, 0, 0, .95) !important;\n}\n\n/* 「正在播放」卡：隐藏原生三段文案，用自己插入的图层显示 */\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card.mr-now-card > .home-card-label,\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card.mr-now-card > .home-card-title,\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-card.mr-now-card > .home-card-sub {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .mr-now-layer {\n  position: absolute;\n  left: 12px;\n  right: 12px;\n  bottom: 12px;\n  z-index: 4;\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  min-width: 0;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .mr-now-kicker {\n  font-size: 10px;\n  letter-spacing: .08em;\n  font-weight: 600;\n  color: #d2d2d6;\n  text-shadow: 0 1px 8px rgba(0, 0, 0, .95);\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .mr-now-title {\n  font-size: 17px;\n  line-height: 1.2;\n  font-weight: 600;\n  color: #fff;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  text-shadow: 0 2px 14px rgba(0, 0, 0, .98), 0 0 3px rgba(0, 0, 0, .9);\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .mr-now-artist {\n  font-size: 11px;\n  line-height: 1.3;\n  color: #c9c9cf;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  text-shadow: 0 1px 10px rgba(0, 0, 0, .95);\n}\n\n/* ========== 14. 为你挑选：文字在上，歌曲卡横向排成一条可滑动的带子 ========== */\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-strip {\n  display: flex !important;\n  flex-direction: column !important;\n  align-items: stretch !important;\n  gap: 10px !important;\n  padding: 14px !important;\n  min-height: 0 !important;\n  background: #1c1c1e !important;\n  border: 0 !important;\n  border-radius: 18px !important;\n  box-shadow: none !important;\n  grid-template-columns: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-strip > .home-insight-kicker,\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-copy {\n  grid-column: auto !important;\n  grid-row: auto !important;\n  align-self: auto !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-title {\n  margin-top: 4px !important;\n  font-size: 15px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-sub {\n  margin-top: 3px !important;\n  font-size: 11px !important;\n  color: #8e8e93 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-list {\n  display: flex !important;\n  flex-direction: row !important;\n  flex-wrap: nowrap !important;\n  align-items: stretch !important;\n  gap: 8px !important;\n  width: 100% !important;\n  min-width: 0 !important;\n  overflow-x: auto !important;\n  overflow-y: hidden !important;\n  grid-template-columns: none !important;\n  grid-auto-rows: auto !important;\n  scrollbar-width: none !important;\n  -webkit-overflow-scrolling: touch !important;\n  padding-bottom: 2px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-list::-webkit-scrollbar {\n  display: none !important;\n  width: 0 !important;\n  height: 0 !important;\n}\n\n/* 宽度按「正好放下两张」算：gap 8px 时每张 50% - 4px，第三张露出一角提示可滑动 */\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-song {\n  flex: 0 0 calc(50% - 4px) !important;\n  width: calc(50% - 4px) !important;\n  min-width: 0 !important;\n  max-width: none !important;\n  height: 58px !important;\n  min-height: 0 !important;\n  grid-template-columns: 38px minmax(0, 1fr) !important;\n  gap: 8px !important;\n  padding: 8px !important;\n  border-radius: 12px !important;\n  border: 1px solid rgba(255, 255, 255, .07) !important;\n  background: rgba(255, 255, 255, .045) !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-cover {\n  width: 38px !important;\n  height: 38px !important;\n  border-radius: 9px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-song-name {\n  font-size: 12px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-song-artist {\n  font-size: 10px !important;\n  color: #8e8e93 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #empty-home .home-discovery-empty {\n  width: 100% !important;\n  min-height: 58px !important;\n}\n\n/* ========== 15. 音乐库（竖屏）：照 Folia 面板版式，让出顶栏与胶囊 ========== */\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask {\n  padding: calc(env(safe-area-inset-top, 0px) + 100px) 16px calc(env(safe-area-inset-bottom, 0px) + 92px) 16px !important;\n  align-items: stretch !important;\n  background: transparent !important;\n  backdrop-filter: none !important;\n  -webkit-backdrop-filter: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-dialog {\n  width: 100% !important;\n  max-width: 100% !important;\n  height: 100% !important;\n  max-height: 100% !important;\n  border-radius: 22px !important;\n  /* 遮罩是透明的（要在上面看到顶栏和胶囊），所以面板本身必须实心，否则首页会透进来 */\n  background: #17181c !important;\n  border: 1px solid rgba(255, 255, 255, .10) !important;\n  box-shadow: 0 18px 50px rgba(0, 0, 0, .45) !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-head {\n  flex-direction: column !important;\n  align-items: stretch !important;\n  gap: 8px !important;\n  padding: 12px 14px 10px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-head p {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-kicker {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-head h2 {\n  margin: 0 !important;\n  font-size: 18px !important;\n  line-height: 1.15 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-head-actions {\n  display: flex !important;\n  flex-wrap: nowrap !important;\n  align-items: center !important;\n  gap: 8px !important;\n  width: 100% !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-head-actions input {\n  flex: 1 1 auto !important;\n  min-width: 0 !important;\n  height: 38px !important;\n  font-size: 13px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-head-actions button {\n  flex: 0 0 auto !important;\n  height: 38px !important;\n  padding: 0 12px !important;\n  font-size: 12px !important;\n  white-space: nowrap !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-content {\n  display: flex !important;\n  flex-direction: column !important;\n  gap: 10px !important;\n  flex: 1 1 auto !important;\n  min-height: 0 !important;\n  padding: 8px 12px 12px !important;\n}\n\n/* 歌单用两列等分，不再横向滚动：横滚时第二张容易被面板边缘切掉一半 */\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-grid {\n  display: grid !important;\n  grid-template-columns: repeat(2, minmax(0, 1fr)) !important;\n  grid-auto-rows: minmax(0, auto) !important;\n  align-content: start !important;\n  flex: 0 0 auto !important;\n  width: 100% !important;\n  max-height: 236px !important;\n  overflow-x: hidden !important;\n  overflow-y: auto !important;\n  gap: 8px !important;\n  padding: 2px !important;\n  scrollbar-width: none !important;\n  overscroll-behavior: contain !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-grid::-webkit-scrollbar {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-card {\n  width: 100% !important;\n  min-width: 0 !important;\n  max-width: 100% !important;\n  min-height: 104px !important;\n  padding: 12px !important;\n  border-radius: 16px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-card-cover {\n  width: 34px !important;\n  height: 34px !important;\n  margin-bottom: 4px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-card strong {\n  font-size: 13px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-main {\n  display: flex !important;\n  flex-direction: column !important;\n  flex: 1 1 auto !important;\n  min-height: 0 !important;\n  width: 100% !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-toolbar {\n  flex: 0 0 auto !important;\n  padding: 6px 2px 8px !important;\n  overflow-x: auto !important;\n  scrollbar-width: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-toolbar::-webkit-scrollbar {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-import-actions {\n  display: flex !important;\n  flex-wrap: nowrap !important;\n  gap: 8px !important;\n  width: max-content !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-import-actions button {\n  flex: 0 0 auto !important;\n  height: 34px !important;\n  min-height: 34px !important;\n  padding: 0 12px !important;\n  font-size: 12px !important;\n  white-space: nowrap !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-detail {\n  flex: 1 1 auto !important;\n  min-height: 0 !important;\n  border-radius: 16px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-song-number {\n  width: 20px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-song-time,\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask .mineradio-library-song-source {\n  display: none !important;\n}\n\n/* 「本地」页：收起歌单卡，只剩本地歌曲列表和操作条，贴近 Folia 的本地音乐页 */\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-grid {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-content {\n  padding-top: 4px !important;\n}\n\n/* ========== 18. 竖屏搜索：最近搜索下拉照 Folia 的卡片样式 ========== */\nhtml[data-mineradio-layout=\"portrait\"] body #search-area #search-results {\n  position: fixed !important;\n  top: calc(env(safe-area-inset-top, 0px) + 58px) !important;\n  right: 18px !important;\n  left: auto !important;\n  width: min(80vw, 304px) !important;\n  max-width: calc(100vw - 36px) !important;\n  max-height: 62vh !important;\n  z-index: 42 !important;\n  transform: none !important;\n  overflow: hidden !important;\n}\n\n/* 搜索结果整页：从平台 tab 下面铺到胶囊上方 */\nhtml[data-mineradio-layout=\"portrait\"] body.mr-search-open #search-area #search-results:not(.search-history-surface) {\n  position: fixed !important;\n  top: calc(env(safe-area-inset-top, 0px) + 152px) !important;\n  left: 16px !important;\n  right: 16px !important;\n  bottom: calc(env(safe-area-inset-bottom, 0px) + 92px) !important;\n  width: auto !important;\n  max-width: none !important;\n  max-height: none !important;\n  height: auto !important;\n  transform: none !important;\n  z-index: 42 !important;\n  display: block !important;\n  opacity: 1 !important;\n  visibility: visible !important;\n  background: #17181c !important;\n  border: 1px solid rgba(255, 255, 255, .10) !important;\n  border-radius: 22px !important;\n  box-shadow: 0 18px 50px rgba(0, 0, 0, .45) !important;\n  backdrop-filter: none !important;\n  -webkit-backdrop-filter: none !important;\n  overflow-y: auto !important;\n  overscroll-behavior: contain !important;\n  padding: 6px !important;\n}\n\n/* 平台 tab 抬到搜索页顶部，方便换平台搜 */\nhtml[data-mineradio-layout=\"portrait\"] body.mr-search-open #search-area .search-mode-tabs {\n  display: flex !important;\n  position: fixed !important;\n  top: calc(env(safe-area-inset-top, 0px) + 102px) !important;\n  left: 16px !important;\n  right: 16px !important;\n  width: auto !important;\n  height: 44px !important;\n  align-items: center !important;\n  flex-wrap: nowrap !important;\n  gap: 6px !important;\n  overflow-x: auto !important;\n  overflow-y: hidden !important;\n  z-index: 43 !important;\n  margin: 0 !important;\n  padding: 5px 6px !important;\n  background: #17181c !important;\n  border: 1px solid rgba(255, 255, 255, .10) !important;\n  border-radius: 18px !important;\n  box-shadow: 0 12px 30px rgba(0, 0, 0, .4) !important;\n  backdrop-filter: none !important;\n  -webkit-backdrop-filter: none !important;\n  scrollbar-width: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body.mr-search-open #search-area .search-mode-tabs::-webkit-scrollbar {\n  display: none !important;\n  width: 0 !important;\n  height: 0 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body.mr-search-open #search-area .search-mode-tabs button {\n  flex: 0 0 auto !important;\n  height: 30px !important;\n  min-height: 30px !important;\n  padding: 0 14px !important;\n  border: 0 !important;\n  border-radius: 15px !important;\n  background: rgba(255, 255, 255, .08) !important;\n  background-image: none !important;\n  color: #9b9b9f !important;\n  font-size: 12px !important;\n  line-height: 30px !important;\n  box-shadow: none !important;\n  backdrop-filter: none !important;\n  -webkit-backdrop-filter: none !important;\n  text-shadow: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body.mr-search-open #search-area .search-mode-tabs button.active {\n  background: #fff !important;\n  color: #101012 !important;\n  font-weight: 600 !important;\n}\n\n/* 结果行：封面 + 歌名/歌手，右侧按钮收成两个小圆点 */\nhtml[data-mineradio-layout=\"portrait\"] body #search-area #search-results:not(.search-history-surface) .search-song-row,\nhtml[data-mineradio-layout=\"portrait\"] body #search-area #search-results:not(.search-history-surface) .search-result-row {\n  padding: 8px 6px !important;\n  border-radius: 14px !important;\n  min-height: 58px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #search-area #search-results:not(.search-history-surface) img {\n  width: 44px !important;\n  height: 44px !important;\n  border-radius: 10px !important;\n}\n\n/* 历史态：Folia 的「最近搜索」卡片 */\nhtml[data-mineradio-layout=\"portrait\"] body #search-area .search-history {\n  background: #1c1c1e !important;\n  border: 1px solid rgba(255, 255, 255, .08) !important;\n  border-radius: 18px !important;\n  padding: 12px 14px 14px !important;\n  box-shadow: 0 18px 44px rgba(0, 0, 0, .5) !important;\n  backdrop-filter: none !important;\n  -webkit-backdrop-filter: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #search-area .search-history-head {\n  display: flex !important;\n  align-items: center !important;\n  justify-content: space-between !important;\n  padding: 0 0 10px !important;\n  font-size: 12px !important;\n  color: #8e8e93 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #search-area .search-history-clear {\n  background: transparent !important;\n  border: 0 !important;\n  padding: 0 !important;\n  font-size: 12px !important;\n  color: #8e8e93 !important;\n  height: auto !important;\n  min-width: 0 !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #search-area .search-history-list {\n  display: flex !important;\n  flex-direction: row !important;\n  flex-wrap: wrap !important;\n  align-items: flex-start !important;\n  gap: 8px !important;\n  max-height: 38vh !important;\n  overflow-y: auto !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] body #search-area .search-history-chip {\n  flex: 0 0 auto !important;\n  width: auto !important;\n  min-width: 0 !important;\n  max-width: 100% !important;\n  height: 30px !important;\n  line-height: 30px !important;\n  padding: 0 13px !important;\n  border: 0 !important;\n  border-radius: 15px !important;\n  background: rgba(255, 255, 255, .09) !important;\n  color: #e6e6eb !important;\n  font-size: 12px !important;\n  overflow: hidden !important;\n  text-overflow: ellipsis !important;\n  white-space: nowrap !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-toolbar {\n  justify-content: flex-end !important;\n  gap: 8px !important;\n  padding: 4px 2px 10px !important;\n}\n\n/* 只留「导入文件夹 / 导入歌单 / 同步」三项，其余收进代码里不显示 */\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-import-actions button:not([data-library-action=\"folder\"]):not([data-library-action=\"import\"]):not([data-library-action=\"sync\"]) {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-import-actions button {\n  height: 34px !important;\n  padding: 0 14px !important;\n  border-radius: 17px !important;\n  font-size: 12px !important;\n}\n\n/* 大卡片：横向滚动，单张 178×232，封面撑满上半部分 */\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-grid {\n  display: flex !important;\n  flex-direction: row !important;\n  flex-wrap: nowrap !important;\n  max-height: none !important;\n  overflow-x: auto !important;\n  overflow-y: hidden !important;\n  gap: 12px !important;\n  padding: 2px 2px 8px !important;\n  scrollbar-width: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-grid::-webkit-scrollbar {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-card {\n  flex: 0 0 178px !important;\n  width: 178px !important;\n  min-width: 178px !important;\n  max-width: 178px !important;\n  min-height: 232px !important;\n  padding: 12px !important;\n  border-radius: 20px !important;\n  display: flex !important;\n  flex-direction: column !important;\n  align-items: stretch !important;\n  justify-content: flex-end !important;\n  gap: 4px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-card-cover {\n  width: 100% !important;\n  height: 154px !important;\n  margin-bottom: 8px !important;\n  border-radius: 14px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-card strong {\n  font-size: 15px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-card small {\n  font-size: 11px !important;\n}\n\n/* 详情标题居中，像 Folia 那样单独一行 */\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-detail-head {\n  justify-content: center !important;\n  text-align: center !important;\n  gap: 10px !important;\n  padding: 10px 12px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-detail-title {\n  flex: 0 1 auto !important;\n  text-align: center !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #mineradio-library-mask.mr-local-only .mineradio-library-detail-head h3 {\n  justify-content: center !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] body #playlist-panel,\nhtml[data-mineradio-layout=\"portrait\"] body #fx-panel {\n  border-radius: 22px !important;\n  background: #17181c !important;\n  border: 1px solid rgba(255, 255, 255, .10) !important;\n  box-shadow: 0 18px 46px rgba(0, 0, 0, .45) !important;\n  backdrop-filter: none !important;\n  -webkit-backdrop-filter: none !important;\n}\n\n/* 歌单面板用 left 定位（top/height/bottom 由 JS 锚定），左右拉通即可 */\nhtml[data-mineradio-layout=\"portrait\"] body #playlist-panel {\n  left: 16px !important;\n  right: 16px !important;\n  width: auto !important;\n  max-width: none !important;\n}\n\n/* 设置面板靠 right + scale(1.12) 从右侧滑入，放大后左边会溢出屏幕，\n   竖屏下改成左右各 16px、缩放归 1（portrait 的 zoom 已经是 1，不需要补偿） */\nhtml[data-mineradio-layout=\"portrait\"] body #fx-panel.show,\nhtml[data-mineradio-layout=\"portrait\"] body #fx-panel.peek {\n  left: 16px !important;\n  right: 16px !important;\n  width: auto !important;\n  max-width: none !important;\n  transform: translateY(0) scale(1) !important;\n}\n\n/* 两个面板都从标题栏下面开始、到胶囊上缘结束 */\nhtml[data-mineradio-layout=\"portrait\"] body #playlist-panel.show,\nhtml[data-mineradio-layout=\"portrait\"] body #fx-panel.show {\n  top: calc(env(safe-area-inset-top, 0px) + 100px) !important;\n  bottom: calc(env(safe-area-inset-bottom, 0px) + 92px) !important;\n  height: auto !important;\n  max-height: none !important;\n}\n\n/* 设置面板顶部的「视觉控制台」标题在竖屏下删掉，省出来的高度给内容 */\nhtml[data-mineradio-layout=\"portrait\"] body #fx-panel .fx-head {\n  display: none !important;\n}\n\n/* 视觉控制台的右下角悬浮按钮在竖屏不需要（tab 行已经有「设置」入口） */\nhtml[data-mineradio-layout=\"portrait\"] body #fx-fab,\nhtml[data-mineradio-layout=\"portrait\"] body #fx-fab.active {\n  display: none !important;\n}\n\n/* 封面选歌插件打开时会隐藏 #search-area / #bottom-bar 等，但它不知道竖屏多了一层顶栏，\n   这里补上，否则 Mineradio 标题和 tab 行会压在封面墙上面 */\nhtml[data-mineradio-layout=\"portrait\"].mr-cover-wall-open #folia-shell {\n  display: none !important;\n}\n\n/* 插件 iframe 自身是透明背景，竖屏下首页会从卡片缝隙里透出来，压成一块深色底 */\nhtml[data-mineradio-layout=\"portrait\"].mr-cover-wall-open iframe[data-mr-plugin=\"cover-wall\"] {\n  background: #0b0b0d !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"].mr-cover-wall-open #playlist-panel {\n  visibility: hidden !important;\n  pointer-events: none !important;\n}\n\n/* 播放栏自动隐藏时，顶栏和搜索框一起收起（同一套逻辑） */\nhtml[data-mineradio-layout=\"portrait\"].mr-controls-hidden #folia-shell,\nhtml[data-mineradio-layout=\"portrait\"].mr-controls-hidden body #search-area {\n  opacity: 0 !important;\n  visibility: hidden !important;\n  pointer-events: none !important;\n  transition: opacity .32s cubic-bezier(.16, 1, .3, 1), visibility .32s !important;\n}\n\n/* 舞台歌词在竖屏会横向溢出：允许换行、压小字号、容器裁切 */\nhtml[data-mineradio-layout=\"portrait\"] #stage-lyrics {\n  width: 100vw !important;\n  max-width: 100vw !important;\n  left: 0 !important;\n  right: 0 !important;\n  overflow: hidden !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] .stage-lyric-line {\n  font-size: clamp(22px, 6.2vw, 42px) !important;\n  letter-spacing: 1px !important;\n  white-space: normal !important;\n  word-break: break-word !important;\n  width: auto !important;\n  max-width: 86vw !important;\n  padding: 0 14px !important;\n  box-sizing: border-box !important;\n  line-height: 1.25 !important;\n}\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask {\n  padding: calc(env(safe-area-inset-top, 0px) + 100px) 16px calc(env(safe-area-inset-bottom, 0px) + 92px) 16px !important;\n  align-items: stretch !important;\n  background: transparent !important;\n  backdrop-filter: none !important;\n  -webkit-backdrop-filter: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask .home-platform-recommend-modal {\n  width: 100% !important;\n  max-width: 100% !important;\n  height: 100% !important;\n  max-height: 100% !important;\n  border-radius: 22px !important;\n  background: #17181c !important;\n  border: 1px solid rgba(255, 255, 255, .10) !important;\n  box-shadow: 0 18px 50px rgba(0, 0, 0, .45) !important;\n  padding: 0 !important;\n  display: flex !important;\n  flex-direction: column !important;\n  overflow: hidden !important;\n}\n\n/* 榜单行原来是 5 列 grid：46 序号 + 50 封面 + 歌名 + 65 来源 + 112 按钮，\n   竖屏可用宽度只有 ~314，歌名被挤到只剩 40px。这里砍成 4 列并去掉来源列。 */\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask .home-ranking-row {\n  grid-template-columns: 30px 44px minmax(0, 1fr) auto !important;\n  gap: 8px !important;\n  padding: 8px 10px !important;\n  min-height: 62px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask .home-ranking-source {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask .home-ranking-number {\n  font-size: 14px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask .home-ranking-cover {\n  width: 44px !important;\n  height: 44px !important;\n  border-radius: 11px !important;\n}\n\n/* 歌名和歌手上下两行，横向更省宽 */\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask .home-ranking-song-copy {\n  flex-direction: column !important;\n  align-items: flex-start !important;\n  justify-content: center !important;\n  gap: 2px !important;\n  white-space: nowrap !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask .home-ranking-song-copy strong {\n  max-width: 100% !important;\n  font-size: 14px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask .home-ranking-song-copy small {\n  max-width: 100% !important;\n  font-size: 11px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask .home-ranking-row-actions {\n  gap: 4px !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #home-platform-recommend-mask .home-ranking-row-actions button {\n  width: 28px !important;\n  min-width: 28px !important;\n  height: 28px !important;\n  min-height: 28px !important;\n  padding: 0 !important;\n  font-size: 12px !important;\n  border-radius: 9px !important;\n}\n\n/* ========== 20. 预设卡片：只允许 active 一种高亮 ==========\n   1) .preset-card.switching::after 的光晕动画没有 forwards，结束后会留下静态径向渐变；\n   2) index.css 给 .preset-card 设了 backdrop-filter: blur(...)，多张卡片连续模糊时\n      WebView 会画出半块灰色条带，看起来像「某张卡只亮一半」。\n   两条都在竖屏禁掉，高亮只走 active 的边框/底色/阴影。 */\nhtml[data-mineradio-layout=\"portrait\"] #preset-grid .preset-card {\n  backdrop-filter: none !important;\n  -webkit-backdrop-filter: none !important;\n  background: rgba(0, 0, 0, .72) !important;\n  border-color: rgba(255, 255, 255, .07) !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #preset-grid .preset-card::before,\nhtml[data-mineradio-layout=\"portrait\"] #preset-grid .preset-card::after {\n  content: none !important;\n  display: none !important;\n  animation: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #preset-grid .preset-card .pc-bg {\n  display: none !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #preset-grid .preset-card.active {\n  background: rgba(var(--fc-accent-rgb), .10) !important;\n  border-color: rgba(var(--fc-accent-rgb), .40) !important;\n  box-shadow: 0 0 0 1px rgba(var(--fc-accent-rgb), .22) !important;\n}\n\nhtml[data-mineradio-layout=\"portrait\"] #preset-grid .preset-card.switching {\n  border-color: rgba(var(--fc-accent-rgb), .34) !important;\n  background: rgba(var(--fc-accent-rgb), .10) !important;\n}\n\n/* plugins/portrait-mode/controls.css: direction buttons belong to the plugin. */\n.mr-orientation-button {\n  touch-action: manipulation;\n}\n/* 竖屏：放在下一首按钮右边（next-btn 在 50% + 22px，宽约 24px）。 */\nhtml[data-mineradio-layout=\"portrait\"] body #bottom-bar #mr-orientation-playback {\n  position: absolute !important;\n  left: calc(50% + 52px) !important;\n  top: 50% !important;\n  transform: translateY(-50%) !important;\n  z-index: 2 !important;\n}\n");
  /*
 * Folia 风格竖屏外壳（第一阶段）
 *
 * 只做一件事：竖屏时在页面顶部挂一条 Folia 式顶栏（标题 + 齿轮 + tab 行）。
 * 横屏不生成任何节点，横屏 DOM 与样式零改动。
 * tab 都复用 Mineradio 已有入口函数，不新建数据通路。
 */
function installPortraitShell(global) {
  'use strict';

  // Every resource is scoped to this installation, so disabling/re-enabling the
  // plugin cannot leave callbacks behind or duplicate listeners.
  var disposed = false;
  var timeouts = new Set();
  var intervals = new Set();
  var frames = new Set();
  var observers = [];
  var listeners = [];
  var searchWatched = null;
  var controlsWatched = null;
  function setTimeout(fn, delay) {
    var id = global.setTimeout(function () { timeouts.delete(id); if (!disposed) fn(); }, delay);
    timeouts.add(id);
    return id;
  }
  function clearTimeout(id) { global.clearTimeout(id); timeouts.delete(id); }
  function setInterval(fn, delay) {
    var id = global.setInterval(function () { if (!disposed) fn(); }, delay);
    intervals.add(id);
    return id;
  }
  function clearInterval(id) { global.clearInterval(id); intervals.delete(id); }
  function requestAnimationFrame(fn) {
    var id = global.requestAnimationFrame(function () { frames.delete(id); if (!disposed) fn(); });
    frames.add(id);
    return id;
  }
  function ManagedMutationObserver(fn) {
    var observer = new global.MutationObserver(function () { if (!disposed) fn(); });
    observers.push(observer);
    return observer;
  }
  function on(target, name, fn, options) {
    target.addEventListener(name, fn, options);
    listeners.push(function () { target.removeEventListener(name, fn, options); });
  }

  var root = document.documentElement;
  var shell = null;
  var currentTab = 'home';

  var TABS = [
    { key: 'home', label: '首页' },
    { key: 'lib', label: '曲库' },
    { key: 'playlist', label: '歌单' },
    { key: 'explore', label: '探索' },
    { key: 'settings', label: '设置' }
  ];

  /* 「本地」= 音乐库里的本地音乐歌单；点进去后把歌单卡收起来，只留本地歌曲列表，
     这样看起来就是 Folia 的「本地」页而不是音乐库首页 */
  function pickLocalCollection() {
    var cards = document.querySelectorAll('#mineradio-library-grid .mineradio-library-card');
    for (var i = 0; i < cards.length; i += 1) {
      if ((cards[i].textContent || '').indexOf('本地音乐') >= 0) {
        cards[i].click();
        break;
      }
    }
    var mask = document.getElementById('mineradio-library-mask');
    if (mask) mask.classList.add('mr-local-only');
    var h2 = document.getElementById('mineradio-library-title');
    if (h2) h2.textContent = '本地音乐';
  }

  function clearLocalOnly() {
    var mask = document.getElementById('mineradio-library-mask');
    if (mask) mask.classList.remove('mr-local-only');
    var h2 = document.getElementById('mineradio-library-title');
    if (h2) h2.textContent = '音乐库';
  }

  /* openMineradioLibrary 内部会 render()，任何一步抛异常都会让面板打不开；
     这里吞掉异常并在后面强制补一次 open 类兜底 */
  function ensureLibraryOpen() {
    var mask = document.getElementById('mineradio-library-mask');
    if (mask && mask.classList.contains('open')) return;
    try {
      if (typeof global.openMineradioLibrary === 'function') global.openMineradioLibrary();
    } catch (e) { }
    setTimeout(function () {
      var m = document.getElementById('mineradio-library-mask');
      if (m && !m.classList.contains('open')) m.classList.add('open');
    }, 150);
  }

  /* 切 tab 之前把其他浮层收掉。except 是要打开的那一个：不能连它也一起关，
     否则「先关再开」会被面板的开关动画锁吞掉，表现为点了没反应。 */
  function closeAllViews(except) {
    var calls = [
      ['closeMineradioLibrary', null, 'lib'],
      ['toggleFxPanel', false, 'settings'],
      ['togglePlaylistPanel', false, 'playlist'],
      ['closeHomePlatformRecommendations', null, 'explore']
    ];
    for (var i = 0; i < calls.length; i += 1) {
      if (calls[i][2] === except) continue;
      try {
        var fn = global[calls[i][0]];
        if (typeof fn === 'function') {
          if (calls[i][1] === null) fn();
          else fn(calls[i][1]);
        }
      } catch (e) { }
    }
    var results = document.getElementById('search-results');
    if (results) results.classList.remove('show');
    if (document.documentElement.classList.contains('mr-cover-wall-open')) {
      var wallBtn = document.getElementById('cover-wall-toggle-btn');
      if (wallBtn) wallBtn.click();
    }
  }

  function runTab(key) {
    closeAllViews(key);
    if (key === 'home') {
      try { if (typeof global.goHome === 'function') global.goHome(); } catch (e) { }
      return;
    }
    if (key === 'lib') {
      clearLocalOnly();
      ensureLibraryOpen();
      return;
    }
    if (key === 'playlist') {
      try { if (typeof global.togglePlaylistPanel === 'function') global.togglePlaylistPanel(true); } catch (e) { }
      return;
    }
    if (key === 'explore') {
      try { if (typeof global.openHomeDashboardCharts === 'function') global.openHomeDashboardCharts(); } catch (e) { }
      return;
    }
    if (key === 'settings') {
      try { if (typeof global.toggleFxPanel === 'function') global.toggleFxPanel(true); } catch (e) { }
    }
  }

  function gearSvg() {
    return '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" '
      + 'stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="12" r="3.1"></circle>'
      + '<path d="M12 3.2v2.1M12 18.7v2.1M3.2 12h2.1M18.7 12h2.1M5.9 5.9l1.5 1.5M16.6 16.6l1.5 1.5'
      + 'M18.1 5.9l-1.5 1.5M7.4 16.6l-1.5 1.5"></path></svg>';
  }

  function build() {
    if (shell || !document.body) return;
    shell = document.createElement('div');
    shell.id = 'folia-shell';

    var html = '<div id="folia-topbar"><div id="folia-brand">Mineradio</div></div>'
      + '<nav id="folia-tabs" role="tablist">';

    for (var i = 0; i < TABS.length; i += 1) {
      html += '<button type="button" role="tab" data-folia-tab="' + TABS[i].key + '"'
        + (TABS[i].key === currentTab ? ' class="is-active"' : '') + '>' + TABS[i].label + '</button>';
    }
    html += '</nav>';

    shell.innerHTML = html;
    document.body.appendChild(shell);

    shell.addEventListener('click', function (event) {
      var brand = event.target.closest ? event.target.closest('#folia-brand') : null;
      if (brand) {
        // 左上角 Mineradio 字样 = 登录入口；先收起所有浮层，避免登录弹窗叠在设置面板上
        closeAllViews();
        try {
          if (typeof global.showLoginModal === 'function') global.showLoginModal({ source: 'folia-brand' });
        } catch (e) { }
        return;
      }
      var tab = event.target.closest ? event.target.closest('[data-folia-tab]') : null;
      if (!tab) return;
      var key = tab.getAttribute('data-folia-tab');
      currentTab = key;
      var buttons = shell.querySelectorAll('[data-folia-tab]');
      for (var i = 0; i < buttons.length; i += 1) {
        buttons[i].classList.toggle('is-active', buttons[i] === tab);
      }
      runTab(key);
    });
  }

  function destroy() {
    if (shell && shell.parentNode) shell.parentNode.removeChild(shell);
    shell = null;
    // The home card is shared with landscape; remove everything this view added.
    document.querySelectorAll('#empty-home .mr-now-layer').forEach(function (node) { node.remove(); });
    document.querySelectorAll('#empty-home .mr-now-card').forEach(function (card) { card.classList.remove('mr-now-card'); });
    root.style.removeProperty('--mr-now-cover');
    clearLocalOnly();
  }

  function isPortrait() {
    return root.getAttribute('data-mineradio-layout') === 'portrait';
  }

  /* 播放栏封面在「恢复上次歌曲」这条路径上不会被写入（只有真正走一遍封面管线
     才会 setControlCoverSrc），这里补一次：依次从缩略图 / 下一首卡兜底拿图。 */
  function bgOf(el) {
    if (!el) return '';
    var v = (el.style && el.style.backgroundImage) || '';
    if (!v || v === 'none') {
      try { v = window.getComputedStyle(el).backgroundImage || ''; } catch (e) { v = ''; }
    }
    return (v && v !== 'none') ? v : '';
  }

  function resolveFallbackCover() {
    var thumb = document.getElementById('thumb-cover');
    var src = thumb ? (thumb.getAttribute('src') || '') : '';
    if (src && src.indexOf('data:,') !== 0) return 'url("' + src.replace(/"/g, '\\"') + '")';

    var nb = bgOf(document.getElementById('home-next-cover'));
    if (nb) return nb;

    var db = bgOf(document.querySelector('#home-discovery-list .home-discovery-cover'));
    if (db) return db;

    var rb = bgOf(document.querySelector('#home-tile-row .home-tile-cover, #home-tile-row img'));
    if (rb) return rb;

    return '';
  }

  var COVER_CACHE_KEY = 'mr-folia-last-cover-v1';

  function nowPlayingKey() {
    var t = document.getElementById('control-title-text');
    var a = document.getElementById('control-artist');
    var name = ((t && t.textContent) || '').trim();
    var artist = ((a && a.textContent) || '').trim();
    return name ? (name + '|' + artist) : '';
  }

  function saveCoverCache(bg) {
    var key = nowPlayingKey();
    if (!key || !bg) return;
    try { localStorage.setItem(COVER_CACHE_KEY, JSON.stringify({ key: key, bg: bg })); } catch (e) { }
  }

  function loadCoverCache() {
    var key = nowPlayingKey();
    if (!key) return '';
    try {
      var data = JSON.parse(localStorage.getItem(COVER_CACHE_KEY) || 'null');
      if (data && data.key === key && data.bg && data.bg.indexOf('url(') === 0) return data.bg;
    } catch (e) { }
    return '';
  }

  /* 上次播放快照里存着本地歌曲的封面地址（/api/local-cover?path=…），
     同源直连就能出图；不要走 loadCoverFromUrl，它会把 http 地址再套一层 /api/cover 代理。 */
  function coverFromSnapshot() {
    var nameEl = document.getElementById('control-title-text');
    var name = nameEl ? (nameEl.textContent || '').trim() : '';
    try {
      var data = JSON.parse(localStorage.getItem('mineradio-last-playback-v1') || 'null');
      var cur = data && data.current;
      if (!cur || !cur.cover) return '';
      var curName = String(cur.name || '').trim();
      if (name && curName && curName !== name) return '';
      return String(cur.cover);
    } catch (e) { return ''; }
  }

  /* 封面统一写进一个 CSS 变量，由竖屏样式表消费。
     原因：Mineraido 的封面管线在恢复失败时会 setControlCoverSrc('') 把内联背景清掉，
     直接写 element.style.backgroundImage 会被它覆盖，变量则不会。 */
  function ensureControlCover() {
    var cover = document.getElementById('control-cover');
    var src = '';
    if (cover) {
      var bg = (cover.style && cover.style.backgroundImage) || '';
      if (!bg || bg === 'none') {
        try { bg = window.getComputedStyle(cover).backgroundImage || ''; } catch (e) { bg = ''; }
      }
      // cover-empty 时它是占位渐变（radial-gradient…），不是真封面，必须只认 url(...)
      if (bg && bg.indexOf('url(') === 0) src = bg;
    }
    if (!src) {
      var cached = loadCoverCache();
      if (cached) src = cached;
    }
    if (!src) {
      var snap = coverFromSnapshot();
      if (snap) src = 'url("' + snap.replace(/"/g, '\\"') + '")';
    }
    if (!src) {
      var fb = resolveFallbackCover();
      if (fb) src = fb;
    }
    if (src) {
      document.documentElement.style.setProperty('--mr-now-cover', src);
      saveCoverCache(src);
    }
    return src;
  }

  /* 第一张卡改成「正在播放」：封面 + 歌名/歌手。
     用自己插入的覆盖层，避免和 Mineradio 首页脚本反复改写同一批节点。 */
  function paintCardArt() {
    if (!isPortrait()) return;
    suppressPortraitShelf();
    // 先算封面：这一步不依赖首页卡片是否存在，卡片没渲染出来也要把播放栏封面点亮
    ensureControlCover();
    if (!shell) return;
    var card = document.querySelector('#empty-home .home-card');
    if (!card) return;

    card.classList.add('mr-now-card');

    var layer = card.querySelector('.mr-now-layer');
    if (!layer) {
      layer = document.createElement('div');
      layer.className = 'mr-now-layer';
      layer.innerHTML = '<span class="mr-now-kicker">正在播放</span>'
        + '<span class="mr-now-title"></span>'
        + '<span class="mr-now-artist"></span>';
      card.appendChild(layer);
    }

    // Portrait CSS reads --mr-now-cover; leave the shared card's inline art alone.

    var nowTitle = document.getElementById('control-title-text');
    var nowArtist = document.getElementById('control-artist');
    var name = nowTitle ? (nowTitle.textContent || '').trim() : '';
    var artist = nowArtist ? (nowArtist.textContent || '').trim() : '';

    var titleEl = layer.querySelector('.mr-now-title');
    var artistEl = layer.querySelector('.mr-now-artist');
    var newTitle = name || '尚未开始播放';
    var newArtist = artist || '从曲库挑一首开始';
    if (titleEl && titleEl.textContent !== newTitle) titleEl.textContent = newTitle;
    if (artistEl && artistEl.textContent !== newArtist) artistEl.textContent = newArtist;
  }

  // Hide only the runtime shelf. setShelfMode would overwrite the user's saved
  // landscape mode, presence and pin settings, even with { user: false }.
  var portraitShelfManager = null;
  function suppressPortraitShelf() {
    if (!isPortrait()) return;
    var manager = global.shelfManager;
    if (!manager || typeof manager.setMode !== 'function') return;
    portraitShelfManager = manager;
    if (!manager.getMode || manager.getMode() !== 'off') manager.setMode('off');
  }
  function restoreLandscapeShelf() {
    var manager = portraitShelfManager;
    portraitShelfManager = null;
    if (!manager || manager !== global.shelfManager) return;
    if (manager.getMode && manager.getMode() !== 'off') return;
    if (global.fx && /^(off|side|stage)$/.test(global.fx.shelf)) manager.setMode(global.fx.shelf);
  }

  /* 竖屏顶栏搜索框保持 Mineradio 原来的在线搜索行为，只做外观对齐 Folia，不拦截焦点 */

  /* 搜索是否处于「有结果」状态，交给 body 上的 mr-search-open 类标记，
     样式侧据此把结果铺成整页、把平台 tab 抬到页面顶部 */
  function watchSearchState() {
    if (!isPortrait()) return;
    var results = document.getElementById('search-results');
    if (!results || searchWatched === results) return;
    searchWatched = results;
    var syncOpen = function () {
      document.body.classList.toggle('mr-search-open', isPortrait() && results.classList.contains('show'));
    };
    try {
      new ManagedMutationObserver(syncOpen).observe(results, { attributes: true, attributeFilter: ['class'] });
    } catch (e) { }
    syncOpen();
  }

  /* 顶栏和搜索框跟着播放栏一起自动隐藏：播放栏被 Mineradio 的自动隐藏逻辑
     打上 .soft-hidden（或 body 被 home-controls-locked 锁住）时，一并收起 */
  function watchControlsVisibility() {
    var bar = document.getElementById('bottom-bar');
    if (!bar || controlsWatched === bar) return;
    controlsWatched = bar;
    var syncVis = function () {
      var hidden = isPortrait() && (bar.classList.contains('soft-hidden')
        || document.body.classList.contains('home-controls-locked'));
      document.documentElement.classList.toggle('mr-controls-hidden', hidden);
    };
    try {
      new ManagedMutationObserver(syncVis).observe(bar, { attributes: true, attributeFilter: ['class'] });
    } catch (e) { }
    syncVis();
  }

  /* 顶栏 / 搜索框的空闲自动隐藏。
     Mineradio 的播放栏是「6 秒无操作自动淡出、碰屏幕回来」，这里照同一套节奏做：
     4.2 秒没操作就收起顶栏和搜索框，任何触摸/按键先唤回来。 */
  var topIdleTimer = 0;

  function topOverlayOpen() {
    var mask = document.getElementById('mineradio-library-mask');
    if (mask && mask.classList.contains('open')) return true;
    if (document.body.classList.contains('home-controls-locked')) return true;
    if (document.body.classList.contains('mr-search-open')) return true;
    var fx = document.getElementById('fx-panel');
    if (fx && fx.classList.contains('show')) return true;
    var pl = document.getElementById('playlist-panel');
    if (pl && pl.classList.contains('show')) return true;
    return false;
  }

  function isPlayingNow() {
    try {
      if (window.audio && typeof window.audio.paused === 'boolean') return !window.audio.paused;
    } catch (e) { }
    var els = document.querySelectorAll('audio');
    for (var i = 0; i < els.length; i += 1) {
      if (els[i] && !els[i].paused && !els[i].ended) return true;
    }
    // 兜底：看播放键图标——播放三角(path 以 M8 5v14 开头) vs 暂停双竖线
    var icon = document.querySelector('#play-icon path');
    var d = icon ? (icon.getAttribute('d') || '') : '';
    return !!d && d.indexOf('M8 5v14') === -1;
  }

  function scheduleTopIdle() {
    if (topIdleTimer) clearTimeout(topIdleTimer);
    if (!isPortrait()) return;
    topIdleTimer = setTimeout(function () {
      if (!isPortrait() || !shell || topOverlayOpen()) return;
      // 只在真正播放中才自动收起顶栏；暂停/未播放时保持常显
      if (!isPlayingNow()) return;
      document.documentElement.classList.add('mr-controls-hidden');
    }, 4200);
  }

  function wakeTop() {
    if (!isPortrait()) return;
    document.documentElement.classList.remove('mr-controls-hidden');
    scheduleTopIdle();
  }

  function installTopIdle() {
    if (installTopIdle.__done) return;
    installTopIdle.__done = true;
    on(document, 'pointerdown', wakeTop, true);
    on(document, 'keydown', wakeTop, true);
    scheduleTopIdle();
  }

  /* 预设卡片切换时会挂 .switching，它的 ::after 是一层光晕（动画只播 0.72s，但伪元素
     绑在类上）。设置列表是 innerHTML 重建的，新节点直接带着这个类出生，MutationObserver
     监听 attributes 抓不到，所以改用轮询：见到 switching 记下时间，超 3 秒仍在就摘掉。 */
  function watchPresetSwitching() {
    if (watchPresetSwitching.__done) return;
    watchPresetSwitching.__done = true;

    var grid = document.getElementById('preset-grid');
    if (!grid) return;

    /* 切换预设会在 WebView 里留下合成层残影（表现为某张卡只亮一半），
       滚动或遮挡后自己就没了 —— 说明是图层没刷新。切完主动触发一次重绘。 */
    var repaint = function () {
      if (!isPortrait()) return;
      var previousTransform = grid.style.transform;
      grid.style.transform = 'translateZ(0.01px)';
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          if (grid.style.transform === 'translateZ(0.01px)') grid.style.transform = previousTransform;
        });
      });
    };
    on(grid, 'click', function (ev) {
      if (!isPortrait()) return;
      var card = ev.target && ev.target.closest ? ev.target.closest('.preset-card') : null;
      if (!card) return;
      setTimeout(repaint, 900);
      setTimeout(repaint, 1800);
    }, true);

    setInterval(function () {
      if (!isPortrait()) return;
      var cards = document.querySelectorAll('.preset-card.switching');
      var now = Date.now();
      for (var i = 0; i < cards.length; i += 1) {
        var el = cards[i];
        if (!el.__mrSwitchAt) {
          el.__mrSwitchAt = now;
        } else if (now - el.__mrSwitchAt > 3000) {
          el.classList.remove('switching');
          el.__mrSwitchAt = 0;
          repaint();
        }
      }
    }, 1500);
  }

  /* 预设持久化对齐。
     Mineradio 存了两份：fx.preset（用户当前选择）和 playbackVisualPreset（启动预览/
     播放时用的）。启动预览阶段 saveLyricLayout() 写回的是 playbackVisualPreset，
     于是它会被反复固化，用户新选的预设下次启动就被顶掉。
     这里在预览结束后把两者对齐，并以 fx.preset 为准落盘一次。 */
  var presetSyncTimer = 0;
  function syncPortraitPreset() {
    if (syncPortraitPreset.__done || presetSyncTimer) return;
    presetSyncTimer = setTimeout(function () {
      presetSyncTimer = 0;
      if (!isPortrait()) return;
      syncPortraitPreset.__done = true;
      try {
        if (!window.fx || typeof window.fx.preset !== 'number') return;
        if (typeof window.playbackVisualPreset === 'number'
          && window.playbackVisualPreset !== window.fx.preset) {
          window.playbackVisualPreset = window.fx.preset;
        }
        if (typeof window.saveLyricLayout === 'function') {
          window.saveLyricLayout({ user: true, reason: 'portrait-preset-sync' });
        }
      } catch (e) { }
    }, 10000);
  }

  function sync() {
    if (disposed) return;
    if (isPortrait()) {
      startArtTimer();
      build();
      paintCardArt();
      suppressPortraitShelf();
      watchSearchState();
      watchControlsVisibility();
      watchPresetSwitching();
      installTopIdle();
      scheduleTopIdle();
      syncPortraitPreset();
    } else {
      if (artTimer) { clearInterval(artTimer); artTimer = 0; }
      if (topIdleTimer) { clearTimeout(topIdleTimer); topIdleTimer = 0; }
      if (presetSyncTimer) { clearTimeout(presetSyncTimer); presetSyncTimer = 0; }
      document.body.classList.remove('mr-search-open');
      document.documentElement.classList.remove('mr-controls-hidden');
      restoreLandscapeShelf();
      destroy();
    }
  }

  var artTimer = 0;
  function startArtTimer() {
    if (artTimer) return;
    artTimer = setInterval(paintCardArt, 2200);
  }

  if (document.readyState === 'loading') {
    on(document, 'DOMContentLoaded', sync);
  } else {
    sync();
  }

  var observer = new ManagedMutationObserver(sync);
  observer.observe(root, { attributes: true, attributeFilter: ['data-mineradio-layout'] });
  return function () {
    disposed = true;
    observers.forEach(function (item) { item.disconnect(); });
    listeners.forEach(function (remove) { remove(); });
    timeouts.forEach(function (id) { global.clearTimeout(id); });
    intervals.forEach(function (id) { global.clearInterval(id); });
    frames.forEach(function (id) { global.cancelAnimationFrame(id); });
    document.body.classList.remove('mr-search-open');
    root.classList.remove('mr-controls-hidden');
    restoreLandscapeShelf();
    destroy();
  };
}

  // plugins/portrait-mode/controls.js: install once per plugin lifecycle.
function installOrientationControls(api, controller) {
  var owned = [];
  function button(parent, id, icon) {
    if (!parent || document.getElementById(id)) return;
    var node = document.createElement('button');
    node.id = id;
    node.type = 'button';
    node.className = 'mr-orientation-button ' + (icon ? 'ctrl-btn' : 'fx-mini-btn ghost');
    if (icon) {
      node.innerHTML = '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="8" y="3" width="9" height="14" rx="2"/><path d="M4 9a8 8 0 0 0 7 12M7 18l4 3-4 2"/></svg>';
      node.setAttribute('data-orientation-icon', 'true');
    }
    node.setAttribute('data-mr-plugin', api.id);
    node.addEventListener('click', function () {
      var next = controller.get() === 'portrait' ? 'landscape' : 'portrait';
      if (!controller.set(next)) {
        if (typeof window.showToast === 'function') window.showToast('方向切换失败，请使用配套新版主程序并启用插件');
      }
      sync();
    });
    var modeButton = document.getElementById('play-mode-btn');
    if (icon && modeButton && modeButton.parentNode === parent) parent.insertBefore(node, modeButton.nextSibling);
    else parent.appendChild(node);
    owned.push(node);
  }
  function sync() {
    owned = owned.filter(function (node) { return node.isConnected; });
    var modeButton = document.getElementById('play-mode-btn');
    button(modeButton && modeButton.parentNode, 'mr-orientation-playback', true);
    owned.forEach(function (node) {
      if (node.tagName !== 'BUTTON') return;
      var text = controller.get() === 'portrait' ? '切换横屏' : '切换竖屏';
      if (!node.hasAttribute('data-orientation-icon') && node.textContent !== text) node.textContent = text;
      node.setAttribute('aria-label', text);
      node.title = text;
    });
  }
  var observer = new MutationObserver(sync);
  observer.observe(document.getElementById('plugin-list-container') || document.body, { childList: true, subtree: true });
  window.addEventListener('mineradio-orientation', sync);
  document.addEventListener('pluginListRendered', sync);
  sync();
  return function () {
    observer.disconnect();
    window.removeEventListener('mineradio-orientation', sync);
    document.removeEventListener('pluginListRendered', sync);
    owned.forEach(function (node) { node.remove(); });
  };
}

  var disposeShell = installPortraitShell(window);
  var disposeControls = installOrientationControls(api, controller);
  return function () {
    disposeControls();
    disposeShell();
    controller.set('landscape');
  };
});
