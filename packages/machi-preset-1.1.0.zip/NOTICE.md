Folia v0.7.27 原作者 chthollyphile，AGPL-3.0。Mineradio 适配层以 AGPL-3.0-only 分发。对应源码见随附源码包；第三方许可见 THIRD-PARTY-NOTICES.md。雾笺笔顺另遵循随附 Arphic Public License。
