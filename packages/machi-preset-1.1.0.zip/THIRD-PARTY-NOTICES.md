# Bundled dependencies

- @applemusic-like-lyrics/ttml 1.0.1 (AGPL-3.0-only): third-party/_applemusic-like-lyrics_ttml_1.0.1/LICENSE
- @xmldom/xmldom 0.9.12 (MIT): third-party/_xmldom_xmldom_0.9.12/LICENSE
- framer-motion 13.4.3 (MIT): third-party/framer-motion_13.4.3/LICENSE.md
- html-parse-stringify 4.0.1 (MIT): third-party/html-parse-stringify_4.0.1/LICENSE
- i18next 26.4.2 (MIT): third-party/i18next_26.4.2/LICENSE
- lucide-react 1.48.0 (ISC): third-party/lucide-react_1.48.0/LICENSE
- motion-dom 13.5.1 (MIT): third-party/motion-dom_13.5.1/LICENSE.md
- motion-utils 13.5.0 (MIT): third-party/motion-utils_13.5.0/LICENSE.md
- react-dom 19.3.0 (MIT): third-party/react-dom_19.3.0/LICENSE
- react-i18next 17.0.15 (MIT): third-party/react-i18next_17.0.15/LICENSE
- react 19.3.0 (MIT): third-party/react_19.3.0/LICENSE
- scheduler 0.28.0 (MIT): third-party/scheduler_0.28.0/LICENSE
- three 0.185.1 (MIT): third-party/three_0.185.1/LICENSE
- use-sync-external-store 1.7.0 (MIT): third-party/use-sync-external-store_1.7.0/LICENSE
- zustand 5.0.15 (MIT): third-party/zustand_5.0.15/LICENSE
