/* ============================================================
 *  LX 自定义音源 · 宿主接入层（integration.js）
 *  ------------------------------------------------------------
 *  本文件不改宿主一行代码，全部通过包裹宿主已有的全局函数实现接管。
 *  四个接入点：
 *
 *   ① 播放直链兜底 —— 包住 settleSourceFallbackTerminal
 *      官方链路（含跨平台换源）全部失败之后，才轮到我。必须早于
 *      宿主做「标记播放失败 / 清理 audio」，否则元素已被拆掉。
 *
 *   ② 未登录直连 —— 包住 playQueueAt
 *      一个平台账号都没登录时，官方链路会逐个平台超时（数秒到十几秒），
 *      用户体验是「点了没反应」。这里提前短路，直接走自定义音源。
 *
 *   ③ 搜索栏并入 —— 包住 fetchMusicSearchResults
 *      把音源的搜索结果并进官方结果里，标签显示为「自定义」。
 *
 *   ④ 全局状态 —— 挂 window.lxSource*，让面板与音源状态可见。
 *
 *  ⚠️ 为什么用 hook 而不是改 07-search.js 的 provider 白名单：
 *     白名单是硬编码的（netease/qq/kugou/qishui/spotify），改它就得重打 APK。
 *     hook 路线不改主程序，插件装上即用、卸载即还原。
 * ============================================================ */
(function () {
  'use strict';
  var W = window;

  var st = {
    installed: false,
    origSettle: null,
    origPlayQueueAt: null,
    // 只在「我们主动把播放交回宿主」的调用栈内为 true，用于防自激。
    // 绝不要把它持久化到 song 对象上（见 shouldTakeOver 的注释）。
    inTakeOver: false,
    origFetchSearch: null,
    origControlSourceProviders: null,
    origSongProviderKey: null,
    origSongSourceTagHtml: null,
    restoreFns: []
  };
  var warned = false;

  function log() {
    try {
      var a = Array.prototype.slice.call(arguments);
      a.unshift('%c[LX音源·接入]', 'color:#7ec8d8;font-weight:bold');
      console.log.apply(console, a);
    } catch (e) { }
  }
  function warn() {
    try {
      var a = Array.prototype.slice.call(arguments);
      a.unshift('%c[LX音源·接入]', 'color:#ffb300;font-weight:bold');
      console.warn.apply(console, a);
    } catch (e) { }
  }
  function noteErr(tag, e) {
    if (warned) return;
    warned = true;
    try { console.error('[LX音源·接入] ' + tag + '（仅报一次）:', e && (e.stack || e.message || e)); } catch (_) { }
  }

  function api() { return W.MrLxSource || null; }
  function ready() { var a = api(); return !!(a && a.isReady()); }

  /** 宿主是否还有任一平台登录态 */
  function anyPlatformLoggedIn() {
    try {
      if (typeof W.hasPlatformLogin === 'function') return W.hasPlatformLogin();
      if (typeof W.neteaseLoginStatus !== 'undefined' && W.neteaseLoginStatus && W.neteaseLoginStatus.loggedIn) return true;
      if (typeof W.qqLoginStatus !== 'undefined' && W.qqLoginStatus && W.qqLoginStatus.loggedIn) return true;
      if (typeof W.kugouLoginStatus !== 'undefined' && W.kugouLoginStatus && W.kugouLoginStatus.loggedIn) return true;
    } catch (e) { }
    return false;
  }

  /**
   * 这首歌要不要交给自定义音源？
   * 规则：
   *   - 音源已就绪才谈得上接管
   *   - 本地歌曲不走（本地有本地链路）
   *   - 已经在自定义音源上解析过的，不重复解析（防自激）
   */
  function shouldTakeOver(song) {
    if (!song || !ready()) return false;
    /* 🔴 防自激必须用「调用栈内」的标记，**不能持久化在 song 对象上**。
     *
     * 原实现是 `if (song.__lxResolved) return false;`，
     * 而 takeOver 里会给 song 打上 __lxResolved = true。
     * 问题：song 对象会被宿主复用（队列缓存 / 存档恢复），
     * 于是**切回一首已经播过的歌时**，这里的判定直接返回 false
     * ⇒ 不接管 ⇒ 宿主走官方链路 ⇒ 未登录只能播 30 秒试听。
     * 这正是用户反馈的「播几首 / 重进之后就变试听」。
     *
     * 现在改成：只有「我们正主动把播放交回宿主」的那一刻才拦一次（防自激），
     * 调用结束立刻复位，不影响任何后续切歌。
     */
    if (st.inTakeOver) return false;
    var t = String(song.type || '');
    if (t === 'local') return false;
    // 来源于自定义音源搜索的结果
    if (song.fromUserSource === true || song.sourceType === 'lxjs') return true;
    // 官方搜索结果但被标记了「优先走自定义音源」——对应"解析器型"音源
    if (song.preferUserSource === true) return true;
    return true;   // 音源就绪时，其余歌曲也可尝试（失败会自动退回官方）
  }

  /**
   * ★ 新增（宿主要求「不固定平台，能播就行」）：
   *   按歌名+歌手走**宿主的跨平台搜索**，找同一首歌在音源支持平台上的条目。
   *
   *   为什么需要这一步：
   *     用户的队列可能整条都来自汽水（qishui），而音源脚本只声明了
   *     tx/wy/kw/kg/mg 的 musicUrl 能力（纯解析器，没有 search）。
   *     汽水的歌没有这些平台的 songmid，脚本自然取不到流。
   *     这里用歌名去宿主的 /api/lx-source/search 把这首歌在 QQ/网易/… 上找回来，
   *     拿到带 songmid/mid/qqId 的条目再交给音源解析。
   *
   *   ⚠ 只在**直接解析失败后**才走这里，正常路径不受影响。
   *   ⚠ 宿主的 apiJson 不在插件作用域里，所以直接用 fetch。
   */
  var SEARCH_FALLBACK_TIMEOUT = 6000;   // 单次搜索上限（原来 8s，切歌时嫌慢）
  var SEARCH_FALLBACK_MAX = 6;          // 最多逐个尝试几条候选（原来 4 条，容易漏）

  function searchCrossPlatform(song) {
    var name = String((song && song.name) || '').trim();
    if (!name) return Promise.resolve([]);
    var artist = String((song && (song.artist || song.singer)) || '').trim();
    // ★ 不限平台：搜索范围跟随音源自己声明的平台（caps），不再写死 5 个 ——
    //   音源声明支持哪些平台就搜哪些，保证「任何平台的歌」都能在这里找到对应版本。
    var A0 = api();
    var caps = (A0 && A0.caps && A0.caps()) || {};
    var sources = Object.keys(caps).join(',') || 'tx,wy,kg,kw,mg';

    function runSearch(q) {
      var url = '/api/lx-source/search?q=' + encodeURIComponent(q)
        + '&limit=12&sources=' + encodeURIComponent(sources) + '&t=' + Date.now();
      return new Promise(function (resolve, reject) {
        var done = false;
        var timer = setTimeout(function () {
          if (done) return;
          done = true;
          reject(new Error('跨平台搜索超时'));
        }, SEARCH_FALLBACK_TIMEOUT);
        fetch(url, { cache: 'no-store' }).then(function (r) {
          return r.json();
        }).then(function (j) {
          if (done) return;
          done = true;
          clearTimeout(timer);
          resolve((j && j.songs) || []);
        }).catch(function (e) {
          if (done) return;
          done = true;
          clearTimeout(timer);
          reject(e);
        });
      });
    }

    var first = runSearch(artist ? (name + ' ' + artist) : name);
    /**
     * ★ 宽搜兜底：各平台对歌手的写法差异极大（英文名/别名/合唱歌手顺序/繁简），
     *   带歌手搜不到时再**只按歌名**搜一次。候选的严格匹配由 tryCandidates 负责，
     *   这里放宽召回不会引入错歌（最终仍要过歌名+歌手+时长三关）。
     */
    return first.catch(function (e) {
      warn('跨平台搜索失败：' + (e && e.message ? e.message : e));
      return [];
    }).then(function (list) {
      if ((list && list.length) || !artist) return list;
      return runSearch(name).catch(function () { return list; });
    });
  }

  /**
   * 判断歌曲的平台是否**能被当前音源直接解析**（即该平台在音源声明的 caps 内）。
   *
   * 用户要求「不管什么平台的歌都优先用导入的音源解析」，所以这里的分工是：
   *   · 平台在音源支持范围内 → 直连解析（最快路径）；
   *   · 不在范围内 / 认不出（Spotify、汽水、或字段缺失）→ 直接走「歌名 + 歌手
   *     跨平台搜索」，在音源支持的平台里找同一首歌 —— 而不是拿错的 ID 去白等一轮超时。
   */
  function songPlatformIsIdentifiable(song) {
    var A = api();
    var caps = (A && A.caps && A.caps()) || {};
    if (!song) return false;
    // 插件自己标记过的平台
    if (song.lxjsSourceCode && caps[song.lxjsSourceCode]) return true;
    var raw = String(song.provider || song.source || song.type || '').toLowerCase().trim();
    // 'lxjs' 是插件自己写回的标记，不是真实平台名，必须排除
    if (raw && raw !== 'unknown' && raw !== 'undefined' && raw !== 'null' && raw !== 'lxjs') {
      if (caps[raw]) return true;   // LX 短码直命
      var mapped = (A && A.PROVIDER_TO_LX && A.PROVIDER_TO_LX[raw]) || '';
      if (mapped && caps[mapped]) return true;   // 平台全名 → 短码
      // ★ 汽水：LX 协议没有这个 slot，但它**不是「不可辨认」** ——
      //   明确按已知平台处理，直接走「歌名 + 歌手」跨平台找流。
      if (raw === 'qishui' || raw === 'qs') return true;
    }
    // 平台专属 ID 特征（仅当音源确实支持该平台时才认）
    if (caps.tx && (song.qqId || (song.songmid && /^[A-Za-z0-9_-]{14}$/.test(String(song.songmid))))) return true;
    if (caps.kg && (song.hash || song.audioHash || song.fileHash)) return true;
    if (caps.kw && song.rid) return true;
    if (caps.mg && song.copyrightId) return true;
    return false;
  }

  /** 时长（秒）：兼容 duration(ms/s) / durationMs / dt / interval("3:45") */
  function candidateDurationSeconds(song) {
    if (!song) return 0;
    var v = song.durationMs || song.duration || song.dt || song.interval;
    if (v === null || v === undefined || v === '') return 0;
    if (typeof v === 'string' && /^\d+:\d+(?::\d+)?$/.test(v)) {
      return v.split(':').map(Number).reduce(function (t, p) { return t * 60 + p; }, 0);
    }
    var n = Number(v) || 0;
    return n > 10000 ? n / 1000 : n;
  }
  function normMatchText(v) {
    return String(v == null ? '' : v).toLowerCase()
      .replace(/[（(【\[].*?[）)】\]]/g, '')
      .replace(/[\s·・\-—_.,，。:：'"“”‘’/\\|]+/g, '');
  }
  function firstArtistName(v) {
    return normMatchText(String(v == null ? '' : v).split(/\s*\/\s*|、|&| feat\.? | ft\.? /i)[0]);
  }
  function candidateArtistOverlaps(cand, wantArtist) {
    var a = firstArtistName(cand && (cand.artist || cand.singer));
    var b = firstArtistName(wantArtist);
    if (!a || !b) return true;
    return a === b || a.indexOf(b) >= 0 || b.indexOf(a) >= 0;
  }

  /**
   * 依次尝试候选，返回第一个**完整版**（非试听）的解析结果。
   *
   * 用户两条硬要求：① 必须是对应的歌曲 ② 必须是完整版。所以这里：
   *   · 只在「歌名归一化后完全一致 + 歌手重叠 + 时长接近」的候选里挑（防张冠李戴）；
   *   · 解析结果必须 trial !== true（用音源脚本的试听探测兜底，防拿片段当完整版）；
   *   · 逐个降级尝试；全都不满足就返回 null（交回宿主，绝不硬塞错的音频）。
   */
  function tryCandidates(list, song) {
    var A = api();
    if (!A) return Promise.resolve(null);
    var wantName = normMatchText(song && (song.name || song.title));
    var wantArtist = String((song && (song.artist || song.singer)) || '');
    var wantSeconds = candidateDurationSeconds(song);
    var strict = [];
    (list || []).forEach(function (c) {
      if (!c || !c.name) return;
      if (normMatchText(c.name) !== wantName) return;                    // 歌名必须一致
      if (wantArtist && !candidateArtistOverlaps(c, wantArtist)) return; // 歌手必须对得上
      var cs = candidateDurationSeconds(c);
      if (wantSeconds && cs && Math.abs(cs - wantSeconds) > 8) return;   // 时长差太多 → 不是同一版本
      strict.push(c);
    });
    if (!strict.length) {
      warn('跨平台搜索没有「同名同歌手同时长」的候选，交回宿主');
      return Promise.resolve(null);
    }
    var order = strict.slice(0, SEARCH_FALLBACK_MAX);
    function next(i) {
      if (i >= order.length) return Promise.resolve(null);
      var cand = order[i];
      // probeTrial: true —— 对候选也做试听探测，确保拿到的是完整版
      return A.resolvePlaybackData(cand, { probeTrial: true }).then(function (d) {
        if (d && d.url && d.trial !== true) return d;   // 只接受完整版
        return next(i + 1);
      }).catch(function () {
        return next(i + 1);
      });
    }
    return next(0);
  }

  /**
   * 真正的接管动作：向音源要直链 → 塞给宿主的 audio 元素。
   * 返回 true 表示「我接管了这次播放，宿主不要再往下走」。
   */
  function takeOver(idx, token, opts) {
    opts = opts || {};
    var A = api();
    if (!A) return Promise.resolve(false);

    var q = W.playQueue;
    var song = (q && idx >= 0 && idx < q.length) ? q[idx] : null;
    if (!song) return Promise.resolve(false);

    var resumeAt = Number(opts.resumeAt != null ? opts.resumeAt : 0) || 0;

    /**
     * ★ 性能修复（2026-10-05）：平台可辨认时先直连，认不出就直接走跨平台搜索。
     *
     * 背景（实测）：宿主切歌先调 resolvePlaybackData()。当歌曲的
     *   provider/source 缺失时，运行时的 platformOf() 会默认判成 'wy'（网易云），
     *   于是拿这首歌去试网易云的 6 个档位，每次都在等网易云接口超时 ——
     *   实测直连 **8263ms** 全白费；而改用歌名搜索只要 653ms + 79ms 就成功。
     *
     * 所以这里先判断平台是否「可辨认」：
     *   · 能辨认（有 provider/source/lxjsSourceCode，或带平台专属 ID）→ 先直连（最快路径）
     *   · 认不出 → 跳过直连的超时等待，直接用歌名跨平台找（实测不到 1 秒）
     */
    var directFirst = songPlatformIsIdentifiable(song);
    if (!directFirst) {
      log('平台不可辨认（provider/source 缺失），直接改用歌名跨平台找「' + (song.name || '') + '」…');
    }

    var resolvePromise = directFirst
      ? A.resolvePlaybackData(song, {})
      : Promise.reject(new Error('平台不可辨认，跳过直连'));

    return resolvePromise
      .catch(function (firstErr) {
        log('直接解析失败（' + (firstErr && firstErr.message ? firstErr.message : firstErr)
          + '），改用歌名跨平台找「' + (song.name || '') + '」…');
        return searchCrossPlatform(song).then(function (list) {
          if (!list || !list.length) return null;
          log('跨平台找到 ' + list.length + ' 条候选，逐个尝试取流');
          return tryCandidates(list, song);
        });
      })
      .then(function (data) {
        if (!data || !data.url) {
          log('自定义音源未能解析《' + (song.name || '') + '》，交回宿主');
          return false;
        }
        // 切歌竞态：用户在这期间点了别的歌
        if (token != null && token !== W.trackSwitchToken) {
          log('放弃接管（已被新一次切歌取代）');
          return false;
        }

        // 标记歌曲：让 UI/统计知道这首是自定义音源解析的。
        // ⚠️ 不要写 __lxResolved —— 那个标记会被宿主复用的 song 对象带下去，
        //    导致下次切回这首歌时被 shouldTakeOver 拒掉（见那里的注释）。
        song.sourceType = 'lxjs';
        song.resolvedPlaybackProvider = 'lxjs';
        song.lxQuality = data.level || '';
        song.jsSourceId = data.jsSourceId || '';

        /**
         * 🔴 关键：**把预解析数据交回宿主**，而不是自己操纵 audio 元素。
         *
         * 早期版本在这里做 `var audio = W.audio || getElementById('audio')` 然后
         * `audio.src=...; audio.play()`。这在真机上**必然失败** ——
         * 宿主的 audio 是 `audio = new Audio()`（13-playback-start-audio.js:920），
         * 一个**游离对象、从不挂进 DOM**，所以：
         *   · W.audio            —— 00-core-stores.js 的模块级 var，插件看不到
         *   · getElementById/querySelector('audio') —— 永远 null
         * 于是 takeOver 每首歌都 return false，播放原样落回官方链路，
         * 用户看到的就是「标签写着 LX，实际放的是官方 30 秒试听」。
         *
         * 正确做法是宿主自己留的口子（13-playback-start-audio.js:1340）：
         *   } else if (opts.preResolvedPlaybackData && opts.preResolvedPlaybackData.url) {
         *     data = opts.preResolvedPlaybackData;
         *   }
         * 传 {url, provider:'js'} 进去，宿主会自行建立播放并接管进度条、
         * 切歌、媒体通知等**全部**后续逻辑 —— 不用我们重写一遍。
         */
        /**
         * ★ 试听标记必须如实带上去。
         *
         * 宿主的试听策略有两道（24-trial-audio-fix.js 的头注释）：
         *   A. 解析时预检 precheckTrialFallback —— 门槛就是 `data.trial`
         *      （13-playback-start-audio.js:1252）
         *   B. 播放中兜底 onAudioMetadata —— 靠真实时长发现片段
         * 以前这里不带 trial，宿主拿不到标记 ⇒ A 进不去 ⇒ 只能走 B：
         * 先把试听播出来、等 loadedmetadata 发现时长短才换源，
         * 于是用户先看到「检测到试听片段」的提示、过一会儿才听到完整版。
         *
         * 运行时（lx-runtime.resolvePlaybackData）现在会自己判片段并先补一次：
         *   · 补到了 → data.trial 为 false，直接播完整版，不打扰宿主；
         *   · 没补到 → 这里把 trial: true 带上去，宿主的 A 预检立刻接管
         *     （它用自己那套跨平台搜索再试一次），失败时也有它的试听提示兜底。
         */
        var preResolved = {
          url: data.url,
          provider: 'js',
          level: data.level,
          qualityState: 'verified',
          sourceType: 'lxjs',
          br: data.br || 0,
          trial: !!data.trial
        };
        if (data.trialRescued) preResolved.trialRescued = true;
        if (resumeAt > 0) preResolved.resumeAt = resumeAt;

        var pass = Object.assign({}, opts, {
          preResolvedPlaybackData: preResolved,
          lxSourceTried: true,
          resumeAt: resumeAt
        });
        log('已解析《' + (song.name || '未知') + '》(' + (data.level || '') + ')，交回宿主播放链路');

        // 上锁：防止 origPlayQueueAt 内部又走到我们的 hook 形成自激
        st.inTakeOver = true;
        return Promise.resolve(st.origPlayQueueAt.call(W, idx, pass))
          .then(function (r) { st.inTakeOver = false; return r !== false; })
          .catch(function (e) { st.inTakeOver = false; noteErr('宿主播放失败', e); return false; });
      })
      .catch(function (e) {
        log('音源解析失败，交回宿主：' + (e && e.message ? e.message : e));
        return false;
      });
  }

  /* ── ① 取源失败兜底 ────────────────────────────────────── */

  function installFallbackHook() {
    // ★ 已移除（架构调整）：新架构下插件是宿主取流分支的「第一优先」，
    //   官方链路失败后无需再兜底重试插件 —— 否则会在取流分支已试过插件之后
    //   又重复解析一次，拖慢失败路径、且与「解析统一走插件」的目标冲突。
    return false;
  }

  /* ── ② 优先接管 ────────────────────────────────────────── */

  /**
   * 🔴 早期版本只在「一个平台都没登录」时才接管，这是个致命的设计错误。
   *
   * 用户装这个插件的意图是「用我自己的音源听歌」，而不是「仅在没登录时兜底」。
   * 一旦他登录了任何平台，插件就完全退化成静默旁路 —— 装了等于没装。
   *
   * 现在的规则：只要自定义音源处于就绪状态，播放就**优先**走它；
   * 拿不到直链（脚本只支持部分平台/该歌曲无版权）再自动退回宿主官方链路。
   * 这样才是「音源当主力、官方当兜底」，也符合插件的语义。
   */
  function installDirectHook() {
    // ★ 架构调整（不再 hook playQueueAt）：
    //   改为暴露一个桥接函数，由宿主的取流分支（13-playback-start-audio.js）直接调用。
    //   这样插件解析成功/失败都发生在宿主同一次 playQueueAt 内：
    //     · 成功 → 宿主直接用插件直链，跳过官方取流，不重复 UI/会话准备；
    //     · 失败 → 宿主继续官方取流，不重新跑一遍 playQueueAt。
    //   彻底消除「插件先解析失败 → 宿主再完整解析」的双重解析（切歌慢的根因）。
    W.__mrLxResolvePlayback = function (song, requestedQuality) {
      var A = api();
      if (!A || !A.isReady()) return Promise.resolve(null);
      if (!shouldTakeOver(song)) return Promise.resolve(null);

      var directFirst = songPlatformIsIdentifiable(song);
      if (!directFirst) {
        log('平台不可辨认（provider/source 缺失），直接改用歌名跨平台找「' + (song && song.name || '') + '」…');
      }

      var resolvePromise = directFirst
        ? A.resolvePlaybackData(song, {})
        : Promise.reject(new Error('平台不可辨认，跳过直连'));

      return resolvePromise
        .catch(function (firstErr) {
          log('直接解析失败（' + (firstErr && firstErr.message ? firstErr.message : firstErr)
            + '），改用歌名跨平台找「' + (song && song.name || '') + '」…');
          return searchCrossPlatform(song).then(function (list) {
            if (!list || !list.length) return null;
            log('跨平台找到 ' + list.length + ' 条候选，逐个尝试取流');
            return tryCandidates(list, song);
          });
        })
        .then(function (data) {
          if (!data || !data.url) {
            log('自定义音源未能解析《' + (song && song.name || '') + '》，交回宿主官方链路');
            return null;
          }
          log('自定义音源已解析《' + (song && song.name || '') + '》(' + (data.level || '') + ')');
          // 打上来源标记，供宿主识别「这份数据来自插件、无需再走官方试听换源」
          return Object.assign({}, data, { fromLxPlugin: true });
        })
        .catch(function (e) {
          noteErr('插件解析异常', e);
          return null;
        });
    };
    return true;
  }

  /* ── ③ 搜索栏并入 ──────────────────────────────────────── */

  /**
   * 为什么音源没就绪时「静默返回官方结果」是错的：
   * 用户导入脚本后如果没能激活（脚本语法错、没调 lx.send('inited')、
   * 云端开关拦截），搜索看起来就是「插件没生效」，毫无线索。
   * 所以这里主动提示一次（限频，避免每次搜索都弹）。
   */
  var notReadyNotified = false;
  function notifyNotReadyOnce() {
    if (notReadyNotified) return;
    notReadyNotified = true;
    var A = api();
    var why = !A ? '插件运行时未载入'
      : (A.initError() ? A.initError() : '请先在「视觉控制台 → 自定义音源（LX）」里启用一个音源');
    try {
      if (typeof W.showSourceFallbackNotice === 'function') {
        W.showSourceFallbackNotice('自定义音源未启用', why);
      }
    } catch (e) { }
    warn('搜索未并入自定义音源：' + why);
  }

  function installSearchHook() {
    if (typeof W.fetchMusicSearchResults !== 'function') return false;
    st.origFetchSearch = W.fetchMusicSearchResults;
    W.fetchMusicSearchResults = async function (q, mode, previousPages) {
      // 先让宿主跑完官方搜索（不阻塞用户看到已有结果）
      var officialPromise = st.origFetchSearch.call(this, q, mode, previousPages);

      // 播客等非歌曲模式不并入
      if (mode === 'podcast') return officialPromise;

      if (!ready()) {
        notifyNotReadyOnce();
        return officialPromise;
      }
      notReadyNotified = false;   // 就绪后恢复提示能力

      var A = api();

      /**
       * 🔴 必须区分「音源支不支持搜索」两种情况，这是很多音源的真实形态：
       *
       *   A. 支持 search（如内置音源）—— 自己能找歌，结果直接并入列表。
       *   B. 只支持 musicUrl（如念心音源这类「解析器」）—— 自己不会找歌，
       *      但用户装它的目的恰恰是「用官方搜索的歌单 + 我的解析器取流」。
       *
       * 早期版本没区分：拿不到 mine 就原样返回官方结果，播放时也不会走音源，
       * 于是用户看到的是「插件装了但搜索没结果、播放也没变化」——
       * 实际上插件对 B 类音源完全无效。
       *
       * 现在：B 类情况下给官方结果打 `preferUserSource` 标记，
       * 播放时优先交给音源解析（见 installDirectHook）。
       */
      var caps = A.caps() || {};
      var supportsSearch = Object.keys(caps).some(function (code) {
        return (caps[code].actions || []).indexOf('search') >= 0;
      });

      var minePromise = supportsSearch
        ? A.search(q, { limit: 18 }).then(function (items) {
          return Array.isArray(items) ? items : [];
        }).catch(function (e) {
          log('搜索（自定义音源）失败：' + (e && e.message ? e.message : e));
          return [];
        })
        : Promise.resolve([]);

      return Promise.all([officialPromise, minePromise]).then(function (pair) {
        var official = pair[0] || { songs: [] };
        var mine = pair[1] || [];
        var officialSongs = official.songs || [];

        // 官方结果统一打标记：这些歌优先交给自定义音源解析直链
        officialSongs.forEach(function (s) {
          try { s.preferUserSource = true; } catch (e) { }
        });

        if (!mine.length) {
          if (!supportsSearch) {
            log('当前音源只做取流不做搜索（' + Object.keys(caps).join('/') +
              '），已把官方搜索结果标记为「优先走自定义音源」');
          }
          return official;
        }

        var merged = officialSongs.slice();
        var seen = {};
        merged.forEach(function (s) { seen[dedupeKey(s)] = true; });
        mine.forEach(function (s) {
          var k = dedupeKey(s);
          if (seen[k]) return;
          seen[k] = true;
          merged.push(s);
        });

        // 保持宿主返回结构不变，只多带一个自定义音源的分页标记
        var out = Object.assign({}, official, {
          songs: merged,
          lxSourceCount: mine.length
        });
        if (out.providerPages && !out.providerPages.lxjs) {
          out.providerPages.lxjs = { offset: 0, limit: 18, nextOffset: 18, hasMore: false, total: mine.length, failed: false };
        }
        log('搜索「' + q + '」：官方 ' + officialSongs.length + ' 首 + 自定义音源 ' + mine.length + ' 首');
        return out;
      }).catch(function (e) {
        noteErr('搜索并入异常', e);
        return officialPromise;
      });
    };
    return true;
  }

  function dedupeKey(s) {
    return String((s && s.name) || '').trim().toLowerCase() + '|' +
      String((s && s.artist) || '').trim().toLowerCase();
  }

  /* ── ④ 歌词兜底 ────────────────────────────────────────── */

  function installLyricHook() {
    // 歌词链路耦合较深，这里只挂一个查询入口给面板/其它模块用，不强行接管
    W.lxSourceResolveLyric = function (song) {
      var A = api();
      if (!A || !A.isReady()) return Promise.resolve(null);
      return A.resolveLyric(song);
    };
    W.lxSourceResolvePic = function (song) {
      var A = api();
      if (!A || !A.isReady()) return Promise.resolve('');
      return A.resolvePic(song);
    };
    return true;
  }

  /* ── ④ 音源切换器：把自定义音源挂进宿主的 provider 列表 ──── */

  /**
   * ★ 已停用（2026-10-04，用户要求）：
   *   原来这里往宿主的「切换音源」列表尾部追加一项 `lxjs`，
   *   让用户能在播放控制台里切到自定义音源。用户明确表示
   *   **不需要在这里切换自定义音源**（而且它会连带影响歌词分支）。
   *
   *   现在直接不包装 W.controlSourceProviders，切换列表保持宿主原来的 5 个平台。
   *   自定义音源的启用/停用仍然在插件自己的面板里操作（音源列表）。
   */
  function installProviderListHook() {
    // 不再追加 lxjs 项，切换音源列表保持宿主原样
    return false;
  }

  function activeSourceMeta() {
    var A = api();
    if (!A) return {};
    var id = A.activeId();
    if (!id) return {};
    var src = null;
    try { src = A.findSource(id); } catch (e) { }
    return src || { id: id, name: '', version: '' };
  }

  /* ── ⑤ 平台判定：让 songProviderKey 认识自定义音源 ──────── */

  /**
   * ★ 已停用（2026-10-04，用户要求）：
   *   原来这里把自定义音源的歌判定成 provider='lxjs'，但宿主
   *   `js/modules/05-playback/06-track-detail-lyrics-actions.js` 与
   *   `js/modules/02-visual/14-stage-lyrics-rendering.js` **大量用
   *   songProviderKey(song) 决定歌词走哪条分支**（例如只有 === 'qq' 才走某条路径）。
   *   返回 'lxjs' 是宿主不认识的平台 → 歌词分支全走错 → 用户反馈"影响到我的歌词"。
   *
   *   现在直接返回宿主原值（保持歌曲真实平台），歌词恢复正常。
   *   播放取流不受影响：走的是 takeOver / settleSourceFallbackTerminal 两条钩子，
   *   它们靠 song.sourceType==='lxjs' 识别，不依赖 songProviderKey。
   */
  function installProviderKeyHook() {
    // 不再包装 W.songProviderKey，保持宿主原行为
    return false;
  }

  /** 标签文案：让歌曲详情/列表里显示「LX」而不是「NE」 */
  function installSourceTagHook() {
    if (typeof W.songSourceTagHtml !== 'function') return false;
    st.origSongSourceTagHtml = W.songSourceTagHtml;
    W.songSourceTagHtml = function (song, opts) {
      if (song && (song.sourceType === 'lxjs' || song.fromUserSource === true)) {
        var cls = 'tag-source lxjs';
        if (opts && opts.switcher) {
          return '<button type="button" class="' + cls + ' control-source-chip" ' +
            'title="切换音源" aria-haspopup="true" ' +
            'onclick="toggleControlSourceSwitcher(event)">LX</button>';
        }
        return '<span class="' + cls + '">LX</span>';
      }
      return st.origSongSourceTagHtml.apply(this, arguments);
    };
    return true;
  }

  /* ── 状态广播 ──────────────────────────────────────────── */

  function broadcastState() {
    var A = api();
    var payload = {
      ready: !!(A && A.isReady()),
      activeId: A ? A.activeId() : '',
      initError: A ? A.initError() : '',
      sources: A ? A.sources() : [],
      anyLoggedIn: anyPlatformLoggedIn()
    };
    try {
      W.dispatchEvent(new CustomEvent('lx-source-state', { detail: payload }));
    } catch (e) { }
    // 通知面板重渲染（面板监听这个）
    try {
      if (typeof W.renderMrLxSourcePanel === 'function') W.renderMrLxSourcePanel();
    } catch (e2) { }
    return payload;
  }

  /* ── 安装 / 卸载 ────────────────────────────────────────── */

  function install() {
    if (st.installed) return true;
    var r = {
      fallback: installFallbackHook(),
      direct: installDirectHook(),
      search: installSearchHook(),
      lyric: installLyricHook(),
      providerList: installProviderListHook(),
      providerKey: installProviderKeyHook(),
      sourceTag: installSourceTagHook()
    };
    st.installed = true;

    // 音源生命周期变化时刷新面板
    var A = api();
    if (A && typeof A.onChange === 'function') {
      A.onChange(function () { broadcastState(); });
    }
    broadcastState();

    log('接入完成：' + JSON.stringify(r));
    if (!r.direct) {
      warn('插件解析桥接未挂上 —— 宿主版本可能与预期不同：' + JSON.stringify(r));
    }
    return r;
  }

  function uninstall() {
    if (!st.installed) return;
    // ★ 新架构不再 hook playQueueAt / settleSourceFallbackTerminal，改挂桥接函数，
    //   这里清理桥接函数即可（宿主取流分支会自行判定其不存在而回退官方）。
    try { if (W.__mrLxResolvePlayback) W.__mrLxResolvePlayback = undefined; } catch (e) { }
    try { if (st.origFetchSearch) W.fetchMusicSearchResults = st.origFetchSearch; } catch (e) { }
    try { if (st.origControlSourceProviders) W.controlSourceProviders = st.origControlSourceProviders; } catch (e) { }
    try { if (st.origSongProviderKey) W.songProviderKey = st.origSongProviderKey; } catch (e) { }
    try { if (st.origSongSourceTagHtml) W.songSourceTagHtml = st.origSongSourceTagHtml; } catch (e) { }
    st.restoreFns.forEach(function (fn) { try { fn(); } catch (e) { } });
    st.restoreFns = [];
    st.origFetchSearch = null;
    st.origControlSourceProviders = null;
    st.origSongProviderKey = null;
    st.origSongSourceTagHtml = null;
    st.installed = false;
    log('已卸载，宿主恢复原状');
  }

  W.__mrLxSourceIntegration = {
    install: install,
    uninstall: uninstall,
    takeOver: takeOver,
    shouldTakeOver: shouldTakeOver,
    anyPlatformLoggedIn: anyPlatformLoggedIn,
    broadcastState: broadcastState
  };
})();