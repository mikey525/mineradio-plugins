/* ============================================================
 *  LX 音源运行时 · 宿主侧管理器
 *  ------------------------------------------------------------
 *  职责：
 *    1. 把 lx-worker.js 编译成 Blob URL 并起一个 Web Worker 沙箱
 *    2. import / activate / deactivate / delete 生命周期
 *    3. 把宿主侧的 {source, action, info} 翻译成 postMessage，
 *       再把 Worker 的响应翻译回宿主要的结构
 *    4. 音质缓存、音源能力缓存、搜索结果归一化
 *
 *  ⚠️ 沙箱是「同时只有一个激活源」的单例（与桌面版 UserApiSandbox 一致）。
 *     换源 = terminate 旧 Worker + 起新的。这是刻意的：
 *     保证任一时刻只有一个第三方脚本在跑，行为可预测。
 * ============================================================ */
(function () {
  'use strict';
  var W = window;

  /* ── 平台码 ↔ 宿主 provider 映射（与桌面版一致）─────────── */
  var LX_TO_PROVIDER = {
    wy: 'netease',
    tx: 'qq',
    kg: 'kugou',
    kw: 'kuwo',
    mg: 'migu',
    qs: 'qishui'
  };
  var PROVIDER_TO_LX = {
    netease: 'wy',
    qq: 'tx',
    kugou: 'kg',
    kuwo: 'kw',
    migu: 'mg',
    qishui: 'qs'   // ★ 新增：汽水音乐
  };
  var LX_CODE_LABEL = { wy: '网易云', tx: 'QQ音乐', kg: '酷狗', kw: '酷我', mg: '咪咕', qs: '汽水' };

  /* ── 平台码别名（脚本声明的写法 → LX 短码）─────────────────
   * 第三方脚本声明平台时并不总是用 wy/tx/kg/kw/mg 这套短码：
   * 有人写全名（netease / kugou / qishui），有人写中文（汽水、酷狗），
   * 还有人写大写（QS / KG）。以前 R.caps 直接存原样，
   * 于是 `R.caps[lxCode]`（lxCode 恒为短码）永远查不到 → 明明声明了也用不上。
   *
   * 汽水尤其明显：LX 标准协议里**没有**汽水这个平台，能不能用完全取决于
   * 脚本自己有没有声明 qs/qishui。所以这里必须把各种写法都归一化，
   * 「声明平台里有没有汽水」才判断得出来。
   */
  var LX_CODE_ALIAS = {
    wy: 'wy', netease: 'wy', ne: 'wy', '网易': 'wy', '网易云': 'wy', '网易云音乐': 'wy',
    tx: 'tx', qq: 'tx', qqmusic: 'tx', 'qq音乐': 'tx',
    kg: 'kg', kugou: 'kg', '酷狗': 'kg', '酷狗音乐': 'kg',
    kw: 'kw', kuwo: 'kw', '酷我': 'kw', '酷我音乐': 'kw',
    mg: 'mg', migu: 'mg', '咪咕': 'mg', '咪咕音乐': 'mg',
    qs: 'qs', qishui: 'qs', qsmusic: 'qs', soda: 'qs', '汽水': 'qs', '汽水音乐': 'qs',
    local: 'local'
  };
  /** 任意写法 → 规范 LX 短码（认不出来就原样返回，保留脚本的其它自定义平台） */
  function canonicalLxCode(code) {
    var raw = String(code == null ? '' : code).trim();
    if (!raw) return '';
    var lower = raw.toLowerCase();
    return LX_CODE_ALIAS[lower] || LX_CODE_ALIAS[raw] || lower;
  }
  /**
   * 把脚本 inited 里声明的 sources 归一化成 { 短码: {name,actions,qualitys} }。
   * 同一平台被声明多次（如同时写了 qs 和 qishui）时合并能力，不丢信息。
   */
  function normalizeCaps(sources) {
    var out = {};
    if (!sources || typeof sources !== 'object') return out;
    Object.keys(sources).forEach(function (rawKey) {
      var meta = sources[rawKey];
      if (!meta || typeof meta !== 'object') return;
      var code = canonicalLxCode(rawKey) || rawKey;
      var actions = Array.isArray(meta.actions) ? meta.actions.slice() : [];
      var qualitys = Array.isArray(meta.qualitys) ? meta.qualitys.slice() : [];
      if (!out[code]) {
        out[code] = Object.assign({}, meta, { actions: actions, qualitys: qualitys });
        return;
      }
      var target = out[code];
      actions.forEach(function (a) { if (target.actions.indexOf(a) < 0) target.actions.push(a); });
      qualitys.forEach(function (q) { if (target.qualitys.indexOf(q) < 0) target.qualitys.push(q); });
      if (!target.name && meta.name) target.name = meta.name;
    });
    return out;
  }

  /* 音质排序（降序）：与桌面版 MR_QUALITY_ORDER 对齐 */
  var MR_QUALITY_ORDER = ['jymaster', 'atmos+', 'atmos', 'hires', 'lossless', 'exhigh', 'standard'];
  var LX_TO_MR = {
    'master': 'jymaster',
    'atmos_plus': 'atmos+',
    'atmos': 'atmos',
    'hires': 'hires',
    'flac24bit': 'hires',
    'flac': 'lossless',
    '320k': 'exhigh',
    '128k': 'standard'
  };
  var MR_TO_LX = {
    'jymaster': 'master',
    'atmos+': 'atmos_plus',
    'atmos': 'atmos',
    'hires': 'hires',
    'lossless': 'flac',
    'exhigh': '320k',
    'standard': '128k'
  };

  var INIT_TIMEOUT_MS = 20000;
  var REQUEST_TIMEOUT_MS = 20000;
  var MAX_SCRIPT_BYTES = 9 * 1024 * 1024;
  var STORE_KEY = 'mr.plugin.lxsource.v1';

  /* ── 状态 ───────────────────────────────────────────────── */
  var R = {
    sources: [],          // [{id, name, version, author, description, homepage, script, scriptSize}]
    activeId: '',
    caps: null,           // 激活源的 {wy:{name,actions,qualitys}} 形状
    worker: null,
    workerUrl: '',
    workerReady: false,
    inited: false,
    initError: '',
    seq: 0,
    inflight: {},         // requestId → {resolve, reject, timer, meta}
    capsCache: { ts: 0, data: null },
    searchCache: {},      // keyword → {ts, items}
    SEARCH_CACHE_MS: 120000,
    listener: null,
    runtimeAlive: false
  };

  /* ── 工具 ───────────────────────────────────────────────── */
  function nowMs() { return Date.now(); }
  function rid(p) { return (p || 'lx') + '-' + (++R.seq) + '-' + Math.random().toString(36).slice(2, 8); }

  function log() {
    try {
      var a = Array.prototype.slice.call(arguments);
      a.unshift('%c[LX音源]', 'color:#7ec8d8;font-weight:bold');
      console.log.apply(console, a);
    } catch (e) { }
  }
  function warn() {
    try {
      var a = Array.prototype.slice.call(arguments);
      a.unshift('%c[LX音源]', 'color:#ffb300;font-weight:bold');
      console.warn.apply(console, a);
    } catch (e) { }
  }
  function err() {
    try {
      var a = Array.prototype.slice.call(arguments);
      a.unshift('%c[LX音源]', 'color:#ef5350;font-weight:bold');
      console.error.apply(console, a);
    } catch (e) { }
  }

  /* ── 存档 ───────────────────────────────────────────────── */
  function readStore() {
    try { return JSON.parse(localStorage.getItem(STORE_KEY) || 'null'); } catch (e) { return null; }
  }
  function writeStore() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({
        sources: R.sources.map(function (s) {
          return {
            id: s.id, name: s.name, version: s.version, author: s.author,
            description: s.description, homepage: s.homepage, importUrl: s.importUrl || '',
            script: s.script, scriptSize: s.scriptSize
          };
        }),
        activeId: R.activeId
      }));
      return true;
    } catch (e) {
      warn('存档写入失败（脚本可能超过 localStorage 配额）', e);
      return false;
    }
  }
  function loadStore() {
    var data = readStore();
    if (!data || typeof data !== 'object') return false;
    R.sources = (Array.isArray(data.sources) ? data.sources : []).filter(function (s) {
      return s && s.id && typeof s.script === 'string' && s.script.length;
    }).map(normalizeSourceMeta);
    R.activeId = data.activeId || '';
    return R.sources.length > 0;
  }

  function normalizeSourceMeta(raw) {
    return {
      id: String(raw.id || ''),
      name: String(raw.name || raw.id || '未命名音源'),
      version: String(raw.version || ''),
      author: String(raw.author || ''),
      description: String(raw.description || ''),
      homepage: String(raw.homepage || ''),
      importUrl: String(raw.importUrl || ''),
      script: String(raw.script || ''),
      scriptSize: Number(raw.scriptSize) || (raw.script ? String(raw.script).length : 0)
    };
  }

  /**
   * 解析脚本头部块注释里的元信息（桌面版 matchInfo 同构）。
   * 形如：
   *   /**
   *    * @name 某某音源
   *    * @version 1.2.0
   *    * @author someone
   *    *\/
   */
  function parseScriptInfo(scriptText, fallbackName) {
    var info = {
      name: '', version: '', author: '', description: '', homepage: ''
    };
    var m = String(scriptText || '').match(/^\s*\/\*([\s\S]*?)\*\//);
    var head = m ? m[1] : '';
    var grab = function (tag) {
      var re = new RegExp('@' + tag + '\\s+([^\\n*]+)', 'i');
      var r = head.match(re);
      return r ? r[1].trim() : '';
    };
    info.name = grab('name');
    info.version = grab('version');
    info.author = grab('author');
    /**
     * ★ 必须解析 @description（2026-10 实测「屿溪 · 云记」）。
     *
     * 新版音源脚本会拿 `lx.currentScriptInfo` 校验自己的元信息（防盗用/防篡改），
     * 字段对不上就主动抛「初始化失败！」并把 GLOBAL_API_URL 置空，
     * 表现是「线路探测明明 200 OK，音源却初始化失败」。
     * 原来这里漏了解析 description，它恒为空串 → 脚本校验不通过。
     */
    info.description = grab('description');
    /**
     * ★ homepage 必须保留**原始值**，不能因为不是 http 开头就清空。
     *
     * 这个脚本写的是：@homepage 交流群https://...更新地址https://...
     * 它以「交流群」开头，原逻辑 `/^https?:\/\//` 不匹配就把整串丢掉，
     * 脚本拿到的 homepage 变成空串 → 同样校验失败。
     * 脚本要的是「脚本里写了什么」，不是「能不能当 URL 用」。
     */
    info.homepage = grab('homepage');
    if (!info.name) {
      // 退化：用文件第一行注释或文件名
      var line = String(scriptText || '').split('\n')[0] || '';
      info.name = line.replace(/^\s*\/\*+\/?/, '').replace(/\*\/$/, '').trim() || (fallbackName || '自定义音源');
    }
    if (!info.version) info.version = '1.0.0';
    /**
     * ★ 兜底：把头部所有 @tag 都并入 currentScriptInfo。
     *
     * 有些音源除了标准 5 个字段，还会校验自定义标签（如 @deploy / @group / @link），
     * 少一个就判定「元信息被篡改」而拒绝初始化。多带几个字段对我们无害，
     * 对脚本却是能不能跑起来的差别。
     */
    try {
      var tagRe = /@([A-Za-z][\w-]*)\s+([^\n*]+)/g;
      var tm;
      while ((tm = tagRe.exec(head))) {
        var tagKey = tm[1].toLowerCase();
        if (info[tagKey] === undefined || info[tagKey] === '') info[tagKey] = tm[2].trim();
      }
    } catch (e) { }
    return info;
  }

  /* ── Worker 生命周期 ────────────────────────────────────── */

  /**
   * 取 Worker 沙箱源码。
   *
   * 🔴 这里**必须用裸 fetch**，不能用 main.js 里的 `api.net.get`。
   *    原因：lx-runtime.js 是被 <script> 标签独立加载的文件，
   *    它运行在全局作用域里；而 `api`（MR/api/MineradioPlugins 三件套）
   *    是 12-plugin-runtime.js 用 `new Function('MR','api','MineradioPlugins', code)`
   *    注入给 **main.js 那个函数体**的参数 —— 同文件的其它普通 script 根本看不到它。
   *    写 `api.net.get` 的结果是 ReferenceError: api is not defined，
   *    表现为「音源永远初始化失败」，而且因为被 Promise 吞掉，日志里连报错都看不到。
   *
   *    代价是拿不到 api.net 的容错；但这是同源 GET，用裸 fetch 完全够。
   */
  function fetchWorkerCode() {
    if (typeof W.__mrLxWorkerCode === 'string' && W.__mrLxWorkerCode) {
      return Promise.resolve(W.__mrLxWorkerCode);
    }
    var url = W.__mrLxWorkerUrl;
    if (!url) return Promise.reject(new Error('缺少 Worker 脚本地址'));
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error('Worker 脚本读取失败 HTTP ' + r.status);
      return r.text();
    }).then(function (code) {
      if (!code || !code.trim()) throw new Error('Worker 脚本读取为空');
      return code;
    }).catch(function (e) {
      return Promise.reject(new Error('无法读取 Worker 脚本：' + (e && e.message ? e.message : e)));
    });
  }

  function teardownWorker(reason) {
    if (R.worker) {
      try { R.worker.terminate(); } catch (e) { }
      R.worker = null;
    }
    R.workerReady = false;
    R.inited = false;
    R.caps = null;
    R.capsCache = { ts: 0, data: null };
    R.runtimeAlive = false;
    // 取消所有在途请求，避免旧 worker 的响应污染新会话
    Object.keys(R.inflight).forEach(function (id) {
      var e = R.inflight[id];
      if (!e) return;
      try { clearTimeout(e.timer); } catch (_) { }
      try { e.reject(new Error('音源已切换（' + (reason || 'source changed') + '）')); } catch (_) { }
    });
    R.inflight = {};
  }

  function spawnWorker(scriptText, meta) {
    return fetchWorkerCode().then(function (code) {
      var blob = new Blob([code], { type: 'application/javascript' });
      var url = URL.createObjectURL(blob);
      R.workerUrl = url;
      var worker;
      try {
        worker = new Worker(url);
      } catch (e) {
        try { URL.revokeObjectURL(url); } catch (_) { }
        throw new Error('无法创建 Worker 沙箱：' + (e && e.message ? e.message : e));
      }
      R.worker = worker;
      R.workerReady = true;
      R.runtimeAlive = true;
      R.initError = '';

      // 先装消息通道，再建握手 Promise，最后才派发 load。
      // 🔴 顺序是硬要求：早期版本是「postMessage 先、握手 Promise 后」，
      //    在真实浏览器里靠 Worker 的异步投递侥幸能过，但那是时序巧合 ——
      //    一旦对端同步或极快返回 inited，onWorkerMessage 读到的
      //    R.initResolve 还是旧值，握手信号直接丢失，
      //    最终表现为没有任何线索的「初始化超时（20s）」。
      worker.onmessage = function (e) { onWorkerMessage(e && e.data, meta); };
      worker.onerror = function (e) {
        var msg = '脚本运行时错误：' + (e && e.message ? e.message : 'unknown');
        R.initError = msg;
        err(msg);
        try { R.initReject && R.initReject(new Error(msg)); } catch (_) { }
      };

      var handshake = new Promise(function (resolve, reject) {
        var settled = false;
        var timer = setTimeout(function () {
          if (settled) return;
          settled = true;
          R.initResolve = null;
          R.initReject = null;
          reject(new Error('音源初始化超时（' + (INIT_TIMEOUT_MS / 1000) +
            's）——脚本可能没有调用 lx.send("inited", {sources:{...}})'));
        }, INIT_TIMEOUT_MS);

        R.initResolve = function (caps) {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          R.initResolve = null;
          R.initReject = null;
          resolve(caps);
        };
        R.initReject = function (e) {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          R.initResolve = null;
          R.initReject = null;
          reject(e);
        };
      });
      R.initPromise = handshake;

      // 握手通道就绪后才派发脚本 —— 此时 R.initResolve 已经能接住信号了
      worker.postMessage({ type: 'load', script: scriptText, meta: meta });
      log('Worker 沙箱已启动，脚本 ' + ((scriptText || '').length / 1024).toFixed(1) + ' KB');

      return handshake;
    });
  }

  function onWorkerMessage(msg, meta) {
    if (!msg || !msg.type) return;
    if (msg.type === 'inited') {
      // ★ 关键：先归一化再存。脚本可能用 qishui / 汽水 / QS 等写法声明平台，
      //   不归一化的话下游一律按短码查 caps，会「明明声明了却说没这个平台」。
      R.caps = normalizeCaps(msg.sources);
      R.inited = true;
      if (R.initResolve) R.initResolve(R.caps);
      log('音源已就绪，声明平台：' + Object.keys(R.caps).join(', ') + (R.caps.qs ? '（含汽水）' : '（无汽水）'));
      if (R.listener) safeCall(R.listener, 'inited');
      return;
    }
    if (msg.type === 'scriptError') {
      // 脚本**异步**阶段的报错（线路探测、取流 Promise 链等）。
      // 这是最有价值的排查信息：以前这类错误完全被吞掉，只表现为「20s 没等到 inited」。
      R.lastScriptError = String(msg.error || '').slice(0, 1000);
      warn('[音源脚本异步错误/' + (msg.phase || '') + '] ' + R.lastScriptError);
      // 未就绪就顺带把原因带进 initError，让界面能直接看到真实死因
      if (!R.inited && !R.initError) R.initError = '脚本异步报错：' + R.lastScriptError;
      return;
    }
    if (msg.type === 'scriptLog') {
      // 剧本自己 console 出来的调试信息，转发到宿主日志便于排查
      log('[音源] ' + (msg.text || ''));
      return;
    }
    if (msg.type === 'initTimeout') {
      var timeoutMsg = msg.error || '初始化超时';
      // 如果脚本在超时前抛过异步错误，那才是真正的原因
      if (R.lastScriptError) timeoutMsg += '；脚本异步报错：' + R.lastScriptError;
      R.initError = timeoutMsg;
      if (R.initReject) R.initReject(new Error(R.initError));
      return;
    }
    if (msg.type === 'fatal') {
      // ★ 只在「尚未初始化成功」时才算致命。音源已经 inited 之后，脚本运行期的
      //   一次报错不应污染 initError（否则会出现「isReady=true 但 initError 非空」
      //   的自相矛盾状态，误导排查）。
      if (!R.inited) {
        R.initError = msg.error || '脚本执行失败';
        if (R.initReject) R.initReject(new Error(R.initError));
      } else {
        warn('音源运行期报错（已就绪，忽略，不影响解析）：' + (msg.error || ''));
      }
      return;
    }
    if (msg.type === 'response') {
      var e = R.inflight[msg.id];
      if (!e) return;
      delete R.inflight[msg.id];
      try { clearTimeout(e.timer); } catch (_) { }
      if (msg.ok) e.resolve(msg.result);
      else e.reject(new Error(msg.error || '音源返回错误'));
      return;
    }
    if (msg.type === 'log') {
      log('[脚本]', msg.text);
    }
  }

  function safeCall(fn, arg) {
    try { return fn(arg); } catch (e) { return null; }
  }

  /* ── 对外：导入 / 激活 / 删除 ───────────────────────────── */

  function importScript(scriptText, fallbackName, importUrl) {
    scriptText = String(scriptText || '');
    if (!scriptText.trim()) return Promise.reject(new Error('脚本内容为空'));
    if (scriptText.length > MAX_SCRIPT_BYTES) {
      return Promise.reject(new Error('脚本超过 9MB 上限（当前 ' + (scriptText.length / 1048576).toFixed(1) + ' MB）'));
    }
    var info = parseScriptInfo(scriptText, fallbackName);
    var source = normalizeSourceMeta({
      id: rid('user_api'),
      name: info.name,
      version: info.version,
      author: info.author,
      description: info.description,
      homepage: info.homepage,
      importUrl: String(importUrl || ''),
      script: scriptText,
      scriptSize: scriptText.length
    });
    R.sources.push(source);
    var ok = writeStore();
    if (!ok) {
      // 配额爆了就把刚才这条撤掉，别留下「列表里有但重启就没」的幽灵条目
      R.sources = R.sources.filter(function (s) { return s.id !== source.id; });
      return Promise.reject(new Error('脚本过大导致存档失败，请使用体积更小的音源脚本'));
    }
    log('已导入音源「' + source.name + '」v' + source.version);
    if (R.listener) safeCall(R.listener, 'sources');
    return activate(source.id).then(function () { return source; });
  }

  function activate(id) {
    var src = findSource(id);
    if (!src) return Promise.reject(new Error('音源不存在: ' + id));
    teardownWorker('activate');
    R.activeId = src.id;
    R.searchCache = {};
    writeStore();
    /**
     * ★ meta 必须**现场重新解析脚本**，不能只用存档里的字段（2026-10 实测「屿溪 · 云记」）。
     *
     * 元信息解析逻辑修好之后（补上 @description、不再因为 homepage 不是 http 开头就清空），
     * 老音源在 localStorage 里存的 description/homepage 仍然是导入那一刻写下的**空串**。
     * 于是每次 activate 传给脚本的 currentScriptInfo 都缺字段 → 脚本自校验失败 →
     * 永远「初始化失败！」，而代码看起来明明已经修好了（这个坑非常隐蔽）。
     *
     * 现场用脚本源码重解析：既能自愈历史数据，也能把修正结果回写存档。
     */
    var freshInfo = {};
    try { freshInfo = parseScriptInfo(src.script, src.name) || {}; } catch (e) { freshInfo = {}; }
    if (freshInfo.name) src.name = freshInfo.name;
    if (freshInfo.version) src.version = freshInfo.version;
    if (freshInfo.author) src.author = freshInfo.author;
    src.description = freshInfo.description || '';
    src.homepage = freshInfo.homepage || '';

    var meta = {
      name: src.name, version: src.version, author: src.author,
      description: src.description, homepage: src.homepage
    };
    // 其余 @tag（@deploy/@group/@link 等）也一并带上：部分音源会连它们一起校验
    Object.keys(freshInfo).forEach(function (k) {
      if (meta[k] === undefined) meta[k] = freshInfo[k];
    });
    writeStore();
    return spawnWorker(src.script, meta).then(function (caps) {
      log('激活完成：' + src.name + '（' + Object.keys(caps || {}).join(', ') + '）');
      if (R.listener) safeCall(R.listener, 'activated');
      return caps;
    }).catch(function (e) {
      R.activeId = '';
      R.initError = String(e && e.message ? e.message : e);
      err('激活失败：' + R.initError);
      if (R.listener) safeCall(R.listener, 'activated');
      throw e;
    });
  }

  function deactivate() {
    teardownWorker('deactivate');
    R.activeId = '';
    R.searchCache = {};
    writeStore();
    log('已停用当前音源');
    if (R.listener) safeCall(R.listener, 'activated');
    return true;
  }

  function removeSource(id) {
    var before = R.sources.length;
    R.sources = R.sources.filter(function (s) { return s.id !== id; });
    if (R.sources.length === before) return false;
    if (R.activeId === id) teardownWorker('delete');
    R.activeId = R.activeId === id ? '' : R.activeId;
    writeStore();
    log('已删除音源');
    if (R.listener) safeCall(R.listener, 'sources');
    return true;
  }

  function findSource(id) {
    for (var i = 0; i < R.sources.length; i++) {
      if (R.sources[i].id === id) return R.sources[i];
    }
    return null;
  }

  /**
   * 更新一个已有音源（供「检查更新」替换脚本使用），保留原 id。
   * 如果它当前正在激活，则用新脚本重新拉起 Worker；否则只更新存档。
   */
  function updateSource(id, scriptText, importUrl) {
    var src = findSource(id);
    if (!src) return Promise.reject(new Error('音源不存在: ' + id));
    scriptText = String(scriptText || '');
    if (!scriptText.trim()) return Promise.reject(new Error('脚本内容为空'));
    if (scriptText.length > MAX_SCRIPT_BYTES) {
      return Promise.reject(new Error('脚本超过 9MB 上限（当前 ' + (scriptText.length / 1048576).toFixed(1) + ' MB）'));
    }
    var info = parseScriptInfo(scriptText, src.name);
    src.name = info.name || src.name;
    src.version = info.version || src.version;
    src.author = info.author;
    src.description = info.description;
    src.homepage = info.homepage;
    src.importUrl = String(importUrl || src.importUrl || '');
    src.script = scriptText;
    src.scriptSize = scriptText.length;
    var ok = writeStore();
    if (!ok) return Promise.reject(new Error('脚本过大导致存档失败，请使用体积更小的音源脚本'));
    log('已更新音源「' + src.name + '」v' + src.version);
    if (R.listener) safeCall(R.listener, 'sources');
    if (R.activeId === src.id) {
      return activate(src.id).then(function () { return src; });
    }
    return Promise.resolve(src);
  }

  /* ── 对外：请求 ─────────────────────────────────────────── */

  function invoke(source, action, info, timeoutMs) {
    if (!R.activeId || !R.worker || !R.workerReady) {
      return Promise.reject(new Error('没有已激活的音源'));
    }
    if (!R.inited) return Promise.reject(new Error('音源尚未初始化'));
    var caps = R.caps || {};
    if (!caps[source]) return Promise.reject(new Error('该音源不支持平台：' + source));
    if ((caps[source].actions || []).indexOf(action) < 0) {
      return Promise.reject(new Error('该音源不支持动作：' + action));
    }
    var id = rid('req');
    return new Promise(function (resolve, reject) {
      var timer = setTimeout(function () {
        delete R.inflight[id];
        reject(new Error('音源响应超时（' + (timeoutMs || REQUEST_TIMEOUT_MS) + 'ms）'));
      }, timeoutMs || REQUEST_TIMEOUT_MS);
      R.inflight[id] = { resolve: resolve, reject: reject, timer: timer };
      try {
        R.worker.postMessage({ type: 'request', id: id, source: source, action: action, info: info || {} });
      } catch (e) {
        clearTimeout(timer);
        delete R.inflight[id];
        reject(new Error('发送请求失败：' + (e && e.message ? e.message : e)));
      }
    });
  }

  /* ── 对外：音质 ─────────────────────────────────────────── */

  function getCaps(force) {
    if (!force && R.capsCache.ts && (nowMs() - R.capsCache.ts) < 60000) {
      return Promise.resolve(R.capsCache.data);
    }
    if (!R.inited) return Promise.resolve(null);
    R.capsCache = { ts: nowMs(), data: R.caps };
    return Promise.resolve(R.caps);
  }

/**
 * 某平台声明的音质 → 宿主档位（降序，去重）。
 *
 * 🔴 为什么要去重：flac24bit 与 hires 在 LX 里是**两个独立音质**，
 *    但映射到宿主都是 'hires'。若不去重，同一档会在数组里出现两次，
 *    下游逐档降级会对同一个 MR 档位反复请求，白白多花一次网络往返。
 */
function tiersFor(lxCode) {
    var caps = R.caps || {};
    var c = caps[lxCode];
    if (!c) return [];
    var declared = (c.qualitys || []).slice();
    var out = [];
    var seen = {};
    for (var i = 0; i < MR_QUALITY_ORDER.length; i++) {
      var mr = MR_QUALITY_ORDER[i];
      var lx = MR_TO_LX[mr];
      if (declared.indexOf(lx) >= 0 && !seen[mr]) {
        seen[mr] = true;
        out.push(mr);
      }
    }
    return out;
  }

  /* ── 对外：musicUrl ─────────────────────────────────────── */

  /**
   * 把宿主 song 对象翻译成 LX 的 musicInfo（lxjsBuildMusicInfo 同构）。
   * 这是音源脚本唯一认识的歌曲结构，必须对齐。
   */
  function buildMusicInfo(song, lxCode, declaredQualitys) {
    song = song || {};
    var info = {
      type: 'music',
      source: lxCode,
      name: String(song.name || song.title || ''),
      artist: String(song.artist || ''),
      album: String(song.album || song.albumName || ''),
      duration: 0
    };
    // 桌面版归一化：>1000 视为毫秒
    var dur = Number(song.duration);
    if (isFinite(dur) && dur > 0) info.duration = dur > 1000 ? Math.round(dur / 1000) : Math.round(dur);

    var copyIf = function (key, val) {
      if (val != null && val !== '' && info[key] === undefined) info[key] = String(val);
    };
    copyIf('id', song.id);
    copyIf('mid', song.mid || song.songmid);
    copyIf('songId', song.id);

    /**
     * 🔴 songmid 必须是「五平台通用兜底」，不能只填 song.songmid/song.mid。
     *
     * 实测发现（念心音源 v1.0.1，Proxy 陷阱捕获它真实读取的字段）：
     *   它对 wy/tx/kg/kw/mg **五个平台全都只读 `musicInfo.songmid`**，
     *   拿它拼取流 URL：`<host>/wy.php?id=<songmid>&level=...&type=mp3`。
     *
     * 而宿主搜索结果的字段分布是：
     *   网易  → 只有 `id`（数字），没有 songmid
     *   QQ    → `songmid`（14 位字母数字）
     *   酷狗  → `hash`
     * 早期版本只写 `copyIf('songmid', song.songmid || song.mid)`，
     * 网易歌就得到 `songmid === undefined` ⇒ 拼出的 URL 是 `id=undefined`
     * ⇒ 服务端 502。**表现就是「音源已就绪但所有歌都放不出来」**。
     *
     * 修法：按平台优先级依次回退，保证任何歌曲都至少有一个可用标识。
     */
    var genericId = song.songmid || song.mid || song.id ||
      song.hash || song.audioHash || song.fileHash ||
      song.rid || song.copyrightId || '';
    copyIf('songmid', genericId);
    copyIf('mediaMid', song.mediaMid || genericId);
    copyIf('hash', song.hash || song.audioHash);
    copyIf('fileHash', song.fileHash || song.hash || song.audioHash);
    copyIf('songid', song.songid || song.id);
    copyIf('rid', song.rid);
    copyIf('copyrightId', song.copyrightId);
    copyIf('albumId', song.albumId);
    copyIf('albumPic', song.albumPic || song.pic);
    copyIf('pic', song.albumPic || song.pic);

    // artists 数组（脚本常用它做多歌手匹配）
    if (Array.isArray(song.artists) && song.artists.length) {
      info.artists = song.artists.slice(0, 10).map(function (a) {
        return { id: String(a && a.id || ''), mid: String(a && (a.mid || a.mediaMid) || ''), name: String(a && a.name || '') };
      }).filter(function (a) { return !!a.name; });
    } else if (info.artist) {
      info.artists = info.artist.split(/[、,&]/).map(function (n) { return { id: '', mid: '', name: n.trim() }; })
        .filter(function (a) { return !!a.name; }).slice(0, 10);
    }

    // 音质表：把宿主 song 上已有的 _qualitys/_types 透传，
    // 没有就用本平台声明的档位填一份骨架（脚本常读 info.qualitys 判断能否升档）
    var tiers = declaredQualitys && declaredQualitys.length ? declaredQualitys : tiersFor(lxCode);
    info.qualitys = tiers.map(function (mr) { return MR_TO_LX[mr] || '128k'; });
    if (song._qualitys && typeof song._qualitys === 'object') info._qualitys = song._qualitys;
    if (song._types && typeof song._types === 'object') info._types = song._types;

    if (lxCode === 'tx') {
      // QQ：脚本常用 qqId，纯数字
      var cand = [song.qqId, song.songid, song.id, song.qqSongId].filter(function (v) {
        return v != null && /^\d+$/.test(String(v));
      })[0];
      if (cand) info.qqId = String(cand);
    }
    return info;
  }

  /* ── 试听识别 + 自动补完整版（对齐宿主的试听策略，且不动宿主）─────
   *
   * 宿主自己有这套逻辑（24-trial-audio-fix.js 的注释写得很清楚）：
   *   A. 解析时预检 precheckTrialFallback() —— 门槛是 `data.trial`
   *   B. 播放中兜底 onAudioMetadata()        —— 靠真实时长发现片段
   * 但 LX 协议**只能交出一个 URL 字符串**（lx-worker.js:609 verifyUrlResult
   * 把 trial 之类的字段全丢掉了），宿主拿不到标记 ⇒ A 永远进不去 ⇒ 只能走 B：
   * 得先把试听播出来、等 loadedmetadata 发现时长短，才去别的平台补
   * —— 用户看到的就是「先弹试听提示、后又换成完整版」。
   *
   * 这一层把 A 的能力补在插件里（宿主一行都不用改）：
   *   1. 拿到直链先判它是不是片段（Range 取总字节数 ÷ 标称时长 → 等效码率）；
   *   2. 是片段就先试下一档（宿主本来就是「拿不到就往下滑一档」的策略）；
   *   3. 所有档位都是片段 → 用宿主现成的轻量接口跨平台找完整版；
   *   4. 找到了播完整版；实在没有就把片段**如实标记**交上去，
   *      宿主的 A 预检与试听提示仍能正常接手。
   *
   * 「不拖累宿主」的四条保证：
   *   · 不改宿主任何代码，只调用它已有的轻量接口（/api/audio、
   *     /api/lx-source/search、各平台取流接口），不触发它那套完整解析流程；
   *   · 正常歌曲只多**一次** Range 探测（有缓存）；标称时长缺失或 <60s 时
   *     连这一次都不发；
   *   · 判定与换源各有预算，超时立刻放行原直链，绝不卡住切歌；
   *   · 任何异常都退化成"原样返回"，不抛错、不改既有行为。
   */
  var TRIAL_MIN_EXPECTED_SEC = 60;    // 标称太短的不判，避免误伤（与宿主一致）
  var PROBE_CACHE_TTL_MS = 120000;
  var RESCUE_CACHE_TTL_MS = 120000;
  var PROBE_TIMEOUT_MS = 2500;
  var RESCUE_BUDGET_MS = 3000;
  var RESCUE_MAX_CANDIDATES = 3;
  /* 判片段的基准码率取**最低**的 128k（16 KB/s），而不是音源自称的档位。
   *
   * 为什么不用自称档位：音源脚本普遍会**虚报**音质 —— 玉宁熙那个脚本自己就写着
   * 「部分高音质无法获取」「不填写 KEY 也可以使用,但是QQ音乐可能音质对不上」。
   * 若按自称档位折算，一条正常的 320k 完整曲（远小于它声称的 flac 应有体积）
   * 会被误判成片段，进而触发换源/试听提示 —— **误伤比漏判糟糕得多**。
   *
   * 取 128k 地板 + 30% 余量：
   *   · 正常完整曲（≥128k）一定超过阈值 ⇒ 不会误伤；
   *   · 常见的 30~60 秒片段（即使按 320k 编码也只有一两 MB）会被抓住；
   *   · 真漏掉的，宿主的时长兜底（B，24-trial-audio-fix.js）仍会接手。
   */
  var TRIAL_FLOOR_BYTES_PER_SEC = 16000;   // 128kbps
  var TRIAL_BYTES_SAFETY = 0.7;            // 留 30% 余量，容忍编码率浮动
  var probeCache = Object.create(null);     // url -> {preview, at}
  var rescueCache = Object.create(null);    // 歌名|歌手 -> {url, at}

  function nominalSeconds(song) {
    var v = song && (song.durationMs || song.duration || song.dt || song.interval);
    if (v === null || v === undefined || v === '') return 0;
    if (typeof v === 'string' && /^\d+:\d+(?::\d+)?$/.test(v)) {
      return v.split(':').map(Number).reduce(function (t, p) { return t * 60 + p; }, 0);
    }
    var n = Number(v) || 0;
    return n > 10000 ? n / 1000 : n;
  }

  /**
   * 探测直链是不是试听片段。
   * 判据：总字节数 ÷ 标称时长 = 等效码率，明显低于该档位应有码率即为片段。
   * 任何异常、拿不到总长 → 返回 false（当正常处理），保证不误伤、不打断播放。
   */
  /**
   * ★ 一次探测拿到「HTTP 状态码 + 总字节数」，两者共用同一次请求。
   *
   * 为什么必须有状态码校验（2026-10 实测「屿溪 · 云记」的咪咕场景）：
   *   音源脚本会对**该平台并不存在的音质档**返回一个看起来正常的 URL，
   *   例如咪咕的 `https://freetyst.nf.migu.cn/.../歌曲下载/wav_32bit/xxx.wav`
   *   （咪咕根本没有 32bit WAV 母带资源），服务器实际返回 **404**。
   *   原实现只判断「总字节数够不够 → 是不是试听」，而且歌曲时长未知时**直接跳过探测**，
   *   于是 404 的坏地址被当成「完整版」交给播放器 ——
   *   表现就是「解析成功、点播放没声音、进度条不动」，控制台报：
   *       MEDIA_ELEMENT_ERROR: Format error (MEDIA_ERR_SRC_NOT_SUPPORTED)
   *
   * 返回 { status, total }；异常时 status = 0（调用方按不可用处理）。
   */
  var urlInfoCache = Object.create(null);
  function probeUrlInfo(url) {
    var hit = urlInfoCache[url];
    if (hit && Date.now() - hit.at < PROBE_CACHE_TTL_MS) return Promise.resolve(hit);
    var ctl = (typeof AbortController === 'function') ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctl) { try { ctl.abort(); } catch (e) { } } }, PROBE_TIMEOUT_MS);
    try {
      return fetch('/api/audio?url=' + encodeURIComponent(url), {
        headers: { Range: 'bytes=0-1' }, signal: ctl ? ctl.signal : undefined
      }).then(function (res) {
        var status = res.status || 0;
        var cr = (res.headers && res.headers.get('content-range')) || '';
        var total = Number(String(cr).split('/')[1]) || 0;
        if (res.body && typeof res.body.cancel === 'function') { try { res.body.cancel(); } catch (e) { } }
        var info = { status: status, total: total, at: Date.now() };
        urlInfoCache[url] = info;
        return info;
      }).catch(function () {
        var info = { status: 0, total: 0, at: Date.now() };
        urlInfoCache[url] = info;
        return info;
      }).then(function (v) { clearTimeout(timer); return v; });
    } catch (e) {
      clearTimeout(timer);
      return Promise.resolve({ status: 0, total: 0, at: Date.now() });
    }
  }

  function probeIsPreview(url, song, mr) {
    var hit = probeCache[url];
    if (hit && Date.now() - hit.at < PROBE_CACHE_TTL_MS) return Promise.resolve(hit.preview);
    var seconds = nominalSeconds(song);
    return probeUrlInfo(url).then(function (info) {
      /**
       * ★ 状态码优先于一切：地址根本不可用（404/403/连不上）必须**抛错**，
       *   让 attempt 的 catch 降档重试，而不是把坏地址当成完整版播出去。
       *   以前这里完全没有状态码校验，咪咕那种 404 的 wav_32bit 假地址就是漏网之鱼。
       */
      if (!(info.status >= 200 && info.status < 400)) {
        throw new Error('直链不可用（HTTP ' + info.status + '）');
      }
      // 时长未知 → 无从判断是否片段，但地址可用，按正常放行
      if (!(seconds >= TRIAL_MIN_EXPECTED_SEC)) {
        probeCache[url] = { preview: false, at: Date.now() };
        return false;
      }
      var expected = seconds * TRIAL_FLOOR_BYTES_PER_SEC * TRIAL_BYTES_SAFETY;
      var preview = info.total > 0 && info.total < expected * 0.6;
      probeCache[url] = { preview: preview, at: Date.now() };
      return preview;
    });
  }

  function normName(v) {
    return String(v === null || v === undefined ? '' : v).toLowerCase()
      .replace(/[（(【\[].*?[）)】\]]/g, '')
      .replace(/[\s·・\-—_.,，。:：'"“”‘’/\\|]+/g, '');
  }
  function isSameSong(cand, name, artist) {
    if (!cand || normName(cand.name) !== normName(name)) return false;
    var first = function (v) {
      return normName(String(v === null || v === undefined ? '' : v)
        .split(/\s*\/\s*|、|&| feat\.? | ft\.? /i)[0]);
    };
    var a = first(cand.artist || cand.singer), b = first(artist);
    if (!a || !b) return true;
    return a === b || a.indexOf(b) >= 0 || b.indexOf(a) >= 0;
  }

  /** 候选属于哪个 LX 平台：先看显式 source/provider，再按 ID 形态兜底。 */
  function candidatePlatform(cand) {
    var raw = String((cand && (cand.source || cand.provider)) || '').toLowerCase();
    if (LX_CODE_LABEL[raw]) return raw;
    if (PROVIDER_TO_LX[raw]) return PROVIDER_TO_LX[raw];
    var hash = String((cand && (cand.hash || cand.fileHash)) || '');
    if (/^[0-9a-fA-F]{32}$/.test(hash)) return 'kg';
    var mid = String((cand && (cand.songmid || cand.mid)) || '');
    if (/^[A-Za-z0-9_-]{14}$/.test(mid)) return 'tx';
    if (cand && cand.rid) return 'kw';
    if (/^\d{3,}$/.test(String((cand && cand.id) || ''))) return 'wy';
    return '';
  }

  /**
   * 用【音源脚本】解析一条候选取直链（跨平台）。
   *
   * ★ 关键（用户要求）：补源必须走音源脚本，而不是宿主的官方取流接口
   *   （api 的 song/url、qq/song/url、kugou/song/url、kuwo/song/url）。
   *   原因：官方接口对 VIP 歌曲往往只给试听片段（QQ/酷狗的 trial 标记也不可靠），
   *   绕一圈补回来的还是试听；而音源脚本本来就具备跨平台解析完整版的能力。
   *   传 probeTrial:false，避免候选解析再触发「探测→补源」形成递归。
   */
  function resolveCandidate(cand) {
    return resolvePlaybackData(cand, { probeTrial: false }).then(function (d) {
      if (!d || !d.url) throw new Error('候选未返回直链');
      return String(d.url);
    });
  }

  /**
   * 跨平台找完整版：借宿主的聚合搜索拿候选，但**取流一律走音源脚本**，
   * 且平台范围不设限（跟随音源脚本自己声明的平台）。全程在预算内，
   * 任何失败返回 null（调用方沿用原直链），绝不打断播放。
   */
  function rescueFullVersion(song, mr, deadline) {
    var name = String((song && (song.name || song.title)) || '').trim();
    var artist = String((song && (song.artist || song.singer)) || '').trim();
    if (!name) return Promise.resolve(null);
    var key = normName(name) + '|' + normName(artist);
    var hit = rescueCache[key];
    if (hit && Date.now() - hit.at < RESCUE_CACHE_TTL_MS) {
      return Promise.resolve(hit.url || null);
    }
    var q = artist ? (name + ' ' + artist) : name;
    // ★ 不限制平台：搜索范围跟随音源脚本自己声明的平台（caps），
    //   而不是写死 tx,kg,wy,kw（那样会漏掉音源支持的 mg 等平台）。
    var searchSources = Object.keys(R.caps || {}).join(',') || 'tx,wy,kg,kw,mg';
    try {
      return fetch('/api/lx-source/search?q=' + encodeURIComponent(q) + '&limit=10&sources=' + encodeURIComponent(searchSources),
        { cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          var list = (j && j.songs) || [];
          var same = list.filter(function (s) { return isSameSong(s, name, artist); })
            .slice(0, RESCUE_MAX_CANDIDATES);
          function next(i) {
            if (i >= same.length || Date.now() > deadline) return Promise.resolve(null);
            return resolveCandidate(same[i]).catch(function () { return next(i + 1); });
          }
          return next(0);
        })
        .then(function (url) {
          rescueCache[key] = { url: url || '', at: Date.now() };
          return url || null;
        })
        .catch(function () { return null; });
    } catch (e) {
      // fetch 同步抛错也要退化成 null，绝不把异常抛给播放链路
      return Promise.resolve(null);
    }
  }

  /**
   * 解析播放直链。逐档降级：jymaster → … → standard。
   * 返回 { url, lxCode, provider, level, trial, ... } 或 throw。
   * trial=true 表示这一份是试听片段（已尽力补过完整版但没补到）。
   */
  function resolvePlaybackData(song, opts) {
    opts = opts || {};
    if (!R.activeId || !R.inited) {
      return Promise.reject(new Error('没有已激活的自定义音源'));
    }
    var lxCode = (opts.lxCodeOverride) || platformOf(song);
    if (!lxCode || !PROVIDER_TO_LX[lxCode] && !LX_TO_PROVIDER[lxCode]) {
      return Promise.reject(new Error('无法确定歌曲所属平台'));
    }
    if (!R.caps || !R.caps[lxCode]) {
      return Promise.reject(new Error('当前音源不支持平台：' + (LX_CODE_LABEL[lxCode] || lxCode)));
    }

    var declared = (R.caps[lxCode].qualitys || []).slice();
    var tiers = tiersFor(lxCode);
    if (!tiers.length) tiers = ['standard'];

    /**
     * ★ 性能修复（2026-10-05）：限制「逐档降级重试」的次数与总耗时。
     *
     * 问题（实测）：宿主切歌时先调本函数直接解析。若歌曲的
     *   provider/source 缺失（很常见），platformOf() 会**默认判成 'wy'（网易云）**，
     *   而网易云声明了 6 个档位 ⇒ 逐个降级试 6 次，每次都等网易云多个接口超时，
     *   实测 **8263ms** 全花在错误的平台上；随后插件改用歌名跨平台搜索
     *   （653ms 拿到 32 条候选 + 79ms 取流）**不到 1 秒就成功**。
     *   也就是说这 8 秒是完全白等的，直接导致「切歌慢」。
     *
     * 修法：
     *   1) 最多只试前 3 个档位（高音质优先）—— 能取到就不用再降；
     *   2) 总耗时超过 maxMs（默认 3.5s）立即放弃，交给调用方的跨平台兜底。
     *
     * 可用 opts.maxTiers / opts.maxMs 覆盖；设 opts.maxTiers = Infinity 恢复旧行为。
     */
    var maxTiers = Math.max(1, Math.min(tiers.length,
      isFinite(opts.maxTiers) ? Number(opts.maxTiers) : 3));
    var maxMs = isFinite(opts.maxMs) ? Number(opts.maxMs) : 3500;
    var budgetStart = (typeof performance !== 'undefined' && performance.now)
      ? performance.now() : Date.now();

    var musicInfo = buildMusicInfo(song, lxCode, declared);
    var lastErr = null;
    /** 连续「直链不可用（404 等）」的档位计数：达到 2 就判定该平台无此资源，提前转跨平台 */
    var unusableTierCount = 0;
    var previewFallback = null;          // 第一份"能播但是片段"的结果，留到最后兜底
    // 试听探测 + 跨平台补源：默认开启（与旧版一致）。需要临时关闭时传 opts.probeTrial = false。
    var probeEnabled = opts.probeTrial !== false;

    function makeResult(url, mr, lxQ, extra) {
      var out = {
        url: String(url),
        source: lxCode,
        provider: 'lxjs',
        lxProvider: LX_TO_PROVIDER[lxCode] || lxCode,
        level: mr,
        lxQuality: lxQ,
        jsSourceId: R.activeId,
        sourceType: 'lxjs',
        platform: lxCode
      };
      if (extra) {
        for (var k in extra) {
          if (Object.prototype.hasOwnProperty.call(extra, k)) out[k] = extra[k];
        }
      }
      return out;
    }

    /**
     * 所有档位都试完之后的收尾：
     *   有片段 → 跨平台补一次；补到就播完整版，补不到就如实标记片段交上去。
     *   没有片段 → 维持原行为（抛最后一个错误，交给调用方的跨平台兜底）。
     */
    function finish() {
      if (!previewFallback) {
        return Promise.reject(lastErr || new Error('所有音质档位均解析失败'));
      }
      var pf = previewFallback;
      if (!probeEnabled) return Promise.resolve(makeResult(pf.url, pf.mr, pf.lxQ, { trial: true }));
      var deadline = Date.now() + RESCUE_BUDGET_MS;
      warn('各档位都只拿到试听片段，改用宿主搜索跨平台补完整版…');
      return rescueFullVersion(song, pf.mr, deadline).then(function (full) {
        if (full) {
          warn('已补到完整音频，直接播完整版');
          return makeResult(full, pf.mr, pf.lxQ, { trial: false, trialRescued: true });
        }
        warn('其它平台也没有完整版：交回片段并标记 trial，让宿主自己那套预检/提示接手');
        return makeResult(pf.url, pf.mr, pf.lxQ, { trial: true });
      });
    }

    function attempt(i) {
      if (i >= maxTiers) return finish();
      var elapsed = ((typeof performance !== 'undefined' && performance.now)
        ? performance.now() : Date.now()) - budgetStart;
      if (elapsed > maxMs) {
        warn('解析耗时 ' + Math.round(elapsed) + 'ms 超预算(' + maxMs + 'ms)');
        // 已经拿到过能播的片段就别白白丢掉：走收尾（有机会补完整版）
        if (previewFallback) return finish();
        return Promise.reject(lastErr ||
          new Error('解析超时（已试 ' + i + ' 档，' + Math.round(elapsed) + 'ms）'));
      }
      var mr = tiers[i];
      var lxQ = MR_TO_LX[mr];
      return invoke(lxCode, 'musicUrl', { type: lxQ, musicInfo: musicInfo }, 22000)
        .then(function (url) {
          if (!/^https?:/i.test(String(url || ''))) {
            throw new Error('音源返回的不是 http(s) 直链');
          }
          /**
           * ★ 无论是否开启「试听探测」，都先校验这条直链真的能取到数据。
           *
           * 音源脚本可能返回服务器上并不存在的地址（实测咪咕会给出 404 的
           * wav_32bit 母带 URL）。这种地址一旦被当完整版交给播放器，就是
           * 「解析成功但放不出声」（MEDIA_ERR_SRC_NOT_SUPPORTED）。
           * probeUrlInfo 的结果会被 probeIsPreview 复用，不会多发请求。
           */
          return probeUrlInfo(String(url)).then(function (info) {
            if (!(info.status >= 200 && info.status < 400)) {
              throw new Error('直链不可用（HTTP ' + info.status + '）');
            }
            if (!probeEnabled) return makeResult(url, mr, lxQ, { trial: false });
            // ★ 拿到可用的直链再判是不是片段。
            //   一旦判定为试听片段，**不再逐档降级重试** —— 试听是「权限/资源」层面的限制，
            //   其他档位同样是试听，继续降档只会白发请求（还会撞上音源脚本自身的限流）。
            //   直接进收尾：用音源脚本跨平台找完整版。
            return probeIsPreview(String(url), song, mr).then(function (isPreview) {
              if (!isPreview) return makeResult(url, mr, lxQ, { trial: false });
              if (!previewFallback) previewFallback = { url: String(url), mr: mr, lxQ: lxQ };
              throw new Error('TRIAL_PREVIEW_STOP');
            });
          });
        })
        .catch(function (e) {
          lastErr = e;
          // 试听片段：直接收尾（跨平台补完整版），不降档
          if (e && e.message === 'TRIAL_PREVIEW_STOP') {
            warn('档位 ' + mr + ' 只拿到试听片段，改用音源脚本跨平台找完整版…');
            return finish();
          }
          /**
           * ★ 跨平台提前触发：连续两个档位都是「地址不存在」→ 该平台整体没这首的资源。
           *
           * 音源脚本对「平台没有的音质档」会返回一个似是而非的 URL（实测咪咕的
           * wav_32bit 母带就是 404）。偶尔一档 404 属于档位差异，降档往往能救回来
           * （咪咕 jymaster 404 → atmos 206 正是如此）；但**连续多档都 404**
           * 说明这个平台根本没有该曲资源，继续降档纯属浪费时间 ——
           * 直接收尾并交回上层，走「歌名跨平台找完整版」。
           */
          if (/直链不可用/.test(String((e && e.message) || ''))) {
            unusableTierCount += 1;
            if (unusableTierCount >= 2) {
              warn('连续 ' + unusableTierCount + ' 个档位直链均不可用，判定该平台无此资源，转跨平台寻找完整版');
              return attempt(maxTiers);
            }
          }
          warn('音质档位 ' + mr + ' 不可用，降级重试：', e && e.message ? e.message : e);
          return attempt(i + 1);
        });
    }
    return attempt(0);
  }

  /** 歌曲 → 平台码。优先看显式标记，其次按字段特征猜。 */
  function platformOf(song) {
    if (!song) return '';
    if (song.lxjsSourceCode) return song.lxjsSourceCode;
    var raw = String(song.provider || song.source || song.type || '').toLowerCase().trim();

    /**
     * ★ 关键修复（2026-10-05）：raw 本身可能就是合法的 LX 短码。
     *
     * 两张映射表都只认「全名」：
     *   PROVIDER_TO_LX = { netease:'wy', qq:'tx', kugou:'kg', kuwo:'kw', migu:'mg' }
     *   LX_TO_PROVIDER = { wy:'netease', tx:'qq', kg:'kugou', kw:'kuwo', mg:'migu' }
     *
     * 但宿主写进队列的 source 是**短码**（实测 50/50 首都是 source="tx"），
     * 于是：
     *   PROVIDER_TO_LX['tx'] → undefined
     *   LX_TO_PROVIDER['tx'] → undefined
     * 两个都查不到 ⇒ 一路落到函数末尾 return 'wy'（网易云）。
     *
     * 后果（实测 8263ms）：歌明明是 QQ 的，却被拿去试网易云的 6 个档位，
     * 每次都等网易云接口超时，白白浪费 8 秒才轮到跨平台搜索兜底
     * （搜索 653ms + 取流 79ms 就能成功）。
     *
     * 而音源声明的平台码本来就叫 tx/wy/kw/mg/kg（见 R.caps），
     * 所以 raw 命中 caps 时直接用即可，不需要经过映射表。
     */
    if (raw && R.caps && Object.prototype.hasOwnProperty.call(R.caps, raw)) return raw;

    if (PROVIDER_TO_LX[raw]) return PROVIDER_TO_LX[raw];
    if (LX_TO_PROVIDER[raw]) return raw;
    if (song.qqId || song.songmid && /^[A-Za-z0-9_-]{14}$/.test(String(song.songmid))) return 'tx';
    if (song.hash || song.audioHash || song.fileHash) return 'kg';
    if (song.rid) return 'kw';
    if (song.copyrightId) return 'mg';
    /**
     * ★ 不再默认猜成网易云（用户要求「不管什么平台都优先用导入的音源解析」）。
     *
     * 原来这里 `return 'wy'`，于是 Spotify / 汽水 / 其它音源不认识的平台会被硬当成
     * 网易云，拿它们的 ID 去网易云取流 —— 必然失败，还要白等一轮超时（实测 8s+）
     * 才回退到跨平台搜索。
     *
     * 现在返回空串：resolvePlaybackData 会立刻 reject，桥接函数直接转「歌名 + 歌手
     * 跨平台搜索」，在音源支持的平台里找同一首歌，既不白等，又能覆盖全平台。
     */
    return '';
  }

  /* ── 对外：搜索 ─────────────────────────────────────────── */

  /**
   * 用自定义音源搜索。逐平台并发 + 60s 内短 TTL 缓存。
   * 返回给宿主的 song 对象已按宿主格式归一化（provider/source/id/name/artist/album/…），
   * 宿主只需原样塞进搜索结果列表。
   */
  function search(keyword, opts) {
    opts = opts || {};
    keyword = String(keyword || '').trim();
    if (!keyword) return Promise.resolve([]);
    if (!R.activeId || !R.inited) return Promise.resolve([]);

    var codes = Object.keys(R.caps || {}).filter(function (c) {
      return (R.caps[c].actions || []).indexOf('search') >= 0;
    });
    if (!codes.length) {
      return Promise.reject(new Error('当前音源没有声明任何支持搜索的平台'));
    }

    var cached = R.searchCache[keyword];
    if (cached && (nowMs() - cached.ts) < R.SEARCH_CACHE_MS) {
      return Promise.resolve(cached.items.slice());
    }

    var perPlatform = Math.max(6, Math.min(30, Number(opts.limit) || 20));
    return Promise.all(codes.map(function (code) {
      return invoke(code, 'search', { keyword: keyword, page: 1, type: 0 }, 16000)
        .then(function (res) {
          var list = res && Array.isArray(res.data) ? res.data : [];
          return list.map(function (item) { return toHostSong(item, code); });
        })
        .catch(function (e) {
          warn('平台 ' + (LX_CODE_LABEL[code] || code) + ' 搜索失败：', e && e.message ? e.message : e);
          return [];
        });
    })).then(function (groups) {
      var items = dedupeByName(groups);
      R.searchCache[keyword] = { ts: nowMs(), items: items };
      if (Object.keys(R.searchCache).length > 60) {
        var keys = Object.keys(R.searchCache);
        keys.sort(function (a, b) { return R.searchCache[a].ts - R.searchCache[b].ts; });
        for (var i = 0; i < keys.length - 40; i++) delete R.searchCache[keys[i]];
      }
      return items;
    });
  }

  /** LX 搜索结果 → 宿主 song 结构。关键：打上 lxjs 标记，播放时才知道该找音源要直链。 */
  function toHostSong(item, lxCode) {
    var host = {
      id: item.id || item.mid || item.hash || (item.name + '|' + item.artist),
      mid: item.mid || item.songmid || item.id || '',
      name: item.name || '未知歌曲',
      artist: item.artist || '',
      album: item.album || '',
      albumPic: item.albumPic || item.pic || '',
      pic: item.albumPic || item.pic || '',
      duration: Number(item.duration) || 0,
      // 播放链路认这几个字段
      provider: LX_TO_PROVIDER[lxCode] || lxCode,
      source: lxCode,
      lxjsSourceCode: lxCode,
      sourceType: 'lxjs',
      fromUserSource: true
    };
    // 平台专属 id 回填
    if (item.hash) host.hash = item.hash;
    if (item.fileHash) host.fileHash = item.fileHash;
    if (item.songmid) host.songmid = item.songmid;
    if (item.mediaMid) host.mediaMid = item.mediaMid;
    if (item.rid) host.rid = item.rid;
    if (item.copyrightId) host.copyrightId = item.copyrightId;
    if (item.songid) host.songid = item.songid;
    if (lxCode === 'tx' && /^\d+$/.test(String(item.id || ''))) host.qqId = String(item.id);
    if (Array.isArray(item.artists) && item.artists.length) host.artists = item.artists;
    return host;
  }

  function dedupeByName(groups) {
    var seen = {};
    var out = [];
    groups.forEach(function (g) {
      g.forEach(function (s) {
        var key = (String(s.name || '').trim().toLowerCase()) + '|' +
          (String(s.artist || '').trim().toLowerCase());
        if (!key.replace(/[|\s]/g, '')) return;
        if (seen[key]) return;
        seen[key] = true;
        out.push(s);
      });
    });
    return out;
  }

  /* ── 对外：歌词 / 封面 ──────────────────────────────────── */

  function resolveLyric(song) {
    var lxCode = platformOf(song);
    if (!R.activeId || !R.inited || !R.caps || !R.caps[lxCode]) return Promise.resolve(null);
    if ((R.caps[lxCode].actions || []).indexOf('lyric') < 0) return Promise.resolve(null);
    var musicInfo = buildMusicInfo(song, lxCode, R.caps[lxCode].qualitys || []);
    return invoke(lxCode, 'lyric', { musicInfo: musicInfo }, 12000)
      .then(function (r) {
        if (!r || typeof r.lyric !== 'string' || !r.lyric.trim()) return null;
        return { lyric: r.lyric, tlyric: r.tlyric || '', rlyric: r.rlyric || '' };
      })
      .catch(function () { return null; });
  }

  function resolvePic(song) {
    var lxCode = platformOf(song);
    if (!R.activeId || !R.inited || !R.caps || !R.caps[lxCode]) return Promise.resolve('');
    if ((R.caps[lxCode].actions || []).indexOf('pic') < 0) return Promise.resolve('');
    var musicInfo = buildMusicInfo(song, lxCode, R.caps[lxCode].qualitys || []);
    return invoke(lxCode, 'pic', { musicInfo: musicInfo }, 12000)
      .then(function (u) { return /^https?:/i.test(String(u || '')) ? String(u) : ''; })
      .catch(function () { return ''; });
  }

  /* ── 对外：自检 ─────────────────────────────────────────── */

  /**
 * 借宿主官方搜索接口找样本歌。
 *
 * 用于「解析器型」音源的自检与降级：这类音源不会自己搜歌，
 * 但只要给它一个结构完整的 song 对象，它就能解析直链。
 * 逐个平台尝试（网易→QQ→酷狗），谁先返回用谁。
 */
function searchViaHost(keyword) {
    var providers = ['netease', 'qq', 'kugou'];
    function one(p) {
      var path = p === 'qq' ? '/api/qq/search?keywords='
        : p === 'kugou' ? '/api/kugou/search?keywords='
        : '/api/search?keywords=';
      return fetch(path + encodeURIComponent(keyword) + '&limit=5', {
        // 宿主 apiJson 默认超时较长，这里自己控一个
      }).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      }).then(function (j) {
        var list = (j && j.result && j.result.songs) ? j.result.songs
          : (j && j.songs) ? j.songs
          : (j && j.data && j.data.song && j.data.song.list) ? j.data.song.list
          : (Array.isArray(j) ? j : null);
        if (!list || !list.length) throw new Error('无结果');
        return list.slice(0, 5);
      });
    }
    return providers.reduce(function (chain, p) {
      return chain.then(function (acc) {
        if (acc.length) return acc;
        return one(p).catch(function () { return []; });
      });
    }, Promise.resolve([]));
  }

  function selfTest(keyword) {
    keyword = String(keyword || '周杰伦 晴天');
    var out = {
      ok: false,
      scriptLoaded: !!R.activeId,
      inited: !!R.inited,
      initError: R.initError || '',
      platforms: [],
      searchCount: 0,
      urlOk: false,
      url: '',
      error: ''
    };
    if (!R.activeId) { out.error = '没有已激活的音源'; return Promise.resolve(out); }
    if (!R.inited) { out.error = R.initError || '音源未初始化'; return Promise.resolve(out); }

    out.platforms = Object.keys(R.caps || {}).map(function (c) {
      return {
        code: c,
        label: LX_CODE_LABEL[c] || c,
        actions: (R.caps[c].actions || []).slice(),
        qualitys: (R.caps[c].qualitys || []).slice(),
        tiers: tiersFor(c)
      };
    });

    /**
     * 🔴 自检**不能依赖音源自己会搜索**。
     *
     * 早期版本固定走 `search()`，于是对「解析器型」音源（念心这类只实现
     * musicUrl、不实现 search 的脚本）必然报：
     *   「搜索返回 0 条」+「当前音源没有声明任何支持搜索的平台」
     * 哪怕它的取直链能力完全正常 —— 用户看到这种报错只会以为插件坏了。
     *
     * 正确逻辑分两路：
     *   ① 音源支持 search → 用它自己搜，验证整条链路
     *   ② 音源只做 musicUrl → 走宿主官方 /api/search 找样本歌，
     *      再用音源解析它的直链。这才是这类音源的真实用法。
     */
    var supportsSearch = out.platforms.some(function (p) {
      return (p.actions || []).indexOf('search') >= 0;
    });
    out.supportsSearch = supportsSearch;

    var findSample = supportsSearch
      ? search(keyword, { limit: 8 }).then(function (items) {
        out.searchCount = items.length;
        return items[0] || null;
      })
      : searchViaHost(keyword).then(function (items) {
        out.searchCount = items.length;
        out.searchSource = 'host';
        return items[0] || null;
      });

    return findSample.then(function (sample) {
      if (!sample) {
        out.error = supportsSearch
          ? '音源搜索无结果（脚本可能未实现 search，或接口需要额外配置）'
          : '连宿主官方搜索都没有结果（网络不通？换个关键词试试）';
        return out;
      }
      return resolvePlaybackData(sample).then(function (d) {
        out.urlOk = true;
        out.url = String(d.url || '').slice(0, 120);
        out.ok = true;
        out.song = { name: sample.name, artist: sample.artist };
        return out;
      }).catch(function (e) {
        out.error = '取直链失败：' + (e && e.message ? e.message : e);
        return out;
      });
    }).catch(function (e) {
      out.error = e && e.message ? e.message : String(e);
      return out;
    });
  }

  /* ── 初始化 & 对外接口 ──────────────────────────────────── */

  function boot() {
    var had = loadStore();
    if (had && R.activeId) {
      // 开机自动恢复：延迟一点，等宿主的音频/网络就绪
      setTimeout(function () {
        activate(R.activeId).catch(function (e) {
          warn('开机自动恢复音源失败：', e && e.message ? e.message : e);
        });
      }, 1500);
    } else if (had) {
      log('已恢复 ' + R.sources.length + ' 个音源（当前未激活）');
    } else {
      log('暂无已保存的音源');
    }
  }

  var API = {
    // 状态
    isActive: function () { return !!R.activeId && !!R.inited; },
    isReady: function () { return !!R.activeId && !!R.inited && !!R.worker; },
    activeId: function () { return R.activeId; },
    initError: function () { return R.initError; },
    caps: function () { return R.caps; },
    /** 当前音源声明的平台（规范短码，去掉 local） */
    platforms: function () {
      return Object.keys(R.caps || {}).filter(function (c) { return c !== 'local'; });
    },
    /**
     * 当前音源是否声明了某个平台。
     * 参数可以是宿主 provider（qishui/kugou…）、LX 短码（qs/kg）或脚本里的任意写法
     * （汽水/QQ音乐…），内部都会归一化。
     */
    supports: function (platform) {
      var raw = String(platform == null ? '' : platform).trim();
      var code = PROVIDER_TO_LX[raw.toLowerCase()] || canonicalLxCode(raw);
      return !!(code && R.caps && Object.prototype.hasOwnProperty.call(R.caps, code));
    },
    /** 快捷判断：当前音源声明了汽水吗 */
    supportsQishui: function () { return API.supports('qishui'); },
    sources: function () { return R.sources.map(function (s) { return Object.assign({}, s, { script: undefined }); }); },
    count: function () { return R.sources.length; },

    // 生命周期
    importScript: importScript,
    updateSource: updateSource,
    activate: activate,
    deactivate: deactivate,
    removeSource: removeSource,
    findSource: findSource,

    // 能力
    onChange: function (fn) { R.listener = fn; },
    getCaps: getCaps,
    tiersFor: tiersFor,
    platformOf: platformOf,
    parseScriptInfo: parseScriptInfo,

    // 核心能力
    search: search,
    searchViaHost: searchViaHost,
    resolvePlaybackData: resolvePlaybackData,
    resolveLyric: resolveLyric,
    resolvePic: resolvePic,
    buildMusicInfo: buildMusicInfo,
    selfTest: selfTest,

    // 常量（集成层要用）
    LX_TO_PROVIDER: LX_TO_PROVIDER,
    PROVIDER_TO_LX: PROVIDER_TO_LX,
    LX_CODE_LABEL: LX_CODE_LABEL,
    MR_QUALITY_ORDER: MR_QUALITY_ORDER,
    REQUEST_TIMEOUT_MS: REQUEST_TIMEOUT_MS,

    // 内部维护
    _teardown: teardownWorker,
    _setWorkerUrl: function (u) { W.__mrLxWorkerUrl = u; },

    // 试听识别 / 补源的内部件：供自检与排错，不是稳定 API
    _trial: {
      nominalSeconds: nominalSeconds,
      probeIsPreview: probeIsPreview,
      candidatePlatform: candidatePlatform,
      isSameSong: isSameSong,
      rescueFullVersion: rescueFullVersion,
      TRIAL_FLOOR_BYTES_PER_SEC: TRIAL_FLOOR_BYTES_PER_SEC,
      TRIAL_BYTES_SAFETY: TRIAL_BYTES_SAFETY,
      caches: { probe: probeCache, rescue: rescueCache }
    }
  };

  W.MrLxSource = API;
  boot();
})();