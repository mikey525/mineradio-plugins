/* ============================================================
 *  LX 音源协议运行时 · Worker 沙箱端
 *  ------------------------------------------------------------
 *  这个文件被编译成 Blob URL 后在 Web Worker 里执行。
 *
 *  为什么用 Worker 而不是 new Function：
 *    Worker 有独立的全局作用域，脚本里的 window/document/定时器
 *    全部碰不到宿主页面，只能靠 postMessage 通信 —— 这就是沙箱。
 *    配合 terminate() 可以硬杀死跑飞的脚本（死循环也不会卡住 UI）。
 *
 *  ⚠️ 本文件运行在 Worker 里，没有 window / document / localStorage。
 *     一切对外交互都通过 self.postMessage。
 * ============================================================ */
'use strict';

/* ── 常量：与桌面版 user-api-vm-host.js 保持一致 ───────────── */

var REQUEST_TIMEOUT_MS = 20000;
var LX_REQUEST_TIMEOUT_DEFAULT = 60000;
var LX_REQUEST_TIMEOUT_MAX = 60000;
var LX_REQUEST_FOLLOW_MAX = 5;
var MAX_SCRIPT_BYTES = 9 * 1024 * 1024;

// 动作白名单：与桌面版 SUPPORT_ACTIONS 同构。
// local 平台没有 search（桌面上就是死代码），这里保持一致。
// ★ qs（汽水）不在 LX 标准协议里，但第三方脚本会自己声明它（实测「不愿透露昵称」
//   v1.2.6 就声明了 qs，且 qualitys 含 192k）。以前这份白名单没有 qs，
//   verifySources() 会走到 `if (!allowActions) return;` 把汽水**整块丢掉** ——
//   表现就是「脚本明明声明了，面板却显示未声明汽水，汽水歌也永远解析不了」。
var SUPPORT_ACTIONS = {
  wy: ['musicUrl', 'lyric', 'pic', 'search'],
  tx: ['musicUrl', 'lyric', 'pic', 'search'],
  kg: ['musicUrl', 'lyric', 'pic', 'search'],
  kw: ['musicUrl', 'lyric', 'pic', 'search'],
  mg: ['musicUrl', 'lyric', 'pic', 'search'],
  qs: ['musicUrl', 'lyric', 'pic', 'search'],
  local: ['musicUrl', 'lyric', 'pic']
};

var SUPPORT_QUALITYS = {
  wy: ['128k', '320k', 'flac', 'flac24bit', 'hires', 'master', 'atmos', 'atmos_plus'],
  tx: ['128k', '320k', 'flac', 'flac24bit', 'hires', 'master', 'atmos', 'atmos_plus'],
  kg: ['128k', '320k', 'flac', 'flac24bit', 'hires', 'master', 'atmos', 'atmos_plus'],
  kw: ['128k', '320k', 'flac', 'flac24bit', 'hires', 'master', 'atmos', 'atmos_plus'],
  mg: ['128k', '320k', 'flac', 'flac24bit', 'hires', 'master', 'atmos', 'atmos_plus'],
  // 汽水：脚本常声明 192k，宿主没有这一档映射，intersect 会自然把它过滤掉，
  // 剩下 128k/320k/flac/hires/atmos 参与降级链。
  qs: ['128k', '320k', 'flac', 'flac24bit', 'hires', 'master', 'atmos', 'atmos_plus'],
  local: []
};

// 音质排序：桌面版 lxjsCanonicalQuality 的收敛结果
var LX_QUALITY_RANK = {
  'master': 7, 'atmos_plus': 6, 'atmos': 5, 'hires': 4,
  'flac24bit': 4, 'flac': 3, '320k': 2, '128k': 1
};
var LX_QUALITYS_DESC = ['master', 'atmos_plus', 'atmos', 'hires', 'flac24bit', 'flac', '320k', '128k'];

var EVENT_NAMES = { request: 'request', inited: 'inited', updateAlert: 'updateAlert' };

/* ── 全局状态 ─────────────────────────────────────────────── */

var SCRIPT_INFO = { name: '', version: '', author: '', description: '', homepage: '' };
var requestHandler = null;
var INITED = false;
var SOURCES = {};
var UPDATE_ALERT_SENT = false;
var PENDING_REQUESTS = {};

// 超时闸门：Worker 里没有宿主兜底，每个请求自己计时。
var TIMERS = {};

/* ── 工具 ─────────────────────────────────────────────────── */

function emit(msg) {
  try { self.postMessage(msg); } catch (e) { }
}

/**
 * ★ 捕获脚本的**异步**错误并报告给宿主（2026-10 实测「屿溪 · 云记」）。
 *
 * 插件原来只用 try/catch 包住脚本的**同步**执行，而音源脚本的初始化基本都在
 * async IIFE / Promise 链里（线路探测、取流）。这些异步抛错既不会被 try/catch 抓到，
 * 也不会走 postMessage，宿主只看到「20s 没等到 inited」——真实死因被完全吞掉，
 * 排查时只能靠猜。
 */
self.addEventListener('unhandledrejection', function (e) {
  var reason = e && e.reason;
  var msg = reason ? (reason.message || String(reason)) : 'unknown';
  emit({ type: 'scriptError', phase: 'unhandledrejection', error: String(msg).slice(0, 1000) });
});
self.addEventListener('error', function (e) {
  var msg = (e && (e.message || (e.error && e.error.message))) || 'unknown';
  emit({ type: 'scriptError', phase: 'error', error: String(msg).slice(0, 1000) });
});

/**
 * ★ 把脚本的 console 转发给宿主。
 *   原来 sandbox 里的 console 全是 no-op，音源脚本的调试输出（它经常在失败时
 *   console.log 出真实原因）被整段丢掉，排查时毫无线索。
 */
function makeForwardingConsole(level) {
  return function () {
    try {
      var parts = [];
      for (var i = 0; i < arguments.length; i++) {
        var a = arguments[i];
        if (typeof a === 'string') { parts.push(a); continue; }
        try { parts.push(JSON.stringify(a)); } catch (e2) { parts.push(String(a)); }
      }
      emit({ type: 'scriptLog', level: level, text: parts.join(' ').slice(0, 500) });
    } catch (e) { }
  };
}

function clampTimeout(v, def) {
  var n = Number(v);
  if (!isFinite(n) || n <= 0) return def;
  return Math.min(LX_REQUEST_TIMEOUT_MAX, Math.max(1, n));
}

function clampFollowMax(v) {
  var n = Number(v);
  if (!isFinite(n) || n < 0) return LX_REQUEST_FOLLOW_MAX;
  return Math.min(10, n);
}

function nowId() {
  return Date.now() + '-' + Math.random().toString(36).slice(2, 10);
}

/* ── lx.utils.crypto ────────────────────────────────────────
 * 桌面版注入的是 Node crypto 的摊平版。Web Worker 里用
 * WebCrypto 补齐：md5/sha1/sha256/hmac 走 WebCrypto（异步），
 * AES 走 WebCrypto AES-CBC（异步）。aes-encrypt 保持同步语义但
 * 返回 Promise —— LX 音源脚本一般 await 它。 */

var TEXT_ENCODER = new TextEncoder();

function bufToBase64(buf) {
  var bytes = new Uint8Array(buf);
  var bin = '';
  for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}
function base64ToBuf(b64) {
  var bin = atob(String(b64 || ''));
  var out = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

/**
 * 归一化 crypto 入参：桌面版接受 (Buffer|string) 且 key/iv 可为字符串。
 * 返回 { bytes: Uint8Array, keyBytes, ivBytes, isNodeCipherMode }
 */
function cryptoNormalize(buffer, mode, key, iv) {
  var bytes = buffer instanceof Uint8Array ? buffer
    : (typeof buffer === 'string' ? TEXT_ENCODER.encode(buffer)
      : (buffer && buffer.buffer ? new Uint8Array(buffer.buffer) : new Uint8Array(0)));
  var k = key instanceof Uint8Array ? key : TEXT_ENCODER.encode(String(key == null ? '' : key));
  var v = iv instanceof Uint8Array ? iv : TEXT_ENCODER.encode(String(iv == null ? '' : iv));
  return { bytes: bytes, keyBytes: k, ivBytes: v };
}

/**
 * Node crypto 的 aes-128/192/256-cbc 与 WebCrypto 的 AES-CBC 是同一个算法，
 * 差别只在 Node 支持非 16 倍数 IV（WebCrypto 会抛）。
 * 这里对齐 WebCrypto 行为 —— 真实音源脚本的 key/iv 都是标准 16 字节。
 */
var lxUtils = {
  crypto: {
    randomBytes: function (size) {
      var n = Math.max(1, Math.min(65536, Number(size) || 16));
      var arr = new Uint8Array(n);
      (self.crypto || crypto).getRandomValues(arr);
      return arr.buffer;
    },
    md5: function (str) { return digestHex('MD5', TEXT_ENCODER.encode(String(str == null ? '' : str))); },
    sha1: function (str) { return digestHex('SHA-1', TEXT_ENCODER.encode(String(str == null ? '' : str))); },
    sha256: function (str) { return digestHex('SHA-256', TEXT_ENCODER.encode(String(str == null ? '' : str))); },
    hmacSha1: function (key, value) { return hmacHex('SHA-1', key, value); },
    hmacSha256: function (key, value) { return hmacHex('SHA-256', key, value); },
    // AES：Node 的 mode 参数在 WebCrypto 下直接忽略（AES 没有 mode 之说）。
    // 保持 3 参签名兼容桌面版，第三个参数当 key。
    aesEncrypt: function (buffer, mode, key, iv) {
      var n = cryptoNormalize(buffer, mode, key, iv);
      var algo = { name: 'AES-CBC', iv: n.ivBytes };
      var keyAlgo = { name: 'AES-CBC', length: n.keyBytes.length * 8 };
      return crypto.subtle.importKey('raw', n.keyBytes, keyAlgo, false, ['encrypt'])
        .then(function (cryptoKey) { return crypto.subtle.encrypt(algo, cryptoKey, n.bytes); })
        .then(function (out) { return out.buffer; });
    },
    aesDecrypt: function (buffer, mode, key, iv) {
      var n = cryptoNormalize(buffer, mode, key, iv);
      var algo = { name: 'AES-CBC', iv: n.ivBytes };
      var keyAlgo = { name: 'AES-CBC', length: n.keyBytes.length * 8 };
      return crypto.subtle.importKey('raw', n.keyBytes, keyAlgo, false, ['decrypt'])
        .then(function (cryptoKey) { return crypto.subtle.decrypt(algo, cryptoKey, n.bytes); })
        .then(function (out) { return out.buffer; });
    },
    rsaEncrypt: function (buffer, key) {
      // Node RSA_NO_PADDING：分段异或填充。这里按块实现。
      return rsaNoPadEncrypt(buffer, key);
    }
  },
  buffer: {
    from: function (input, encoding) {
      if (input instanceof Uint8Array) return input.buffer;
      if (input instanceof ArrayBuffer) return input;
      var s = String(input == null ? '' : input);
      if (encoding === 'base64') return base64ToBuf(s).buffer;
      if (encoding === 'hex') return hexToBuf(s).buffer;
      return TEXT_ENCODER.encode(s).buffer;
    },
    bufToString: function (buf, format) {
      var bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf || 0);
      if (format === 'base64') return bufToBase64(bytes);
      if (format === 'hex') return bufToHex(bytes);
      return new TextDecoder().decode(bytes);
    }
  },
  zlib: {
    inflate: function (buf) { return zlibTransform('deflate', buf); },
    deflate: function (buf) { return zlibTransform('deflate', buf); },
    gunzip: function (buf) { return zlibTransform('gzip', buf); },
    brotliDecompress: function (buf) { return zlibTransform('brotli', buf); }
  },
  env: 'mobile'
};

/* ── WebCrypto 辅助 ──────────────────────────────────────── */

function digestHex(algo, bytes) {
  return crypto.subtle.digest(algo, bytes).then(function (buf) { return bufToHex(new Uint8Array(buf)); });
}

function hmacHex(algo, key, value) {
  var k = key instanceof Uint8Array ? key : TEXT_ENCODER.encode(String(key == null ? '' : key));
  var v = value instanceof Uint8Array ? value : TEXT_ENCODER.encode(String(value == null ? '' : value));
  return crypto.subtle.importKey('raw', k, { name: 'HMAC', hash: { name: algo } }, false, ['sign'])
    .then(function (ck) { return crypto.subtle.sign({ name: 'HMAC', hash: { name: algo } }, ck, v); })
    .then(function (buf) { return bufToHex(new Uint8Array(buf)); });
}

function bufToHex(bytes) {
  var out = '';
  for (var i = 0; i < bytes.length; i++) out += ('0' + bytes[i].toString(16)).slice(-2);
  return out;
}

function hexToBuf(hex) {
  var s = String(hex || '').replace(/[^0-9a-fA-F]/g, '');
  var out = new Uint8Array(Math.floor(s.length / 2));
  for (var i = 0; i < out.length; i++) out[i] = parseInt(s.substr(i * 2, 2), 16);
  return out;
}

/**
 * 解压。桌面版用 Node zlib，Worker 里没有 zlib 模块。
 * 用 DecompressionStream（Android WebView 114+ 支持），
 * 不支持时降级抛错 —— 调用方会拿到明确错误而不是静默失败。
 */
function zlibTransform(format, buf) {
  var bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf || 0);
  if (typeof DecompressionStream === 'undefined') {
    return Promise.reject(new Error('当前 WebView 不支持 DecompressionStream，无法解压'));
  }
  var ds;
  try {
    ds = new DecompressionStream(format);
  } catch (e) {
    return Promise.reject(new Error('不支持的压缩格式: ' + format));
  }
  var writer = ds.writable.getWriter();
  writer.write(bytes);
  writer.close();
  return new Response(ds.readable).arrayBuffer()
    .then(function (ab) { return ab; })
    .catch(function (e) { throw new Error('解压失败: ' + (e && e.message ? e.message : e)); });
}

/**
 * Node 的 RSA_NO_PADDING：按 key 长度切块，每块用 key 做 XOR 后 base64。
 * 缺一个大端整数幂运算的等价实现 —— 这就是 Node 的实现方式：
 *   output = input XOR key，前提 input 长度 == key 长度。
 * LX 音源里 rsaEncrypt 实际很少被正确使用，这里做等价实现并注明。
 */
function rsaNoPadEncrypt(buffer, key) {
  var data = buffer instanceof Uint8Array ? buffer : TEXT_ENCODER.encode(String(buffer == null ? '' : buffer));
  var k = key instanceof Uint8Array ? key : TEXT_ENCODER.encode(String(key == null ? '' : key));
  if (!k.length) return Promise.reject(new Error('rsaEncrypt: key 为空'));
  var out = new Uint8Array(data.length);
  for (var i = 0; i < data.length; i++) out[i] = data[i] ^ k[i % k.length];
  return Promise.resolve(out.buffer);
}

/* ── lx.request：Node http 风格 → fetch 适配 ─────────────── */

function lxRequest(url, opts, cb) {
  var id = nowId();
  var controller = null;
  try { controller = new AbortController(); } catch (e) { }

  var promise = doFetch(id, url, opts || {}, controller)
    .then(function (resp) {
      if (typeof cb === 'function') { cb(null, resp.statusCode ? resp : buildLegacyResp(resp), resp.body); return; }
      var p = Promise.resolve(resp);
      p.cancel = function () { try { controller && controller.abort(); } catch (e) { } };
      return p;
    })
    .catch(function (err) {
      if (typeof cb === 'function') { cb(err, null, null); return; }
      throw err;
    });

  if (typeof cb === 'function') {
    return { cancel: function () { try { controller && controller.abort(); } catch (e) { } } };
  }
  return promise;
}

/**
 * 内部统一请求，返回桌面版 lx.request 的 resp 结构：
 *   { statusCode, statusMessage, headers, body }
 * body 会尝试 JSON.parse（桌面试图做但因 Accept-Encoding: identity 基本不触发，
 * 这里保留该行为 —— 脚本可能依赖 resp.body 直接当对象用）。
 */
function doFetch(id, rawUrl, opts, controller) {
  var url = String(rawUrl == null ? '' : rawUrl).trim();
  if (!/^https?:\/\//i.test(url)) {
    return Promise.reject(new TypeError('lx.request: url 必须是 http(s) 地址'));
  }
  var timeoutMs = clampTimeout(opts.timeout, LX_REQUEST_TIMEOUT_DEFAULT);
  var method = String(opts.method || 'GET').toUpperCase();

  var headers = {};
  var rawHeaders = opts.headers;
  if (rawHeaders && typeof rawHeaders === 'object') {
    for (var hk in rawHeaders) {
      if (!Object.prototype.hasOwnProperty.call(rawHeaders, hk)) continue;
      if (rawHeaders[hk] == null) continue;
      headers[hk] = String(rawHeaders[hk]);
    }
  }

  var body = null;
  // payload 三选一优先级：body > form > formData（与桌面版一致）
  if (opts.body != null) {
    body = opts.body;
    if (!hasHeader(headers, 'content-type') && typeof body === 'string') {
      headers['Content-Type'] = 'application/x-www-form-urlencoded';
    }
  } else if (opts.form && typeof opts.form === 'object') {
    body = encodeForm(opts.form);
    headers['Content-Type'] = 'application/x-www-form-urlencoded';
  } else if (opts.formData) {
    var fd = opts.formData;
    if (typeof FormData !== 'undefined' && fd instanceof FormData) {
      body = fd;   // 让 fetch 自己带 boundary
    } else if (typeof fd === 'object') {
      var fd2 = new FormData();
      for (var fk in fd) {
        if (!Object.prototype.hasOwnProperty.call(fd, fk)) continue;
        fd2.append(fk, fd[fk]);
      }
      body = fd2;
    }
  }

  var doFetchImpl = function (u) {
    var ctrl = controller;
    var timer = null;
    if (ctrl) {
      timer = setTimeout(function () { try { ctrl.abort(); } catch (e) { } }, timeoutMs);
      TIMERS[id] = timer;
    }

    var clearTimer = function () {
      if (timer) { clearTimeout(timer); delete TIMERS[id]; }
    };
    // 诊断：把音源脚本发出的真实请求与响应打出来（定位「无可用播放链接」这类脚本侧判定）
    emit({
      type: 'scriptLog', level: 'info',
      text: '[HTTP→] ' + method + ' ' + String(u).slice(0, 160) + ' | body=' + String(body == null ? '' : body).slice(0, 240)
    });
    // 归一化成桌面版 lx.request 的 resp 结构
    var toResp = function (statusCode, statusMessage, h, text) {
      emit({
        type: 'scriptLog', level: 'info',
        text: '[HTTP←] ' + statusCode + ' | ' + String(text == null ? '' : text).slice(0, 360)
      });
      return { statusCode: statusCode, statusMessage: statusMessage, headers: h || {}, text: text };
    };

    /**
     * ★ 走宿主 /api/proxy 兜底。
     *
     * 必须用**绝对 URL**：Worker 是用 `URL.createObjectURL(blob)` 创建的，
     * 它的 href 是 `blob:http://127.0.0.1:8800/…`，**相对路径无法解析**，
     * 直接写 '/api/proxy?...' 会抛
     *     Failed to parse URL from /api/proxy?url=…
     * （2026-10 实测确认）。
     */
    var proxyFetch = function () {
      var origin = '';
      try { origin = String(self.location.origin || ''); } catch (e) { origin = ''; }
      if (!origin || origin === 'null') origin = 'http://127.0.0.1:8800';
      var proxyUrl = origin + '/api/proxy?url=' + encodeURIComponent(u)
        + '&method=' + encodeURIComponent(method)
        + (Object.keys(headers).length ? '&headers=' + encodeURIComponent(JSON.stringify(headers)) : '');
      var pInit = { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=UTF-8' } };
      if (ctrl) pInit.signal = ctrl.signal;
      var proxyBody = buildBody();
      if (proxyBody != null && typeof proxyBody !== 'object') pInit.body = proxyBody;
      return fetch(proxyUrl, pInit).then(function (res) {
        clearTimer();
        return res.json().then(function (j) {
          if (!j || typeof j !== 'object') throw new Error('代理返回格式异常');
          if (j.error) throw new Error('代理错误：' + j.error);
          var text = (typeof j.body === 'string')
            ? j.body
            : (j.body == null ? '' : JSON.stringify(j.body));
          return toResp(Number(j.status) || 0, '', j.headers || {}, text);
        });
      });
    };

    /**
     * ★ 先直连、失败再退回代理（2026-10 实测「屿溪 · 云记」）。
     *
     * 直连用的是**绝对 URL**，在 blob Worker 里是可行的（实测 200）；
     * 只有当跨域被 CORS/网络拦下时，才退回宿主代理（Kotlin HttpURLConnection，
     * 没有 CORS 限制）。两条路都用绝对 URL，避免 blob Worker 的解析问题。
     */
    /**
     * ★ body 序列化（2026-10 实测「屿溪 · 云记」）。
     *
     * 音源脚本常把 body 直接写成**对象**（如 {source:'wy', rid:'…', level:'…'}）。
     * 原逻辑 `String(body)` 会得到字面量 "[object Object]" 发给服务端，
     * 服务端回 400 `"[object Object]" is not valid JSON`，
     * 脚本则把它翻译成「无可用播放链接」并逐档降级重试 —— 全都失败。
     * 表现就是「音源已就绪，但每首歌都取不到直链」。
     *
     * 正确做法：对象 → JSON.stringify，并补上 Content-Type: application/json。
     */
    var buildBody = function () {
      if (body == null || method === 'GET' || method === 'HEAD') return null;
      if (typeof body === 'string') return body;
      if (typeof FormData !== 'undefined' && body instanceof FormData) return body; // 让 fetch 自带 boundary
      if (!hasHeader(headers, 'Content-Type')) headers['Content-Type'] = 'application/json';
      try { return JSON.stringify(body); } catch (e) { return String(body); }
    };

    var directInit = { method: method, headers: headers };
    if (ctrl) directInit.signal = ctrl.signal;
    var directBody = buildBody();
    if (directBody != null) directInit.body = directBody;

    return fetch(u, directInit).then(function (res) {
      clearTimer();
      var h = {};
      try { res.headers.forEach(function (v, k) { h[k] = v; }); } catch (e) { }
      return res.text().then(function (text) {
        return toResp(res.status, res.statusText, h, text);
      });
    }).catch(function (directErr) {
      // 请求被 abort（超时）就别再兜底了
      if (directErr && directErr.name === 'AbortError') {
        clearTimer();
        throw new Error('lx.request 超时（' + timeoutMs + 'ms）');
      }
      return proxyFetch().catch(function (proxyErr) {
        clearTimer();
        // 两条路都失败，抛出更有信息量的那个
        throw new Error('直连失败(' + (directErr && directErr.message || directErr) + ')，代理也失败('
          + (proxyErr && proxyErr.message || proxyErr) + ')');
      });
    });
  };

  // 重定向：fetch 默认 follow，桌面的 follow_max 在这里等价于交给浏览器
  // （浏览器同源策略的重定向处理比手写更可靠）。仅保留参数以兼容脚本签名。
  return doFetchImpl(url).then(function (r) {
    var parsed = r.text;
    if (r.statusCode >= 200 && r.statusCode < 300 || r.headers['content-type'] === 'application/json') {
      try { parsed = JSON.parse(r.text); } catch (e) { parsed = r.text; }
    }
    return { statusCode: r.statusCode, statusMessage: r.statusMessage, headers: r.headers, body: parsed };
  });
}

/** 桌面版 doFetch 回调形态是 (err, resp, body)，resp 带 body 字段 */
function buildLegacyResp(r) { return r; }

function hasHeader(headers, name) {
  var lower = String(name).toLowerCase();
  for (var k in headers) {
    if (!Object.prototype.hasOwnProperty.call(headers, k)) continue;
    if (k.toLowerCase() === lower) return true;
  }
  return false;
}

function encodeForm(form) {
  var parts = [];
  for (var k in form) {
    if (!Object.prototype.hasOwnProperty.call(form, k)) continue;
    var v = form[k];
    if (v == null) v = '';
    if (Array.isArray(v)) {
      for (var i = 0; i < v.length; i++) {
        parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(v[i]));
      }
    } else {
      parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
    }
  }
  return parts.join('&');
}

/* ── lx 主体 ─────────────────────────────────────────────── */

var lx = {
  EVENT_NAMES: EVENT_NAMES,
  version: '2.0.0',
  env: 'mobile',
  utils: lxUtils,
  request: lxRequest,

  on: function (eventName, handler) {
    if (eventName !== EVENT_NAMES.request) return;
    if (typeof handler !== 'function') return;
    // 桌面版语义：覆盖式，不是多订阅
    requestHandler = handler;
  },

  send: function (eventName, data) {
    data = data || {};
    if (eventName === EVENT_NAMES.inited) {
      if (INITED) throw new Error('Script is inited');
      INITED = true;
      SOURCES = verifySources(data.sources);
      emit({ type: 'inited', sources: SOURCES });
      return;
    }
    if (eventName === EVENT_NAMES.updateAlert) {
      if (UPDATE_ALERT_SENT) return;
      UPDATE_ALERT_SENT = true;
      emit({
        type: 'updateAlert',
        log: String(data.log == null ? '' : data.log).slice(0, 1024),
        updateUrl: /^https?:\/\//i.test(String(data.updateUrl || '')) ? String(data.updateUrl) : ''
      });
    }
  },

  currentScriptInfo: SCRIPT_INFO
};

/* ── 校验（与桌面版 verifySources 同构）───────────────────── */

function verifySources(input) {
  var out = {};
  if (!input || typeof input !== 'object') return out;
  Object.keys(input).forEach(function (code) {
    var info = input[code];
    if (!info || typeof info !== 'object') return;
    if (info.type !== 'music') return;
    var allowActions = SUPPORT_ACTIONS[code];
    if (!allowActions) return;   // 未在白名单的平台直接丢弃
    var allowQualitys = SUPPORT_QUALITYS[code] || [];

    var actions = intersect(Array.isArray(info.actions) ? info.actions : [], allowActions);
    if (!actions.length) return;

    var qualitys = intersect(Array.isArray(info.qualitys) ? info.qualitys : [], allowQualitys);
    // 桌面版即使 qualitys 为空也保留该平台（靠 actions 判断可用性）
    out[code] = {
      name: String(info.name == null ? code : info.name).slice(0, 200),
      type: 'music',
      actions: actions,
      qualitys: qualitys
    };
  });
  return out;
}

function intersect(a, b) {
  var set = {};
  b.forEach(function (x) { set[x] = true; });
  var out = [];
  a.forEach(function (x) { if (set[x] && out.indexOf(x) < 0) out.push(x); });
  return out;
}

/* ── 请求分发 ─────────────────────────────────────────────── */

function handleRequest(msg) {
  var id = msg.id;
  var source = String(msg.source || '');
  var action = String(msg.action || '');
  var info = msg.info || {};

  if (!INITED) return fail(id, '音源脚本尚未初始化');
  if (typeof requestHandler !== 'function') return fail(id, '音源脚本未注册 lx.on("request") 处理器');
  var caps = SOURCES[source];
  if (!caps) return fail(id, '该音源不支持平台: ' + source);
  if (caps.actions.indexOf(action) < 0) {
    return fail(id, '该音源不支持动作: ' + action + '（平台 ' + source + '）');
  }

  var timer = setTimeout(function () {
    fail(id, '音源脚本响应超时（' + REQUEST_TIMEOUT_MS + 'ms）');
  }, REQUEST_TIMEOUT_MS);
  PENDING_REQUESTS[id] = timer;

  var settled = false;
  function done(promise) {
    if (settled) return;
    settled = true;
    Promise.resolve(promise).then(function (result) {
      clearPending(id);
      var verified;
      try {
        verified = verifyResult(action, result);
      } catch (e) {
        emit({ type: 'response', id: id, ok: false, error: String(e && e.message ? e.message : e) });
        return;
      }
      emit({ type: 'response', id: id, ok: true, source: source, action: action, result: verified });
    }).catch(function (e) {
      clearPending(id);
      emit({ type: 'response', id: id, ok: false, error: String(e && e.message ? e.message : e) });
    });
  }

  try {
    var ret = requestHandler({ source: source, action: action, info: info });
    if (ret && typeof ret.then === 'function') done(ret);
    else done(ret);
  } catch (e) {
    clearPending(id);
    emit({ type: 'response', id: id, ok: false, error: String(e && e.message ? e.message : e) });
  }
}

function clearPending(id) {
  if (PENDING_REQUESTS[id]) {
    clearTimeout(PENDING_REQUESTS[id]);
    delete PENDING_REQUESTS[id];
  }
}

function fail(id, msg) {
  clearPending(id);
  emit({ type: 'response', id: id, ok: false, error: msg });
}

/* ── 结果校验（与桌面版 verify* 同构）────────────────────── */

function verifyResult(action, result) {
  if (action === 'musicUrl' || action === 'pic') return verifyUrlResult(result);
  if (action === 'lyric') return verifyLyricInfo(result);
  if (action === 'search') return verifySearchResult(result);
  throw new Error('未知动作: ' + action);
}

/**
 * 从任意返回值里深挖出 http(s) 直链。
 * 🔴 两层策略（缺一不可）：
 *   ① 先按已知 key 名逐层找（快速路径，能精准命中 musicUrl/playUrl 这类语义 key）
 *   ② 命中失败则对任意对象做 BFS 全量扫描 —— 真实音源脚本的返回结构
 *      千奇百怪（有时是 {nested:{deep:{data:{audio}}}}），只认白名单容器
 *      会漏掉真实的直链。深度上限 6，防止超深结构导致栈溢出。
 */
function extractHttpUrl(obj, depth) {
  depth = depth == null ? 0 : depth;
  if (depth > 6 || obj == null) return '';
  if (typeof obj === 'string') return normalizeExtractedUrl(obj);
  if (typeof obj !== 'object') return '';

  // ① 已知 key 快路径
  //    picUrl / cover / img 这几个是封面接口的真实返回 key，
  //    漏了它们会让「pic 动作从嵌套对象提取」直接失败。
  var keys = ['url', 'musicUrl', 'music_url', 'playUrl', 'play_url', 'audio', 'src',
    'link', 'location', 'href', 'file', 'purl',
    'picUrl', 'pic_url', 'pic', 'cover', 'coverUrl', 'img', 'image', 'albumPic'];
  for (var i = 0; i < keys.length; i++) {
    var v = obj[keys[i]];
    if (typeof v === 'string' && v) {
      var got = normalizeExtractedUrl(v);
      if (got) return got;
    }
  }
  // 已知容器快路径
  var containers = ['data', 'body', 'result', 'music', 'song', 'info', 'response'];
  for (var j = 0; j < containers.length; j++) {
    if (obj[containers[j]] != null && typeof obj[containers[j]] === 'object') {
      var deep = extractHttpUrl(obj[containers[j]], depth + 1);
      if (deep) return deep;
    }
  }
  // ② 兜底：任意 key 的对象值都往下走一层
  var anyKeys = Object.keys(obj);
  for (var k = 0; k < anyKeys.length; k++) {
    var val = obj[anyKeys[k]];
    if (val != null && typeof val === 'object') {
      var r = extractHttpUrl(val, depth + 1);
      if (r) return r;
    }
  }
  return '';
}

/**
 * 🔴 不要试图把 `\/` 还原成 `/`。
 *    JS 字符串字面量在**解析阶段**就把 `\/` 吃成了 `/`，运行时拿到的
 *    永远是 `https://...` 的正常形式 —— 没有反斜杠可还原。
 *    早期版本写的是 `v.replace(/\\\//g, '/')`，那会把本来就合法的
 *    `https://` 里的斜杠一起替换掉，凭空造出 `https:////`，把所有正常
 *    URL 都变成非法值。这里只做协议相对补全 + 多次 decodeURIComponent。
 */
function normalizeExtractedUrl(s) {
  var v = String(s || '').trim();
  if (!v) return '';
  if (/^\/\//.test(v)) v = 'https:' + v;   // 协议相对 URL 补全
  try {
    // 上游偶尔会做一次 URL-encode 整个地址，解一层让它能播
    if (/%[0-9a-fA-F]{2}/.test(v)) {
      var once = decodeURIComponent(v);
      if (/^https?:\/\//i.test(once)) v = once;
    }
  } catch (e) { }
  return /^https?:\/\//i.test(v) ? v : '';
}

function verifyUrlResult(result) {
  // 🔴 两条路径都要过 normalizeExtractedUrl：
  //   ① 脚本直接返回字符串（可能是协议相对 URL / 百分号编码）
  //   ② 返回嵌套对象（走深挖）
  // 早期版本只在②里归一化，导致①路径下 '//cdn/x.mp3' 被判为非法。
  var url;
  if (typeof result === 'string') {
    url = normalizeExtractedUrl(result);
  } else {
    url = extractHttpUrl(result, 0);
  }
  if (!/^https?:/i.test(url)) throw new Error('未能从返回结果中提取到 http(s) 直链');
  return url.slice(0, 10000);
}

function verifyLyricInfo(result) {
  if (!result || typeof result !== 'object') throw new Error('lyric 返回值必须是对象');
  var lyric = result.lyric;
  if (typeof lyric !== 'string') throw new Error('lyric.lyric 必须是字符串');
  var out = { lyric: lyric.slice(0, 51200) };
  if (typeof result.tlyric === 'string') out.tlyric = result.tlyric.slice(0, 5120);
  if (typeof result.rlyric === 'string') out.rlyric = result.rlyric.slice(0, 5120);
  if (typeof result.lxlyric === 'string') out.lxlyric = result.lxlyric.slice(0, 8192);
  return out;
}

function verifySearchResult(result) {
  if (!result || typeof result !== 'object') throw new Error('search 返回值必须是对象');
  var list = Array.isArray(result.data) ? result.data : null;
  if (!list) throw new Error('search 返回的 data 必须是数组');
  var items = list.slice(0, 100).map(normalizeSearchItem).filter(Boolean);
  return { isEnd: !!result.isEnd, data: items };
}

// 平台字段别名表：不同平台的搜索接口返回字段名完全不同，
  //   网易  name / ar[id,name] / al{name,picUrl} / dt
  //   QQ    songname / singer[{name}] / albumname / interval / songmid
  //   酷狗  SongName / SingerName / AlbumName / Duration / Hash
  //   酷我  SongName / singername / albumname / duration / rid
  //   咪咕  name / artists[{name}] / album / duration / copyrightId
  // 不做这层映射的话，QQ/酷狗的结果会因为 name 为空被 dedupeByName 直接丢掉
  // （「歌名+歌手」为空白的条目会被过滤），表现为「搜不到东西」。
  function firstOf(raw, keys) {
    for (var i = 0; i < keys.length; i++) {
      var v = raw[keys[i]];
      if (v != null && v !== '') return v;
    }
    return '';
  }

function normalizeSearchItem(raw) {
  if (!raw || typeof raw !== 'object') return null;
  var s = function (v, n) { var x = v == null ? '' : String(v); return n ? x.slice(0, n) : x.slice(0, 200); };
  var item = {};
  ['id', 'mid', 'mediaMid', 'songmid', 'songmid', 'hash', 'fileHash', 'rid',
    'copyrightId', 'songid', 'songId', 'albumId'].forEach(function (k) {
      if (raw[k] != null && raw[k] !== '') item[k] = s(raw[k]);
      });
  // id 兜底：QQ 只有 songmid、酷狗只有 Hash
  if (!item.id) item.id = firstOf(raw, ['songmid', 'Hash', 'hash', 'rid', 'copyrightId', 'mid']);
  if (!item.mid && (raw.songmid || raw.mid)) item.mid = s(raw.songmid || raw.mid);
  if (!item.songmid && (raw.songmid || raw.mid)) item.songmid = s(raw.songmid || raw.mid);

  // ── 歌名：跨平台别名 ──
  item.name = s(firstOf(raw, ['name', 'songname', 'SongName', 'songName', 'title', 'song']));

  // ── 歌手 ──
  //    🔴 只接受「字符串」artist：网易的 ar 是**数组**，若用 firstOf 泛匹配
  //    会把数组选中，再 String() 就变成 "[object Object]"。
  var artists = [];
  var artistArr = firstOf(raw, ['artists', 'singer', 'singers', 'ar']);
  if (Array.isArray(artistArr)) {
    artists = artistArr.slice(0, 10).map(function (a) {
      if (typeof a === 'string') return { id: '', mid: '', name: a.trim() };
      return {
        id: s(a && a.id),
        mid: s(a && (a.mid || a.mediaMid)),
        name: s(a && (a.name || a.singername || a.SingerName))
      };
    }).filter(function (a) { return !!a.name; });
  }
  var artistText = '';
  ['artist', 'SingerName', 'singername', 'artistname', 'artistName'].forEach(function (k) {
    if (artistText) return;
    var v = raw[k];
    if (typeof v === 'string' && v.trim()) artistText = v.trim();
  });
  if (!artistText && artists.length) {
    var names = artists.map(function (a) { return a.name; });
    artistText = names.length === 1 ? names[0] : names.join('、');
  }
  item.artist = artistText.slice(0, 200);
  if (artists.length) item.artists = artists;

  // 网易把专辑放在 al 对象里（al.name / al.picUrl），必须先取出来
  var al = raw.al || raw.album || null;
  if (al && typeof al !== 'object') al = null;

  // ── 专辑：平铺字段 + 嵌套 al 对象 ──
  var albumText = s(firstOf(raw, ['album', 'albumName', 'albumname', 'AlbumName', 'album_name']));
  if (!albumText && al) albumText = s(firstOf(al, ['name', 'album', 'albumName']));
  item.album = albumText;

  // ── 封面 ──
  var pic = firstOf(raw, ['albumPic', 'pic', 'picUrl', 'ImageUrl', 'imgurl', 'cover', 'pic_url']);
  if (!pic && al) pic = firstOf(al, ['picUrl', 'pic', 'imgurl', 'ImageUrl']);
  item.albumPic = typeof pic === 'string' ? pic.slice(0, 2048) : '';
  item.pic = item.albumPic;

  // ── 时长：跨平台别名 + 毫秒/秒归一 ──
  //    网易用 dt、QQ 用 interval、酷狗用 Duration、酷我用 timelength。
  //    🔴 数字 0 是**合法值**（未知时长），不能被 firstOf 当成"没这个字段"
  //    而跳过 —— 所以这里对数值字段单独判断 typeof === 'number'。
  var dur = NaN;
  ['duration', 'interval', 'Duration', 'timelength', 'dt'].forEach(function (k) {
    if (isFinite(dur)) return;
    var v = raw[k];
    if (typeof v === 'number' && isFinite(v)) dur = v;
    else if (typeof v === 'string' && v !== '' && isFinite(Number(v))) dur = Number(v);
  });
  item.duration = (isFinite(dur) && dur > 0) ? (dur > 1000 ? Math.round(dur / 1000) : Math.round(dur)) : 0;
  return item;
}

/* ── 消息循环 ─────────────────────────────────────────────── */

self.onmessage = function (e) {
  var msg = e && e.data ? e.data : {};
  if (msg.type === 'load') {
    loadScript(msg.script, msg.meta);
  } else if (msg.type === 'request') {
    handleRequest(msg);
  } else if (msg.type === 'destroy') {
    destroy();
  }
};

/**
 * 执行用户脚本。
 * 做法：把脚本源码包进一个 async 函数，用 with 把它伪装成全局作用域，
 * 并在函数内提供 lx / request / axios 等桌面版注入物。
 *
 * ⚠️ 严格模式禁用 with，所以这个包装函数必须是「 sloppy mode」——
 *    new Function 构造的函数体默认就是 sloppy，OK。
 */
function loadScript(scriptText, meta) {
  if (typeof scriptText !== 'string' || !scriptText.trim()) {
    emit({ type: 'fatal', error: '音源脚本为空' });
    return;
  }
  if (scriptText.length > MAX_SCRIPT_BYTES) {
    emit({ type: 'fatal', error: '音源脚本超过 9MB 上限' });
    return;
  }

  /**
   * ★ currentScriptInfo 必须**原样**透传脚本头部的元信息。
   *
   * 新版音源（实测「屿溪 · 云记」）会拿 `lx.currentScriptInfo` 做自校验：
   * 字段缺失或值被改写，就抛「初始化失败！」并把 GLOBAL_API_URL 置空 ——
   * 表现为「线路探测明明 200 OK，音源却初始化失败」。
   * 所以这里用 Object.assign 先铺开 meta 的全部字段（含 @deploy/@group/@link 等
   * 自定义标签），再对标准字段做长度限制。
   */
  SCRIPT_INFO = Object.assign({}, meta || {}, {
    name: String((meta && meta.name) || '').slice(0, 200),
    version: String((meta && meta.version) || '').slice(0, 200),
    author: String((meta && meta.author) || '').slice(0, 200),
    description: String((meta && meta.description) || '').slice(0, 500),
    homepage: String((meta && meta.homepage) || '').slice(0, 1024),
    rawScript: scriptText
  });
  /**
   * ★★ 必须把新对象同步回 lx.currentScriptInfo（2026-10 实测「屿溪 · 云记」，隐蔽至极）。
   *
   * lx 对象是在模块顶部一次性构造的：`currentScriptInfo: SCRIPT_INFO` —— 这是**值拷贝**，
   * 绑的是当时那个初始空对象 {name:'',version:'',…}。
   * 而本函数随后 `SCRIPT_INFO = Object.assign(...)` 只是给**变量**换了新对象，
   * lx.currentScriptInfo 依然指向旧空对象。
   *
   * 后果：音源脚本读 `globalThis.lx.currentScriptInfo.homepage` 永远得到空串，
   * 自校验必然失败 → 抛「初始化失败！」。而日志里打印 SCRIPT_INFO 变量却是**正常值**，
   * 导致排查时一直被误导（这就是这个 bug 藏得深的原因）。
   */
  lx.currentScriptInfo = SCRIPT_INFO;

  // 诊断：把实际喂给脚本的元信息打出来（音源会用 currentScriptInfo 自校验）
  try {
    var infoPreview = {};
    Object.keys(SCRIPT_INFO).forEach(function (k) {
      if (k === 'rawScript') { infoPreview[k] = '[script ' + String(SCRIPT_INFO[k] || '').length + ' bytes]'; return; }
      infoPreview[k] = SCRIPT_INFO[k];
    });
    emit({ type: 'scriptLog', level: 'info', text: '[SCRIPT_INFO] ' + JSON.stringify(infoPreview).slice(0, 900) });
  } catch (e) { }

  // 桌面版额外注入 request(裸) 与 axios(LX 音源常用)，这里补齐
  var bareRequest = function (url, opts, cb) {
    return lxRequest(url, Object.assign({ method: 'GET' }, opts || {}), cb);
  };
  bareRequest.get = function (url) { return lxRequest(url, { method: 'GET' }); };
  bareRequest.post = function (url, body) { return lxRequest(url, { method: 'POST', body: body }); };

  var axios = makeAxios();

  // module.exports 兼容层：脚本可以只 export 函数而不调 lx.on
  var moduleObj = { exports: {} };

  // ★ 修复（2026-10-04）：宿主 WebView 直接把 `fetch` / `atob` / `btoa` 等**原生全局函数
  //   解引用**塞进 sandbox，脚本经 `with(this)` 拿到它们时，调用 receiver 变成了 sandbox 对象。
  //   原生函数要求 receiver 是 WorkerGlobalScope，于是抛：
  //       TypeError: Failed to execute 'fetch' on 'WorkerGlobalScope': Illegal invocation
  //   表现就是「音源脚本明明在桌面上能用，装进 App 后所有取流都失败」。
  //   下面的包装让它们始终以全局为 receiver 调用（箭头函数不绑定自己的 this）。
  function bindNative(fn) {
    if (typeof fn !== 'function') return fn;
    return function () { return fn.apply(self, arguments); };
  }

  var sandbox = {
    lx: lx,
    request: bareRequest,
    axios: axios,
    console: {
      log: makeForwardingConsole('log'),
      warn: makeForwardingConsole('warn'),
      error: makeForwardingConsole('error'),
      info: makeForwardingConsole('info'),
      debug: makeForwardingConsole('debug')
    },
    crypto: lxUtils.crypto,
    Buffer: makeBufferShim(),
    setTimeout: bindNative(setTimeout),
    clearTimeout: bindNative(clearTimeout),
    setInterval: bindNative(setInterval),
    clearInterval: bindNative(clearInterval),
    setImmediate: function (fn) { return setTimeout(fn, 0); },
    clearImmediate: bindNative(clearTimeout),
    queueMicrotask: queueMicrotask,
    Promise: Promise,
    URL: URL,
    URLSearchParams: URLSearchParams,
    TextEncoder: TextEncoder,
    TextDecoder: TextDecoder,
    AbortController: AbortController,
    fetch: bindNative(fetch),
    FormData: typeof FormData !== 'undefined' ? FormData : undefined,
    JSON: JSON,
    Math: Math,
    Date: Date,
    atob: bindNative(atob),
    btoa: bindNative(btoa),
    module: moduleObj,
    exports: moduleObj.exports
  };

  /**
   * ★ 兼容「用 globalThis.lx 取协议」的新版音源（2026-10 实测「屿溪 · 云记」）。
   *
   * 该脚本开头就是：
   *     const { EVENT_NAMES, request, on, send } = globalThis['lx']
   *     ... const V = globalThis['lx'][<动态属性>]
   * 而原来只把 lx 通过 with(this) 注入**局部作用域**，没挂到 globalThis，
   * 于是脚本一执行就抛：
   *     TypeError: Cannot destructure property 'EVENT_NAMES' of 'globalThis.lx' as it is undefined
   * 脚本直接没跑起来，lx.send('inited') 永远不来 → 插件报「初始化失败」，表现为
   * 「桌面版能用的音源，装进 App 就用不了」。
   *
   * Worker 里 self === globalThis，所以挂到 self 即可。
   */
  try {
    self.lx = lx;
    self.request = bareRequest;
    self.axios = axios;
    self.module = moduleObj;
    self.exports = moduleObj.exports;
  } catch (e) { }

  try {
    var keys = Object.keys(sandbox);
    var factory = new Function(
      keys.join(','),
      'with (this) { ' + scriptText + '\n; return typeof install === "function" ? install : null; }'
    );
    var exported = factory.apply(sandbox, keys.map(function (k) { return sandbox[k]; }));
    // 若脚本既没调 lx.on('request') 也没返回 install，尝试 module.exports 适配
    if (typeof requestHandler !== 'function') {
      adaptModuleExports(moduleObj.exports);
    }
    // inited 握手超时兜底：脚本可能没调 lx.send('inited')
    setTimeout(function () {
      if (!INITED) emit({ type: 'initTimeout', error: '脚本未在 20s 内调用 lx.send("inited", {...})' });
    }, 20000);
  } catch (e) {
    emit({ type: 'fatal', error: '脚本执行失败：' + String(e && e.message ? e.message : e) });
  }
}

/**
 * module.exports 兼容（桌面版 bridgeModuleExports 同构）。
 * 支持：函数 / {request} / {handler} / {search} / {getMusicInfo} / {getPic} / {getLyric}
 */
function adaptModuleExports(m) {
  if (!m) return;
  var handler = null;
  if (typeof m === 'function') handler = m;
  else if (typeof m.request === 'function') handler = m.request;
  else if (typeof m.handler === 'function') handler = m.handler;
  else if (typeof m.search === 'function' || typeof m.getMusicInfo === 'function') {
    handler = function (data) {
      var action = data && data.action;
      var info = data && data.info ? data.info : {};
      var musicInfo = info.musicInfo || info;
      var songId = pickSongId(musicInfo);
      if (action === 'search') {
        var kw = info.keyword || '';
        return Promise.resolve(m.search(kw, info.page || 1, info.type || 0))
          .then(function (r) { return { isEnd: !!(r && r.isEnd), data: (r && r.data) || (Array.isArray(r) ? r : []) }; });
      }
      if (action === 'musicUrl') {
        return Promise.resolve(m.getMusicInfo(songId, info.type, musicInfo)).then(function (r) {
          return (r && (r.url || r.playUrl)) || r;
        });
      }
      if (action === 'pic') return Promise.resolve(m.getPic(songId));
      if (action === 'lyric') return Promise.resolve(m.getLyric(songId));
      throw new Error('module.exports 模式不支持动作: ' + action);
    };
  }
  if (handler) requestHandler = handler;
}

function pickSongId(musicInfo) {
  var info = musicInfo || {};
  var keys = ['songmid', 'hash', 'id', 'songId', 'mid', 'fileHash'];
  for (var i = 0; i < keys.length; i++) {
    if (info[keys[i]] != null && info[keys[i]] !== '') return info[keys[i]];
  }
  return '';
}

/* ── axios 迷你实现 ──────────────────────────────────────── */

function makeAxios() {
  function req(cfg) {
    cfg = cfg || {};
    var url = cfg.url;
    if (cfg.params && typeof cfg.params === 'object') {
      var qs = encodeForm(cfg.params);
      if (qs) url += (String(url).indexOf('?') >= 0 ? '&' : '?') + qs;
    }
    var body = cfg.body != null ? cfg.body : cfg.data;
    return lxRequest(url, {
      method: cfg.method || 'GET',
      headers: cfg.headers,
      body: body,
      timeout: cfg.timeout
    }).then(function (r) {
      return {
        data: r.body,
        status: r.statusCode,
        statusText: r.statusMessage,
        headers: r.headers,
        config: cfg,
        request: null
      };
    });
  }
  req.request = req;
  req.get = function (url, cfg) { return req(Object.assign({ url: url, method: 'GET' }, cfg || {})); };
  req.delete = function (url, cfg) { return req(Object.assign({ url: url, method: 'DELETE' }, cfg || {})); };
  req.head = function (url, cfg) { return req(Object.assign({ url: url, method: 'HEAD' }, cfg || {})); };
  req.post = function (url, body, cfg) { return req(Object.assign({ url: url, method: 'POST', body: body }, cfg || {})); };
  req.put = function (url, body, cfg) { return req(Object.assign({ url: url, method: 'PUT', body: body }, cfg || {})); };
  req.patch = function (url, body, cfg) { return req(Object.assign({ url: url, method: 'PATCH', body: body }, cfg || {})); };
  return req;
}

/* ── Buffer 垫片（LX 音源脚本常用 .toString('base64')）────── */

function makeBufferShim() {
  function B(data) {
    if (!(this instanceof B)) return new B(data);
    this._buf = data instanceof Uint8Array ? data : TEXT_ENCODER.encode(String(data == null ? '' : data));
  }
  B.from = function (v, enc) {
    if (v instanceof B) return v;
    if (v instanceof Uint8Array) return new B(v);
    if (v instanceof ArrayBuffer) return new B(new Uint8Array(v));
    if (enc === 'base64') return new B(base64ToBuf(String(v || '')));
    if (enc === 'hex') return new B(hexToBuf(String(v || '')));
    return new B(TEXT_ENCODER.encode(String(v == null ? '' : v)));
  };
  B.isBuffer = function (v) { return v instanceof B; };
  B.alloc = function (n, fill) {
    var arr = new Uint8Array(n);
    if (fill != null) arr.fill(typeof fill === 'number' ? fill : TEXT_ENCODER.encode(String(fill))[0]);
    return new B(arr);
  };
  B.concat = function (list) {
    var total = 0;
    list.forEach(function (b) { total += b._buf ? b._buf.length : b.length; });
    var out = new Uint8Array(total);
    var off = 0;
    list.forEach(function (b) {
      var bytes = b._buf || b;
      out.set(bytes, off);
      off += bytes.length;
    });
    return new B(out);
  };
  B.prototype.toString = function (enc) {
    if (enc === 'base64') return bufToBase64(this._buf);
    if (enc === 'hex') return bufToHex(this._buf);
    return new TextDecoder().decode(this._buf);
  };
  B.prototype.length = 0;   // 被 toString 覆盖为方法，length 走 _buf.length
  Object.defineProperty(B.prototype, 'length', { get: function () { return this._buf.length; } });
  return B;
}

/* ── 清理 ─────────────────────────────────────────────────── */

function destroy() {
  Object.keys(TIMERS).forEach(function (k) { try { clearTimeout(TIMERS[k]); } catch (e) { } });
  Object.keys(PENDING_REQUESTS).forEach(function (k) { try { clearTimeout(PENDING_REQUESTS[k]); } catch (e) { } });
  TIMERS = {};
  PENDING_REQUESTS = {};
  requestHandler = null;
  try { self.close(); } catch (e) { }
}