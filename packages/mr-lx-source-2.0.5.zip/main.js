/* ============================================================
 *  自定义音源（LX）· 音源管理版 · 插件装配入口
 *  ------------------------------------------------------------
 *  职责：按依赖顺序把部件装起来。
 *
 *    1. lx-runtime.js   —— 宿主侧管理器（Worker 生命周期 / 协议 / 缓存）
 *    2. 面板 HTML/CSS   —— 用户界面（需在运行时之前，否则 render 找不到节点）
 *    3. integration.js  —— 宿主接入点（播放接管 / 搜索并入 / 试听补完整）
 *
 *  面板形态对齐电脑版「音源管理」：状态条 + 已添加的源列表 +
 *  本地/在线导入 + 删除确认 + 检查更新（在线源）。不含内置音源、不含音源测试。
 *
 *  面板的 DOM 查找全部延迟到 initPanel()，并带轮询兜底 ——
 *  插件可能比宿主主界面先加载完成，那时 #fx-panel 还不存在。
 * ============================================================ */

var PLUGIN_ID = 'mr-lx-source';

function W() { return typeof window !== 'undefined' ? window : null; }

function resURL(rel) {
  return '/api/plugins/' + encodeURIComponent(PLUGIN_ID) + '/resource?path=' + encodeURIComponent(rel);
}
function loadResScript(rel) { return api.resource.loadScript(resURL(rel)); }

function log() {
  try {
    var a = Array.prototype.slice.call(arguments);
    a.unshift('%c[LX音源]', 'color:#7ec8d8;font-weight:bold');
    console.log.apply(console, a);
  } catch (e) { }
}
function warn() {
  try {
    var a = Array.prototype.slice.call(arguments);
    a.unshift('%c[LX音源]', 'color:#ffb300;font-weight:bold');
    console.warn.apply(console, a);
  } catch (e) { }
}
function err() {
  try {
    var a = Array.prototype.slice.call(arguments);
    a.unshift('%c[LX音源]', 'color:#ef5350;font-weight:bold');
    console.error.apply(console, a);
  } catch (e) { }
}

var LXS = {
  panelMounted: false,
  panelHost: null,
  clickHooked: false,
  styleEl: null,
  panelNodes: [],
  uninstallers: []
};

/* ── 1. 载入运行时 ───────────────────────────────────────── */

function loadRuntime() {
  if (typeof W().MrLxSource === 'object') {
    log('运行时已存在，复用');
    return Promise.resolve();
  }
  return loadResScript('lx-runtime.js').then(function () {
    if (typeof W().MrLxSource !== 'object') throw new Error('lx-runtime.js 未定义 MrLxSource');
    // 把 worker 源码的取件地址告诉运行时
    W().MrLxSource._setWorkerUrl(resURL('lx-worker.js'));
    log('运行时已载入');
  });
}

/* ── 2. 面板 ─────────────────────────────────────────────── */

function injectCSS() {
  if (document.getElementById('mr-lx-source-style')) return;
  return api.net.get(resURL('panel.css')).then(function (css) {
    if (!css || !css.trim()) return;
    var el = document.createElement('style');
    el.id = 'mr-lx-source-style';
    el.textContent = css;
    (document.head || document.documentElement).appendChild(el);
    LXS.styleEl = el;
  }).catch(function (e) { warn('样式载入失败', e); });
}

/**
 * 面板落位：注册成视觉控制台的独立 Tab，位置在「歌词」之后。
 *
 * 宿主的 setFxPanelTab 有硬编码白名单 { home, interface, lyrics, motion, shelf, system }，
 * 不在名单里的 key 一律落到 'home'；而且它按 [data-fx-tab] 选择器把「所有」同值按钮
 * 一起点亮。所以：
 *   · 这里不再给我们的按钮设 data-fx-tab（原先借用宿主的 system，会导致
 *     用户切到宿主「系统」页时本插件的「音源」也跟着亮 —— 2026-10 已修）；
 *   · 自己建按钮 + 页容器，点击时拦截，阻止宿主切页、显示我们自己的页；
 *   · 高亮由 showOurPage() / syncOff() 自行维护。
 */
var TAB_KEY = 'mrLxSource';
var TAB_LABEL = '音源';

function registerConsoleTab() {
  return true;
}

function showOurPage() {
  if (!document.getElementById('fx-console-tab-' + TAB_KEY)) {
    LXS.clickHooked = false;
    ensureTabShell();
  }
  var panel = document.getElementById('fx-panel');
  var ourPage = document.getElementById('fx-console-page-' + TAB_KEY);
  if (!panel || !ourPage) return;

  Array.prototype.slice.call(panel.querySelectorAll('.fx-tab-page')).forEach(function (p) {
    if (p !== ourPage) {
      p.classList.remove('active');
      p.setAttribute('aria-hidden', 'true');
    }
  });
  ourPage.classList.add('active');
  ourPage.setAttribute('aria-hidden', 'false');
  try { panel.setAttribute('data-active-tab', TAB_KEY); } catch (e) { }

  // ★ 熄灭宿主的所有页签（它们仍带 data-fx-tab，由宿主自己维护）
  Array.prototype.slice.call(panel.querySelectorAll('#fx-panel-tabs [data-fx-tab]')).forEach(function (b) {
    b.classList.remove('active');
    b.setAttribute('aria-selected', 'false');
    b.setAttribute('tabindex', '-1');
  });
  // ★ 我们这颗按钮不带 data-fx-tab，宿主不会碰它，必须自己点亮（2026-10）
  var ourBtn = document.getElementById('fx-console-tab-' + TAB_KEY);
  if (ourBtn) {
    ourBtn.classList.add('active');
    ourBtn.setAttribute('aria-selected', 'true');
    ourBtn.setAttribute('tabindex', '0');
    try { ourBtn.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (e1) { }
  }

  try { if (typeof W().repositionFxFloatingPanels === 'function') W().repositionFxFloatingPanels(); } catch (e2) { }
  renderPanel();
}

function ensureTabShell() {
  var bar = document.getElementById('fx-panel-tabs');
  if (!bar) return null;

  var pageId = 'fx-console-page-' + TAB_KEY;
  var page = document.getElementById(pageId);
  if (!page) {
    var ref = document.getElementById('fx-console-page-lyrics');
    page = document.createElement('div');
    page.id = pageId;
    page.className = (ref && ref.className) ? ref.className : 'fx-tab-page';
    page.setAttribute('data-fx-page', TAB_KEY);
    page.setAttribute('role', 'tabpanel');
    page.setAttribute('aria-labelledby', 'fx-console-tab-' + TAB_KEY);
    page.setAttribute('aria-hidden', 'true');
    if (ref && ref.parentNode) ref.parentNode.insertBefore(page, ref.nextSibling);
    else bar.parentNode.appendChild(page);
  }

  if (!document.getElementById('fx-console-tab-' + TAB_KEY)) {
    var lyricsBtn = document.getElementById('fx-console-tab-lyrics');
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'fx-console-tab-' + TAB_KEY;
    btn.setAttribute('role', 'tab');
    /**
     * ★ 2026-10 修复「切到宿主『系统』页时本插件的『音源』也跟着亮」：
     *   宿主 setFxPanelTab 会把**所有** [data-fx-tab="<当前页>"] 的按钮一起点亮，
     *   而这里原先借用宿主的 system 作为 data-fx-tab（因为宿主白名单不含 mrLxSource），
     *   于是两颗按钮同时高亮。
     *   现在**不设 data-fx-tab**：宿主的选择器完全匹配不到这颗按钮，
     *   高亮改由我们的 showOurPage() / syncOff() 自己管。
     *   代价仅为：宿主的左右方向键切换页签会跳过本按钮（可接受）。
     */
    btn.setAttribute('data-mr-tab', TAB_KEY);
    btn.setAttribute('aria-controls', pageId);
    btn.setAttribute('aria-selected', 'false');
    btn.setAttribute('tabindex', '-1');
    btn.textContent = TAB_LABEL;
    if (lyricsBtn && lyricsBtn.className) btn.className = lyricsBtn.className;
    if (lyricsBtn && lyricsBtn.parentNode) lyricsBtn.parentNode.insertBefore(btn, lyricsBtn.nextSibling);
    else bar.appendChild(btn);
  }

  if (!LXS.clickHooked) {
    LXS.clickHooked = true;
    var btnEl = document.getElementById('fx-console-tab-' + TAB_KEY);
    if (btnEl) {
      btnEl.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        showOurPage();
      });
    }

    var panelEl = document.getElementById('fx-panel');
    if (panelEl && !panelEl._mrLxObserved) {
      panelEl._mrLxObserved = true;
      var syncOff = function () {
        var ourPage = document.getElementById('fx-console-page-' + TAB_KEY);
        var ourBtn = document.getElementById('fx-console-tab-' + TAB_KEY);
        var activeTab = panelEl.getAttribute('data-active-tab');
        if (!activeTab || activeTab === TAB_KEY) return;
        if (ourPage && ourPage.classList.contains('active')) {
          ourPage.classList.remove('active');
          ourPage.setAttribute('aria-hidden', 'true');
        }
        /**
         * ★ 宿主接管页签后，我们这颗按钮要一起灭掉（2026-10）。
         *   它不带 data-fx-tab，宿主的高亮逻辑碰不到它，
         *   不在这里清就会出现「从『音源』切回『系统』后音源一直亮着」。
         */
        if (ourBtn && ourBtn.classList.contains('active')) {
          ourBtn.classList.remove('active');
          ourBtn.setAttribute('aria-selected', 'false');
          ourBtn.setAttribute('tabindex', '-1');
        }
      };
      if (typeof MutationObserver !== 'undefined') {
        var mo = new MutationObserver(syncOff);
        mo.observe(panelEl, { attributes: true, attributeFilter: ['data-active-tab'] });
        LXS.observer = mo || null;
      }
      panelEl.addEventListener('click', function () { setTimeout(syncOff, 0); });
    }
  }

  return page;
}

function waitForTabPage(cb) {
  var page = ensureTabShell();
  if (page) { cb(page); return; }

  var tries = 0;
  (function attempt() {
    var p = document.getElementById('fx-console-page-' + TAB_KEY);
    if (p) { cb(p); return; }
    tries++;
    if (tries > 40) {
      warn('Tab 页容器始终无法建立，面板退回挂到 #fx-panel 末尾');
      var fallback = document.getElementById('fx-panel');
      if (fallback) cb(fallback);
      return;
    }
    api.timer.setTimeout(attempt, 300);
  })();
}

function injectPanel() {
  if (LXS.panelMounted) return Promise.resolve();
  if (!registerConsoleTab()) warn('宿主控制台数据结构不可用，面板将挂到面板末尾');

  return api.net.get(resURL('panel.html')).then(function (html) {
    if (!html || !html.trim()) return;
    var wrap = document.createElement('div');
    wrap.innerHTML = html;
    var nodes = Array.prototype.slice.call(wrap.children);
    if (!nodes.length) return;

    // 弹窗节点挂到 body（否则在 tab page 里可能被裁剪/遮挡），面板节点挂 tab page
    var modals = nodes.filter(function (n) { return n.classList && n.classList.contains('mr-lx-modal-mask'); });
    var panelNodes = nodes.filter(function (n) { return !(n.classList && n.classList.contains('mr-lx-modal-mask')); });
    modals.forEach(function (m) {
      if (m && m.id && !document.getElementById(m.id)) document.body.appendChild(m);
    });

    return new Promise(function (resolve) {
      waitForTabPage(function (host) {
        ensureTabShell();
        for (var k = 0; k < panelNodes.length; k++) host.appendChild(panelNodes[k]);
        LXS.panelNodes = panelNodes;
        LXS.panelHost = host;
        LXS.panelMounted = true;
        log('面板已挂入控制台「' + TAB_LABEL + '」页');
        bindPanel();
        resolve();
      });
    });
  }).catch(function (e) { warn('面板载入失败', e); });
}

/* ── 3. 接入层 ───────────────────────────────────────────── */

function loadIntegration() {
  return loadResScript('integration.js').then(function () {
    var integ = W().__mrLxSourceIntegration;
    if (!integ || typeof integ.install !== 'function') throw new Error('integration.js 未导出安装函数');
    integ.install();
    log('宿主接入点已安装');
  });
}

/* ── 面板逻辑（对齐电脑版「音源管理」） ────────────────────── */

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

function panel() { return document.getElementById('mr-lx-source-panel'); }

function formatSourceSize(bytes) {
  bytes = Number(bytes) || 0;
  if (!bytes) return '';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

/* 平台短码 → 胶囊标签（对齐电脑版 fxSourceTag） */
var FX_TAG_PLATFORM_MAP = { KW: 'kw', KG: 'kg', TX: 'qq', QQ: 'qq', WY: 'wy', NE: 'wy', AM: 'am', QS: 'qs', SP: 'sp', MG: 'mg', KUWO: 'kw', MIGU: 'mg', APPLE: 'am', NETEASE: 'wy' };
var FX_TAG_LABEL_MAP = { WY: 'NE', NE: 'NE', NETEASE: 'NE', QQ: 'QQ', TX: 'QQ', KG: 'KG', QS: 'QS', SP: 'SP', KW: 'KW', KUWO: 'KW', MG: 'MG', MIGU: 'MG', AM: 'AM', APPLE: 'AM' };
function fxSourceTag(name) {
  var up = String(name || '').toUpperCase();
  var key = FX_TAG_PLATFORM_MAP[up] || '';
  var label = FX_TAG_LABEL_MAP[up] || FX_TAG_LABEL_MAP[key] || name;
  var el = document.createElement('span');
  el.className = 'fx-source-tag' + (key ? ' fx-source-tag-' + key : '');
  el.textContent = label;
  return el;
}

function renderPanel() {
  var p = panel();
  if (!p) return;
  var A = W().MrLxSource;
  if (!A) return;

  /* 状态 */
  var dot = document.getElementById('mr-lx-dot');
  var txt = document.getElementById('mr-lx-status-text');
  var ready = A.isReady();
  if (dot) dot.className = 'mr-lx-dot' + (ready ? ' on' : (A.initError() ? ' err' : ''));
  if (txt) {
    if (ready) {
      var src = A.findSource(A.activeId());
      var caps = A.caps() || {};
      var labels = Object.keys(caps).map(function (c) { return (A.LX_CODE_LABEL && A.LX_CODE_LABEL[c]) || c; });
      txt.textContent = '已启用' + (src ? ' · ' + (src.name || src.id) : '') + (labels.length ? ' · 覆盖 ' + labels.join(' / ') : '');
    } else if (A.initError()) {
      txt.textContent = '初始化失败：' + A.initError();
    } else {
      txt.textContent = '未启用（没有已激活的音源）';
    }
  }

  /* 已添加的源 */
  renderSourceList(document.getElementById('mr-lx-list'));
}

function renderSourceList(list) {
  if (!list) return;
  var A = W().MrLxSource;
  if (!A) return;
  list.innerHTML = '';
  var sources = A.sources() || [];
  var activeId = A.activeId() || '';
  var caps = A.caps() || {};
  if (!sources.length) {
    list.innerHTML = '<div class="mr-lx-empty">尚未导入任何 JS 音源，点击下方「本地导入」或「在线导入」。</div>';
    return;
  }
  sources.forEach(function (s) { list.appendChild(renderSourceRow(s, s.id === activeId, caps)); });
}

function makeMiniBtn(label, cls, onClick) {
  var b = document.createElement('button');
  b.type = 'button';
  b.className = 'mr-lx-btn mr-lx-btn-mini ' + (cls || 'mr-lx-btn-ghost');
  b.textContent = label;
  b.addEventListener('click', onClick);
  return b;
}

function renderSourceRow(source, active, caps) {
  var r = document.createElement('div');
  r.className = 'fx-source-row' + (active ? ' active' : '');
  r.setAttribute('data-source-id', source.id);

  var nameLine = document.createElement('div');
  nameLine.className = 'fx-source-name-line';
  var title = document.createElement('span');
  title.className = 'fx-source-name-title';
  title.textContent = source.name || '未命名音源';
  nameLine.appendChild(title);
  if (active) {
    var pill = document.createElement('span');
    pill.className = 'fx-source-pill active';
    pill.textContent = '使用中';
    nameLine.appendChild(pill);
  }
  r.appendChild(nameLine);

  var metaLine = document.createElement('div');
  metaLine.className = 'fx-source-meta-line';
  var v = document.createElement('span');
  v.className = 'fx-source-version';
  v.textContent = 'v' + (source.version || '?');
  metaLine.appendChild(v);
  if (source.author) {
    var a = document.createElement('span');
    a.className = 'fx-source-author';
    a.textContent = source.author;
    metaLine.appendChild(a);
  }
  if (source.scriptSize) {
    var sz = document.createElement('span');
    sz.className = 'fx-source-size';
    sz.textContent = formatSourceSize(source.scriptSize);
    metaLine.appendChild(sz);
  }

  /* 操作按钮：启用/停用 + 检查更新（在线源）+ 删除 */
  var actions = document.createElement('span');
  actions.className = 'mr-lx-row-actions';
  actions.appendChild(makeMiniBtn(active ? '停用' : '启用', active ? '' : 'mr-lx-btn-primary', function () {
    if (active) mrLxDeactivate(); else mrLxActivate(source.id);
  }));
  if (source.importUrl) {
    actions.appendChild(makeMiniBtn('检查更新', 'mr-lx-btn-ghost', function () { checkUpdate(source); }));
  }
  actions.appendChild(makeMiniBtn('删除', 'mr-lx-btn-ghost mr-lx-btn-danger', function () { showDeleteConfirm(source); }));
  metaLine.appendChild(actions);
  r.appendChild(metaLine);

  if (source.description) {
    var d = document.createElement('div');
    d.className = 'fx-source-description';
    d.textContent = source.description;
    r.appendChild(d);
  }

  if (active && caps) {
    var capKeys = Object.keys(caps).filter(function (k) { return k !== 'local'; });
    if (capKeys.length) {
      var capsLine = document.createElement('div');
      capsLine.className = 'fx-source-caps-line';
      var lab = document.createElement('span');
      lab.className = 'fx-source-caps-label';
      lab.textContent = '声明平台';
      capsLine.appendChild(lab);
      capKeys.forEach(function (code) { capsLine.appendChild(fxSourceTag(code)); });
      // 声明了 qs 就自然多出一个 QS 胶囊 —— 不再附加任何文字说明（用户要求）。
      r.appendChild(capsLine);
    }
  }

  return r;
}

/* ── 全局动作 ─────────────────────────────────────────────── */

W().mrLxActivate = function (id) {
  var A = W().MrLxSource;
  if (!A) return;
  A.activate(id).then(function () {
    log('已切换音源');
  }).catch(function (e) {
    var msg = '激活失败：' + (e && e.message ? e.message : e);
    err(msg);
    toast(msg);
  }).then(renderPanel);
};

W().mrLxDeactivate = function () {
  var A = W().MrLxSource;
  if (!A) return;
  A.deactivate();
  renderPanel();
};

/* ── 导入 ─────────────────────────────────────────────────── */

/**
 * 通过宿主的 /api/proxy 端点跨域下载文本（绕过浏览器 CORS，与电脑版走 Node 下载等价）。
 * 端点由 Kotlin 层（127.0.0.1:8800）提供，返回 { status, body, headers } JSON。
 * 返回 Promise<string>（上游正文），失败 reject。
 */
function proxyFetchText(url) {
  var proxyUrl = '/api/proxy?url=' + encodeURIComponent(url) + '&method=GET';
  return fetch(proxyUrl, { method: 'GET' }).then(function (r) {
    if (!r.ok) throw new Error('代理请求失败 HTTP ' + r.status);
    return r.json();
  }).then(function (data) {
    if (!data || data.status == null) throw new Error((data && data.error) || '代理响应异常');
    if (data.status < 200 || data.status >= 300) throw new Error('上游返回 HTTP ' + data.status);
    if (typeof data.body !== 'string') throw new Error('上游返回内容为空');
    return data.body;
  });
}

function importSourceScript(scriptText, label, importUrl) {
  var A = W().MrLxSource;
  if (!A) return Promise.reject(new Error('运行时未就绪'));
  return A.importScript(scriptText, label, importUrl).then(function (src) {
    log('已导入并启用：' + (src && src.name ? src.name : label));
    renderPanel();
    return src;
  }).catch(function (e) {
    renderPanel();
    throw e;
  });
}

function handleLocalImportFiles(files) {
  files = Array.prototype.slice.call(files || []);
  var jsFiles = files.filter(function (f) {
    return /\.(js|mjs)$/i.test(f.name || '') || /javascript/.test(f.type || '') || !/\.[a-z0-9]{1,8}$/i.test(f.name || '');
  });
  if (!jsFiles.length) {
    toast('请选择 .js / .mjs 音源脚本文件');
    return;
  }
  var pending = jsFiles.length;
  jsFiles.forEach(function (file) {
    var reader = new FileReader();
    reader.onload = function () {
      importSourceScript(String(reader.result || ''), file.name, '').then(function () {
        toast('已导入「' + (file.name || '音源') + '」');
      }).catch(function (e) {
        toast('导入「' + (file.name || '音源') + '」失败：' + (e && e.message ? e.message : e));
      }).then(function () {
        pending--;
      });
    };
    reader.onerror = function () { pending--; toast('读取文件失败：' + (file.name || '')); };
    reader.readAsText(file);
  });
}

/* ── 在线导入弹窗 ─────────────────────────────────────────── */

function showOnlineImportModal() {
  var mask = document.getElementById('mr-lx-online-import-modal');
  if (!mask) return;
  var input = document.getElementById('mr-lx-online-import-url');
  if (input) input.value = '';
  mask.hidden = false;
  setTimeout(function () { if (input) input.focus(); }, 80);
}
function closeOnlineImportModal() {
  var mask = document.getElementById('mr-lx-online-import-modal');
  if (mask) mask.hidden = true;
}
function submitOnlineImport() {
  var input = document.getElementById('mr-lx-online-import-url');
  var url = input ? String(input.value || '').trim() : '';
  var btn = document.getElementById('mr-lx-online-import-submit');
  if (!url) { toast('请先输入 http(s) 链接'); return; }
  if (!/^https?:\/\//i.test(url)) { toast('请输入 http(s) 链接'); return; }
  if (btn) btn.disabled = true;
  // 走宿主 /api/proxy 代理下载，绕过浏览器 CORS —— 任意 http(s) 链接均可（与电脑版一致）。
  proxyFetchText(url).then(function (text) {
    if (!text || !String(text).trim()) throw new Error('脚本内容为空');
    return importSourceScript(String(text), url, url);
  }).then(function () {
    closeOnlineImportModal();
    toast('已在线导入并启用音源');
  }).catch(function (e) {
    var msg = '在线导入失败：' + (e && e.message ? e.message : e);
    toast(msg);
  }).then(function () {
    if (btn) btn.disabled = false;
  });
}

/* ── 删除确认弹窗 ─────────────────────────────────────────── */

var deleteTarget = null;
function showDeleteConfirm(source) {
  deleteTarget = source;
  var body = document.getElementById('mr-lx-delete-confirm-body');
  if (body) body.textContent = '确认删除音源「' + (source.name || source.id) + '」？删除后不可恢复。';
  var mask = document.getElementById('mr-lx-delete-confirm-modal');
  if (mask) mask.hidden = false;
}
function closeDeleteConfirm() {
  deleteTarget = null;
  var mask = document.getElementById('mr-lx-delete-confirm-modal');
  if (mask) mask.hidden = true;
}
function confirmDelete() {
  var source = deleteTarget;
  closeDeleteConfirm();
  if (!source) return;
  var A = W().MrLxSource;
  if (!A) return;
  A.removeSource(source.id);
  toast('已删除音源「' + (source.name || source.id) + '」');
  renderPanel();
}

/* ── 检查更新（在线源） ───────────────────────────────────── */

function checkUpdate(source) {
  if (!source || !source.importUrl) {
    toast('本地导入的音源不支持在线更新检查');
    return;
  }
  toast('正在检查「' + (source.name || source.id) + '」更新…');
  proxyFetchText(source.importUrl).then(function (text) {
    text = String(text || '');
    if (!text.trim()) throw new Error('脚本内容为空');
    var info = W().MrLxSource.parseScriptInfo(text, source.name);
    var remote = String(info.version || '');
    var local = String(source.version || '');
    if (!remote) { toast('无法识别远程版本号'); return; }
    if (remote === local) { toast('「' + (source.name || source.id) + '」当前已是最新版本'); return; }
    // 有更新：用删除确认弹窗复用成通用确认（标题/正文/按钮动态填充）
    showUpdateConfirm(source, local, remote, text);
  }).catch(function (e) {
    toast('检查更新失败：' + (e && e.message ? e.message : e));
  });
}

var updateTarget = null;
function showUpdateConfirm(source, localVer, remoteVer, newScript) {
  updateTarget = { source: source, remoteVer: remoteVer, newScript: newScript };
  var titleEl = document.getElementById('mr-lx-delete-confirm-title');
  var bodyEl = document.getElementById('mr-lx-delete-confirm-body');
  var okEl = document.getElementById('mr-lx-delete-confirm');
  if (titleEl) titleEl.textContent = '发现新版本';
  if (bodyEl) bodyEl.textContent = '「' + (source.name || source.id) + '」当前 v' + localVer + ' → 新 v' + remoteVer + '，是否立即更新？';
  if (okEl) {
    okEl.textContent = '立即更新';
    okEl.classList.remove('danger');
    okEl.classList.add('primary');
  }
  var mask = document.getElementById('mr-lx-delete-confirm-modal');
  if (mask) mask.hidden = false;
}
function resetConfirmModal() {
  var titleEl = document.getElementById('mr-lx-delete-confirm-title');
  var bodyEl = document.getElementById('mr-lx-delete-confirm-body');
  var okEl = document.getElementById('mr-lx-delete-confirm');
  if (titleEl) titleEl.textContent = '确认操作';
  if (bodyEl) bodyEl.textContent = '确认删除音源？删除后不可恢复。';
  if (okEl) {
    okEl.textContent = '确认删除';
    okEl.classList.remove('primary');
    okEl.classList.add('danger');
  }
}
function confirmDeleteOrUpdate() {
  if (updateTarget) {
    var u = updateTarget;
    updateTarget = null;
    closeDeleteConfirm();
    resetConfirmModal();
    var A = W().MrLxSource;
    if (!A) return;
    toast('正在更新…');
    A.updateSource(u.source.id, u.newScript, u.source.importUrl).then(function () {
      toast('已更新「' + (u.source.name || u.source.id) + '」到 v' + u.remoteVer);
      renderPanel();
    }).catch(function (e) {
      toast('更新失败：' + (e && e.message ? e.message : e));
    });
    return;
  }
  confirmDelete();
}

/* ── 事件绑定 ─────────────────────────────────────────────── */

function toast(msg) {
  try { if (typeof W().showToast === 'function') { W().showToast(String(msg)); return; } } catch (e) { }
  try { log(String(msg)); } catch (e) { }
}

function bindPanel() {
  var btnImport = document.getElementById('mr-lx-import-btn');
  var inputImport = document.getElementById('mr-lx-import-input');
  if (btnImport && inputImport) {
    btnImport.addEventListener('click', function () { inputImport.click(); });
    inputImport.addEventListener('change', function () {
      handleLocalImportFiles(inputImport.files);
      inputImport.value = '';
    });
  }

  var btnOnline = document.getElementById('mr-lx-online-import-btn');
  if (btnOnline) btnOnline.addEventListener('click', showOnlineImportModal);
  var onlineSubmit = document.getElementById('mr-lx-online-import-submit');
  if (onlineSubmit) onlineSubmit.addEventListener('click', submitOnlineImport);
  var onlineClose = document.getElementById('mr-lx-online-import-close');
  if (onlineClose) onlineClose.addEventListener('click', closeOnlineImportModal);
  var onlineUrl = document.getElementById('mr-lx-online-import-url');
  if (onlineUrl) {
    onlineUrl.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.keyCode === 13) { e.preventDefault(); submitOnlineImport(); }
    });
  }
  var onlineMask = document.getElementById('mr-lx-online-import-modal');
  if (onlineMask) onlineMask.addEventListener('click', function (e) { if (e.target === onlineMask) closeOnlineImportModal(); });

  var delCancel = document.getElementById('mr-lx-delete-cancel');
  if (delCancel) delCancel.addEventListener('click', function () { closeDeleteConfirm(); resetConfirmModal(); });
  var delOk = document.getElementById('mr-lx-delete-confirm');
  if (delOk) delOk.addEventListener('click', confirmDeleteOrUpdate);
  var delMask = document.getElementById('mr-lx-delete-confirm-modal');
  if (delMask) delMask.addEventListener('click', function (e) { if (e.target === delMask) { closeDeleteConfirm(); resetConfirmModal(); } });

  // 宿主状态变化时刷新（比如登录/登出）
  try {
    W().addEventListener('lx-source-state', renderPanel);
  } catch (e) { }
}

/* ── 启动装配 ────────────────────────────────────────────── */

function boot() {
  api.ready(function () {
    api.timer.setTimeout(function () {
      log('初始化…');

      injectCSS();
      injectPanel();

      loadRuntime()
        .then(function () { return loadIntegration(); })
        .then(function () {
          renderPanel();
          var A = W().MrLxSource;
          log('音源管理插件就绪（' + (A ? A.count() : 0) + ' 个音源）');
        })
        .catch(function (e) {
          err('装配失败：' + (e && e.stack ? e.stack : e));
          renderPanel();
        });
    }, 0);
  });
}

boot();

/* ── 卸载 ─────────────────────────────────────────────────── */

function uninstall() {
  try {
    var A = W().MrLxSource;
    if (A && A._teardown) A._teardown('uninstall');
  } catch (e) { }
  try {
    var integ = W().__mrLxSourceIntegration;
    if (integ && typeof integ.uninstall === 'function') integ.uninstall();
  } catch (e) { }
  LXS.uninstallers.forEach(function (fn) { try { fn(); } catch (e) { } });
  LXS.uninstallers = [];

  if (LXS.styleEl && LXS.styleEl.parentNode) LXS.styleEl.parentNode.removeChild(LXS.styleEl);
  LXS.styleEl = null;
  var pid = 'mr-lx-source-panel';
  var el = document.getElementById(pid);
  if (el && el.parentNode) el.parentNode.removeChild(el);
  LXS.panelNodes = [];
  LXS.panelMounted = false;
  LXS.panelHost = null;

  ['mr-lx-online-import-modal', 'mr-lx-delete-confirm-modal'].forEach(function (mid) {
    var m = document.getElementById(mid);
    if (m && m.parentNode) m.parentNode.removeChild(m);
  });

  try {
    var pg = document.getElementById('fx-console-page-' + TAB_KEY);
    if (pg && pg.parentNode) pg.parentNode.removeChild(pg);
    var tb = document.getElementById('fx-console-tab-' + TAB_KEY);
    if (tb && tb.parentNode) tb.parentNode.removeChild(tb);
  } catch (e4) { }
  LXS.clickHooked = false;

  ['mrLxActivate', 'mrLxDeactivate'].forEach(function (k) {
    try { delete W()[k]; } catch (e) { try { W()[k] = undefined; } catch (_) { } }
  });
  log('插件已卸载');
}

return function uninstallFn() {
  uninstall();
};
