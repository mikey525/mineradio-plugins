Folia 0.7.19 原作者 chthollyphile，AGPL-3.0-only。本适配层同许可；本次交付目录随附对应源码包（含适配代码、原版源码、资源、依赖锁文件和构建脚本）。第三方许可见 renderer.js.LEGAL.txt。
