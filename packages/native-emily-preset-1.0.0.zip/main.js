/* Mineradio optional native visual preset. Original authors retained in manifest. */
MineradioPlugins.register({"id":"native-emily-preset","name":"emily专辑封面预设","version":"1.0.0","author":"Mineradio","description":"封面粒子 · 快速入场；原内置视觉预设，需配套虚空核心版主程序","license":"GPL-3.0-only"}, function (api) {
  var registry = window.MineradioVisualPresets;
  if (!registry) throw new Error('请安装配套的虚空核心版 Mineradio');
  
  var disposePreset = registry.register({ index: 0, id: "native-emily-preset", meta: {"name":"emily专辑封面","desc":"封面粒子 · 快速入场"}, icon: "<svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"><path d=\"M3 14c3-2 5-2 8 0s5 2 8 0M3 10c3-2 5-2 8 0s5 2 8 0M3 18c3-2 5-2 8 0s5 2 8 0\"/></svg>", vertexShader: "\nprecision highp float;\nuniform float uTime, uBass, uMid, uTreble, uBeat, uEnergy, uBurstAmt;\nuniform float uPreset, uIntensity, uDepth, uPointScale, uSpeed, uTwist;\nuniform float uVinylSpin;\nuniform float uColorBoost, uScatter, uCoverRes, uBgFade;\nuniform float uHasCover, uHasDepth, uEdgeEnabled, uAiBoost;\nuniform float uMouseActive, uPixel, uColorMixT, uLoading;\nuniform sampler2D uCoverTex, uPrevCoverTex, uEdgeTex, uRippleTex;\nuniform int uRippleCount;\nuniform vec2 uMouseXY;\nuniform vec3 uTintColor;\nuniform float uTintStrength;\nattribute vec2 aUv;\nattribute float aRand;\nvarying vec3 vColor;\nvarying float vBright, vRipple, vEdgeBoost, vAlpha, vSourceLum;\n\n#define PI 3.14159265359\n\nvec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;}\nvec4 mod289v(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}\nvec4 perm(vec4 x){return mod289v(((x*34.0)+1.0)*x);}\nfloat snoise(vec3 v){\n  const vec2 C=vec2(1.0/6.0,1.0/3.0);\n  const vec4 D=vec4(0.0,0.5,1.0,2.0);\n  vec3 i=floor(v+dot(v,C.yyy));\n  vec3 x0=v-i+dot(i,C.xxx);\n  vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g;\n  vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);\n  vec3 x1=x0-i1+C.xxx;\n  vec3 x2=x0-i2+C.yyy;\n  vec3 x3=x0-D.yyy;\n  i=mod289(i);\n  vec4 p=perm(perm(perm(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));\n  float n_=0.142857142857;\n  vec3 ns=n_*D.wyz-D.xzx;\n  vec4 j=p-49.0*floor(p*ns.z*ns.z);\n  vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);\n  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy;\n  vec4 h=1.0-abs(x)-abs(y);\n  vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);\n  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0;\n  vec4 sh=-step(h,vec4(0.0));\n  vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;\n  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);\n  vec4 norm=inversesqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3)));\n  p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;\n  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0);\n  m=m*m;\n  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3)));\n}\n\nfloat hash11(float p) {\n  return fract(sin(p * 127.1) * 43758.5453123);\n}\n\nvec2 safeCoverUv(vec2 uv) {\n  return clamp(uv, vec2(0.0012), vec2(0.9988));\n}\n\nvec3 sampleNewCoverColor(vec2 uv) {\n  return texture2D(uCoverTex, safeCoverUv(uv)).rgb;\n}\n\nvec3 samplePrevCoverColor(vec2 uv) {\n  return texture2D(uPrevCoverTex, safeCoverUv(uv)).rgb;\n}\n\nvec4 sampleEdgeColor(vec2 uv) {\n  return texture2D(uEdgeTex, safeCoverUv(uv));\n}\n\nfloat rippleSumAt(vec2 p, out float maxAmp) {\n  float sum = 0.0; maxAmp = 0.0;\n  for (int ri = 0; ri < 12; ri++) {\nif (ri >= uRippleCount) break;\nfloat vCoord = (float(ri) + 0.5) / 12.0;\nvec4 rd = texture2D(uRippleTex, vec2(0.5, vCoord));\nfloat age = rd.z; float str = rd.w;\nif (str < 0.005 || age < 0.0 || age > 2.0) continue;\nfloat dx = p.x - rd.x, dy = p.y - rd.y;\nfloat dist = sqrt(dx*dx + dy*dy);\nfloat lifeN = age / 2.0;\nfloat fadeIn  = smoothstep(0.0, 0.06, age);\nfloat fadeOut = 1.0 - smoothstep(0.7, 1.0, lifeN);\nfloat env = fadeIn * fadeOut;\n// v7.1: 把幅度放大 — 中心凸起更高更宽\nfloat bulgeW = 0.55 + age * 0.80;\nfloat bulge  = exp(-dist*dist / (2.0 * bulgeW * bulgeW)) * (1.0 - smoothstep(0.0, 0.55, lifeN));\nfloat waveR  = age * 2.10;\nfloat ringW  = 0.40 + age * 0.22;\nfloat ring   = exp(-pow((dist - waveR) / ringW, 2.0));\n// v7.1: 提升整体幅度 ×2\nfloat local  = (bulge * 2.4 + ring * 1.30) * env * str;\nsum += local;\nmaxAmp = max(maxAmp, abs(local));\n  }\n  return sum;\n}\n\nvoid main(){\n  float t = uTime * uSpeed;\n  vec3 pos;\n  vec2 sampleUv = safeCoverUv(aUv);\n  // 切歌颜色渐变: 在新旧封面间 mix\n  vec3 newCol = sampleNewCoverColor(sampleUv);\n  vec3 prevCol = samplePrevCoverColor(sampleUv);\n  vec3 coverColor = mix(prevCol, newCol, clamp(uColorMixT, 0.0, 1.0));\n  vec4 edge = sampleEdgeColor(sampleUv);\n  float depthVal = edge.r;\n  float edgeVal  = edge.g;\n  float fgMask   = edge.b;\n  float lumVal   = edge.a;\n  float maxRippleAmp = 0.0;\n  float rippleZ = 0.0;\n\n  vec3 defaultColor = mix(\nvec3(0.36, 0.28, 0.72),\nmix(vec3(0.85, 0.55, 0.95), vec3(0.45, 0.78, 0.95), aUv.x),\naUv.y\n  );\n  vColor = mix(defaultColor, coverColor, uHasCover);\n  vAlpha = 1.0;\n\n  // 律动强度的真实倍数 (放大 intensity 滑块的影响)\n  float K = uIntensity * 1.6;   // 滑块 1.0 → K=1.6, 滑块 1.6 → K=2.56\n\n{\n\npos = position;\nrippleZ = rippleSumAt(pos.xy, maxRippleAmp);\n\nfloat midN = snoise(vec3(pos.x*1.4, pos.y*1.4, t*0.55)) * 0.6\n           + snoise(vec3(pos.x*2.8+5.0, pos.y*2.8-3.0, t*0.85)) * 0.4;\nfloat midMask = 0.55 + 0.45 * snoise(vec3(pos.x*0.4, pos.y*0.4, t*0.18));\nfloat midDisp = midN * uMid * 0.55 * midMask * K;       // 0.20 → 0.55\n\nfloat trebleJ = snoise(vec3(pos.x*6.5, pos.y*6.5, t*3.5 + aRand*4.0)) * uTreble * 0.18 * K;  // 0.06→0.18\nfloat bassBreath = snoise(vec3(pos.x*0.35, pos.y*0.35, t*0.4)) * uBass * 0.42 * K;          // 0.14→0.42\n\n// AI 深度: 显著强化 (0.85 → 1.4)\nfloat depthZ = (depthVal - 0.5) * uAiBoost * uDepth * 1.40 * uHasDepth;\n\npos.z = rippleZ * 1.30 + midDisp + trebleJ + bassBreath + depthZ;\n  \n}\n  // ====================================================\n  //  鼠标交互 (仅 SILK)\n  // ====================================================\n  if (uMouseActive > 0.5 && uPreset < 0.5) {\nfloat mdx = pos.x - uMouseXY.x;\nfloat mdy = pos.y - uMouseXY.y;\nfloat md = sqrt(mdx*mdx + mdy*mdy);\nif (md < 1.0) {\n  float push = (1.0 - md) * (1.0 - md);\n  pos.z += push * 0.55;\n}\n  }\n\n  // ====================================================\n  //  通用: 离散感 / 扭曲\n  // ====================================================\n  if (uScatter > 0.001) {\nvec2 jdir = vec2(cos(aRand * 6.2831), sin(aRand * 6.2831));\npos.xy += jdir * uScatter * (0.05 + uTreble * 0.10);\n  }\n  if (uTwist > 0.001 && uPreset < 0.5) {\nfloat ta = uTwist * pos.z * 0.6;\nfloat cs = cos(ta), sn = sin(ta);\npos.xy = mat2(cs, -sn, sn, cs) * pos.xy;\n  }\n\n  // 颜色\n  float vinylHiResGuard = smoothstep(1.08, 1.55, uCoverRes) * step(3.5, uPreset) * (1.0 - step(4.5, uPreset));\n  float edgeBoost = uEdgeEnabled * edgeVal * mix(1.0, 0.42, vinylHiResGuard);\n  vSourceLum = dot(max(vColor, vec3(0.0)), vec3(0.299, 0.587, 0.114));\n  float blackParticleGuard = 1.0 - smoothstep(0.025, 0.115, vSourceLum);\n  vEdgeBoost = edgeBoost * (uPreset > 3.5 ? 0.22 : 1.0) * (1.0 - blackParticleGuard);\n  vColor = pow(max(vColor, vec3(0.0)), vec3(1.0 / max(0.35, uColorBoost)));\n  float edgeColorMix = edgeBoost * (uPreset > 3.5 ? 0.20 : 0.50) * (1.0 - blackParticleGuard);\n  vColor = mix(vColor, vColor + vec3(0.20), edgeColorMix);\n  float tintLum = max(max(vColor.r, vColor.g), vColor.b);\n  vec3 tintedColor = uTintColor * max(0.24, tintLum * 1.12);\n  vColor = mix(vColor, tintedColor, clamp(uTintStrength, 0.0, 1.0) * (1.0 - blackParticleGuard));\n\n  vBright = 0.82 + maxRippleAmp * 0.55 + uBass * 0.10 + edgeBoost * 0.30 + uEnergy * 0.05 + uBurstAmt * 0.40;\n  if (uPreset > 4.5) {\nvBright = 0.94 + maxRippleAmp * 0.34 + uBass * 0.020 + uEnergy * 0.026 + uBurstAmt * 0.025;\n  } else if (uPreset > 3.5) {\nvBright = 0.94 + maxRippleAmp * 0.64 + uBass * 0.08 + edgeBoost * 0.12 + uEnergy * 0.05 + uBeat * 0.16 + uBurstAmt * 0.16;\n  }\n  vRipple = clamp(maxRippleAmp * 1.5, 0.0, 1.0);\n\n  if (uHasDepth > 0.5 && uPreset < 0.5) {\nfloat bgMul = mix(1.0, 0.55, uBgFade * (1.0 - fgMask));\nvBright *= bgMul;\n  }\n  float loadingMistSize = 1.0;\n\n  // 加载形态: 雾状微尘流，避免廉价旋转圆环\n  if (uLoading > 0.001) {\nfloat mistSeed = hash11(aRand * 931.7);\nfloat mistLayer = floor(mistSeed * 4.0);\nfloat layerN = (mistLayer + 0.5) / 4.0;\nfloat mistAngle = aRand * 6.2831 + uTime * (0.16 + mistSeed * 0.18) + snoise(vec3(aRand * 2.1, uTime * 0.24, 2.0)) * 1.85;\nfloat mistR = mix(1.35, 3.15, sqrt(hash11(aRand * 127.3))) * (1.0 + sin(uTime * 0.42 + aRand * 7.0) * 0.13);\nvec2 mistCurl = vec2(\n  snoise(vec3(aRand * 4.1, uTime * 0.32, 3.0)),\n  snoise(vec3(aRand * 4.7, uTime * 0.30, 8.0))\n);\nfloat mistBreath = 0.5 + 0.5 * sin(uTime * (0.82 + mistSeed * 0.55) + aRand * 17.0);\nfloat mistRibbon = sin(mistAngle * (1.35 + layerN * 0.55) + uTime * 0.34 + mistSeed * 4.0);\nfloat glowPick = smoothstep(0.88, 0.997, hash11(aRand * 1501.0 + mistLayer * 17.0));\nfloat dustPick = 0.34 + glowPick * 0.66;\nvec3 mistPos = vec3(\n  cos(mistAngle) * mistR * (1.24 + mistCurl.x * 0.16) + mistCurl.x * 0.72,\n  sin(mistAngle * 0.82 + mistRibbon * 0.25) * mistR * (0.56 + layerN * 0.10) + mistCurl.y * 0.62,\n  (layerN - 0.5) * 4.85 + mistCurl.x * 0.56 + mistBreath * 0.36 + mistRibbon * 0.24\n);\nvec3 mistCol = mix(vec3(0.62, 0.86, 0.84), vec3(0.36, 0.46, 0.78), mistSeed);\nmistCol = mix(mistCol, vec3(0.94, 1.0, 0.97), glowPick * (0.45 + mistBreath * 0.35));\nvColor = mix(vColor, mistCol, uLoading * 0.78);\nvBright = mix(vBright, 0.20 + mistBreath * 0.18 + abs(mistCurl.x) * 0.06 + glowPick * (0.72 + abs(mistRibbon) * 0.24), uLoading);\nvAlpha = mix(vAlpha, 0.08 + mistBreath * 0.11 + dustPick * 0.11 + glowPick * 0.30, uLoading);\npos = mix(pos, mistPos, uLoading);\nloadingMistSize = 1.26 + mistBreath * 0.24 + abs(mistRibbon) * 0.14 + glowPick * 0.78;\n  }\n\n  vec4 mvPos = modelViewMatrix * vec4(pos, 1.0);\n  float depthSize = 36.0 / max(0.5, -mvPos.z);\n  float audioBoost = 1.0 + maxRippleAmp * 0.7 + edgeBoost * 0.55 + uBeat * 0.30 + uBurstAmt * 0.5;\n  float sz = clamp(depthSize * audioBoost, 1.05, 4.95);\n  if (uPreset > 4.5) {\nfloat flowDrive = uBass * 0.070 + uMid * 0.046 + uTreble * 0.060 + uBurstAmt * 0.090 + uBeat * 0.055;\nsz = clamp(depthSize * (1.05 + flowDrive), 1.00, 5.45);\n  } else if (uPreset > 3.5) {\nfloat ringDrive = uBass * 0.30 + uMid * 0.18 + uTreble * 0.22 + uBeat * 0.30;\nsz = clamp(depthSize * (0.90 + ringDrive * 0.62), 1.05, 3.90);\n  }\n  // 加载态下粒子稍大\n  sz = mix(sz, sz * loadingMistSize, uLoading);\n  gl_PointSize = sz * uPixel * uPointScale;\n  gl_Position = projectionMatrix * mvPos;\n}\n", dispose: function () {  } });
  
(function () {
  if (typeof document === 'undefined') return;
  var grid = document.getElementById('preset-grid');
  if (!grid || !grid.parentNode) return;
  var section = document.createElement('section');
  section.setAttribute('data-mr-preset-panel', '0');
  section.style.cssText = 'display:none;margin:12px 0';
  var button = document.createElement('button');
  button.type = 'button';
  button.setAttribute('data-mr-preset-panel-toggle', '');
  button.textContent = "emily专辑封面参数设置";
  button.style.cssText = 'padding:10px 16px;border-radius:9px;color:#eee;background:#222b39;border:1px solid #5c6370;width:100%';
  var body = document.createElement('div');
  body.className = 'mr-preset-panel-body';
  body.style.cssText = 'display:none;margin-top:8px;max-height:65vh;overflow:auto;background:#090b10;border:1px solid rgba(255,255,255,.10);border-radius:12px;padding:10px 12px';
  body.innerHTML = "<div class=\"fx-section-label\">基础画面</div><div class=\"fx-slider\"><label>律动强度</label><input data-mr-preset-range=\"intensity\" type=\"range\" min=\"0.2\" max=\"1.6\" step=\"0.01\"><output></output></div><div class=\"fx-slider\"><label>画面景深</label><input data-mr-preset-range=\"depth\" type=\"range\" min=\"0.2\" max=\"1.8\" step=\"0.01\"><output></output></div><div class=\"fx-slider\"><label>封面清晰度</label><input data-mr-preset-range=\"coverResolution\" type=\"range\" min=\"0.75\" max=\"1.55\" step=\"0.01\"><output></output></div><div class=\"fx-slider\"><label>镜头晃动</label><input data-mr-preset-range=\"cinemaShake\" type=\"range\" min=\"0\" max=\"1.8\" step=\"0.01\"><output></output></div><div class=\"fx-toggle-grid\"><div class=\"fx-toggle\" data-mr-preset-toggle=\"cinema\"><span>电影镜头</span><span class=\"dot\"></span></div></div><div class=\"fx-section-label\">粒子与光影</div><div class=\"fx-toggle-grid\"><div class=\"fx-toggle\" data-mr-preset-toggle=\"floatLayer\"><span>浮空粒子层</span><span class=\"dot\"></span></div></div><div class=\"fx-toggle-grid\"><div class=\"fx-toggle\" data-mr-preset-toggle=\"bloom\"><span>粒子溢光</span><span class=\"dot\"></span></div></div><div class=\"fx-toggle-grid\"><div class=\"fx-toggle\" data-mr-preset-toggle=\"edge\"><span>轮廓高亮</span><span class=\"dot\"></span></div></div><div class=\"fx-toggle-grid\"><div class=\"fx-toggle\" data-mr-preset-toggle=\"backgroundStarRiver\"><span>背景星河</span><span class=\"dot\"></span></div></div><div class=\"fx-slider\"><label>粒子尺寸</label><input data-mr-preset-range=\"point\" type=\"range\" min=\"0.5\" max=\"2.2\" step=\"0.01\"><output></output></div><div class=\"fx-slider\"><label>运动速度</label><input data-mr-preset-range=\"speed\" type=\"range\" min=\"0.2\" max=\"2.5\" step=\"0.01\"><output></output></div><div class=\"fx-slider\"><label>粒子扭曲</label><input data-mr-preset-range=\"twist\" type=\"range\" min=\"0\" max=\"0.6\" step=\"0.01\"><output></output></div><div class=\"fx-slider\"><label>色彩张力</label><input data-mr-preset-range=\"color\" type=\"range\" min=\"0.5\" max=\"2\" step=\"0.01\"><output></output></div><div class=\"fx-slider\"><label>光晕强度</label><input data-mr-preset-range=\"bloomStrength\" type=\"range\" min=\"0\" max=\"1.6\" step=\"0.01\"><output></output></div><div class=\"fx-slider\"><label>离散感</label><input data-mr-preset-range=\"scatter\" type=\"range\" min=\"0\" max=\"0.5\" step=\"0.01\"><output></output></div><div class=\"fx-slider\"><label>背景压暗</label><input data-mr-preset-range=\"bgFade\" type=\"range\" min=\"0\" max=\"1.2\" step=\"0.01\"><output></output></div>";
  var resetRow = document.createElement('div');
  resetRow.className = 'fx-actions';
  resetRow.style.cssText = 'margin-top:10px;padding-top:8px;border-top:1px solid rgba(255,255,255,.10)';
  var resetButton = document.createElement('button');
  resetButton.type = 'button';
  resetButton.className = 'fx-mini-btn ghost';
  resetButton.setAttribute('data-mr-preset-reset', '');
  resetButton.textContent = '恢复默认';
  resetRow.appendChild(resetButton);
  body.appendChild(resetRow);

  function refreshHost() {
    if (typeof updateFxInputs === 'function') updateFxInputs();
    if (typeof updateSonicGroundColorControls === 'function') updateSonicGroundColorControls();
    if (typeof updateSonicWorkshopColorControls === 'function') updateSonicWorkshopColorControls();
    if (typeof bindSonicAudioMonitorControls === 'function') bindSonicAudioMonitorControls();
    if (typeof refreshSonicAudioMonitorUi === 'function') refreshSonicAudioMonitorUi();
  }
  function syncValues() {
    body.querySelectorAll('[data-mr-preset-range]').forEach(function (input) {
      var key = input.getAttribute('data-mr-preset-range');
      var value = presetFxParamValue(key);
      input.value = value;
      var out = input.parentElement && input.parentElement.querySelector('output');
      if (out) out.textContent = String(value);
    });
    body.querySelectorAll('[data-mr-preset-toggle]').forEach(function (el) {
      el.classList.toggle('on', !!presetFxParamValue(el.getAttribute('data-mr-preset-toggle')));
    });
  }
  button.addEventListener('click', function () {
    var open = body.style.display !== 'none';
    body.style.display = open ? 'none' : '';
    button.classList.toggle('active', !open);
    if (!open) syncValues();
  });
  resetButton.addEventListener('click', function () {
    if (typeof resetPresetFxProfile === 'function') resetPresetFxProfile(0);
    body.querySelectorAll('[data-preset-key]').forEach(function (input) {
      var key = input.getAttribute('data-preset-key');
      if (typeof fxDefaults !== 'undefined' && typeof fxDefaults[key] !== 'undefined') fx[key] = fxDefaults[key];
    });
    if (typeof sonicAudioNormalizeFx === 'function') sonicAudioNormalizeFx(fx);
    if (typeof syncFxUniforms === 'function') syncFxUniforms();
    if (typeof saveLyricLayout === 'function') saveLyricLayout({ user: true, reason: 'preset-panel-reset' });
    syncValues();
    refreshHost();
    if (typeof showToast === 'function') showToast('已恢复该预设的默认参数');
  });
  body.querySelectorAll('[data-mr-preset-range]').forEach(function (input) {
    input.addEventListener('input', function () {
      setPresetFxParam(input.getAttribute('data-mr-preset-range'), parseFloat(input.value));
      syncValues();
    });
  });
  body.querySelectorAll('[data-mr-preset-toggle]').forEach(function (el) {
    el.addEventListener('click', function () {
      var key = el.getAttribute('data-mr-preset-toggle');
      setPresetFxParam(key, !presetFxParamValue(key));
      syncValues();
    });
  });
  body.querySelectorAll('[data-preset-key]').forEach(function (input) {
    input.addEventListener('input', function () {
      var key = input.getAttribute('data-preset-key');
      var value = input.type === 'range' ? Number(input.value) : input.value;
      if (input.type === 'range' && !isFinite(value)) return;
      fx[key] = value;
      if (/^sonicAudio/.test(key) && typeof sonicAudioNormalizeFx === 'function') sonicAudioNormalizeFx(fx);
      if (typeof syncFxUniforms === 'function') syncFxUniforms();
      if (typeof saveLyricLayout === 'function') saveLyricLayout({ user: true, reason: 'preset-panel' });
      var out = input.parentElement && input.parentElement.querySelector('output');
      if (out) out.textContent = input.type === 'range' ? String(value) : String(value).toUpperCase();
    });
  });

  section.appendChild(button);
  section.appendChild(body);
  grid.parentNode.insertBefore(section, grid.nextSibling);
  var wasActive = false;
  function updateActive() {
    var active = Number(window.fx && fx.preset) === 0;
    section.style.display = active ? '' : 'none';
    if (active && !wasActive) { refreshHost(); syncValues(); }
    if (!active) { body.style.display = 'none'; button.classList.remove('active'); }
    wasActive = active;
  }
  api.timer.setInterval(updateActive, 300);
  if (api.hook && typeof api.hook.after === 'function') {
    try { api.hook.after('setPreset', function () { updateActive(); }); } catch (e) { }
  }
  api._uninstallers.push(function () { if (section.parentNode) section.parentNode.removeChild(section); });
  updateActive();
})();

  return disposePreset;
});
